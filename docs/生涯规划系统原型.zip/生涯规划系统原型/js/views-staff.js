/* ============================================================
   生涯规划系统 · MVP 原型 —— 辅导员端 & 管理端视图
   ============================================================ */

window.StaffViews = {

  /* ============================================================
     辅导员 · 工作总览
     ============================================================ */
  advisorDashboard(appEl) {
    const list = MOCK_STUDENTS;
    const assessed = list.filter(s => s.assessed).length;
    const planned = list.filter(s => s.primaryGoal !== '—').length;
    const late = list.filter(s => s.status === 'late');
    const ask = list.filter(s => s.askGuidance);
    const taskRate = Math.round(list.filter(s=>s.planRate>0).reduce((n,s)=>n+s.planRate,0) / Math.max(1,list.filter(s=>s.planRate>0).length));

    const html = `
    <div class="page-head">
      <div class="eyebrow">计算机学院 · 2026 级</div>
      <h1>工作总览</h1>
      <p>仅展示你负责的学生（共 ${list.length} 人），所有查看操作均记录审计日志。</p>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="s-label">所带学生</div><div class="s-value">${list.length}<em> 人</em></div><div class="s-trend muted">计科 2 班 + 软工 2 班</div></div>
      <div class="stat-card"><div class="s-label">测评完成率</div><div class="s-value">${Math.round(assessed/list.length*100)}<em>%</em></div><div class="s-trend muted">${list.length-assessed} 人未完成</div></div>
      <div class="stat-card"><div class="s-label">计划制定率</div><div class="s-value">${Math.round(planned/list.length*100)}<em>%</em></div><div class="s-trend muted">${planned} 人已确认</div></div>
      <div class="stat-card"><div class="s-label">任务平均完成率</div><div class="s-value">${taskRate}<em>%</em></div><div class="s-trend muted">仅统计已制定计划学生</div></div>
    </div>

    <div class="section-title">需要关注</div>
    <div class="row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="card card-pad">
        <div class="row between">
          <div class="card-title" style="font-size:14px">主动申请指导</div>
          <span class="badge badge-amber">${ask.length}</span>
        </div>
        ${ask.length ? ask.map(s => `
          <div class="row between mt12" style="border-top:1px dashed var(--line-2);padding-top:10px">
            <div><b>${s.name}</b><span class="small muted"> · ${s.className}</span>
              <div class="small muted">在阶段复盘中申请了指导</div></div>
            <a class="btn btn-soft btn-sm" href="#/advisor/student/${s.id}">去处理</a>
          </div>`).join('') : `<div class="small muted mt8">暂无申请</div>`}
      </div>
      <div class="card card-pad">
        <div class="row between">
          <div class="card-title" style="font-size:14px">长期未复盘</div>
          <span class="badge badge-red">${late.length}</span>
        </div>
        ${late.length ? late.map(s => `
          <div class="row between mt12" style="border-top:1px dashed var(--line-2);padding-top:10px">
            <div><b>${s.name}</b><span class="small muted"> · ${s.className}</span>
              <div class="small muted">最近复盘 ${s.lastReview || '—'}（超过 45 天）</div></div>
            <a class="btn btn-paper btn-sm" href="#/advisor/student/${s.id}">查看</a>
          </div>`).join('') : `<div class="small muted mt8">暂无</div>`}
      </div>
    </div>

    <div class="section-title">最新学生动态</div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>学生</th><th>完成度</th><th>测评</th><th>路径 / 方向</th><th>主目标</th><th>计划完成</th><th>最近复盘</th></tr>
        ${list.slice(0,5).map(s => `
        <tr>
          <td><a href="#/advisor/student/${s.id}" class="cell-main">${s.name}</a><div class="cell-sub">${s.className}</div></td>
          <td><div style="display:flex;align-items:center;gap:8px">${progressBar(s.complete,5)}<span class="num">${s.complete}%</span></div></td>
          <td>${s.assessed ? badge('已完成','green') : badge('未完成','gray')}</td>
          <td>${s.direction !== '未确定' ? s.path ? PATHS[s.path]?.name + ' · ' : '' : ''}<span class="small">${s.direction}</span></td>
          <td class="small">${s.primaryGoal}</td>
          <td class="num">${s.planRate}%</td>
          <td class="small">${s.lastReview || '<span class="faint">—</span>'}</td>
        </tr>`).join('')}
      </table>
    </div>
    <div class="row mt12" style="justify-content:flex-end">
      <a class="btn btn-soft btn-sm" href="#/advisor/students">查看全部学生 →</a>
    </div>`;

    renderStaffShell(html, 'advisor', 'dashboard');
  },

  /* ============================================================
     辅导员 · 学生列表（组合筛选）
     ============================================================ */
  advisorStudents(appEl) {
    let fPath = 'all', fSpecial = 'all', kw = '';
    function body() {
      let list = MOCK_STUDENTS.slice();
      if (fPath !== 'all') list = list.filter(s => s.path === fPath);
      if (fSpecial === 'nogoal') list = list.filter(s => !s.primaryGoal || s.primaryGoal === '—');
      if (fSpecial === 'late') list = list.filter(s => s.status === 'late');
      if (fSpecial === 'ask') list = list.filter(s => s.askGuidance);
      if (kw) list = list.filter(s => s.name.includes(kw) || s.className.includes(kw));
      return `
      <div class="page-head">
        <div class="eyebrow">辅导员工作台</div>
        <h1>学生列表</h1>
        <p>支持按路径、方向、目标状态等条件组合筛选；仅展示授权范围内学生。</p>
      </div>
      <div class="card card-pad mb12">
        <div class="filter-bar">
          <select class="input" id="f-path">
            <option value="all" ${fPath==='all'?'selected':''}>全部路径</option>
            ${Object.values(PATHS).map(p=>`<option value="${p.id}" ${fPath===p.id?'selected':''}>${p.name}</option>`).join('')}
          </select>
          <select class="input" id="f-special">
            <option value="all" ${fSpecial==='all'?'selected':''}>全部状态</option>
            <option value="nogoal" ${fSpecial==='nogoal'?'selected':''}>未确定目标</option>
            <option value="late" ${fSpecial==='late'?'selected':''}>长期未复盘</option>
            <option value="ask" ${fSpecial==='ask'?'selected':''}>主动申请指导</option>
          </select>
          <input class="input" id="f-kw" placeholder="搜索姓名 / 班级" value="${esc(kw)}" style="min-width:160px">
          <button class="btn btn-paper btn-sm" id="f-reset">重置</button>
          <span class="small muted" style="margin-left:auto">共 ${list.length} 人</span>
        </div>
      </div>
      <div class="table-wrap">
        <table class="data">
          <tr><th>学生</th><th>完成度</th><th>测评</th><th>路径 / 方向</th><th>主目标</th><th>计划完成</th><th>最近复盘</th><th>标签</th><th></th></tr>
          ${list.map(s => `
          <tr>
            <td><div class="cell-main">${s.name}</div><div class="cell-sub">${s.className}</div></td>
            <td class="num">${s.complete}%</td>
            <td>${s.assessed ? badge('已完成','green') : badge('未完成','gray')}</td>
            <td class="small">${s.direction}</td>
            <td class="small">${s.primaryGoal}</td>
            <td class="num">${s.planRate}%</td>
            <td class="small">${s.lastReview || '<span class="faint">—</span>'}</td>
            <td>
              ${s.status==='late' ? badge('长期未复盘','red') : ''}
              ${s.askGuidance ? badge('申请指导','amber') : ''}
              ${s.assessed ? '' : badge('待测评','gray')}
            </td>
            <td><a class="btn btn-soft btn-sm" href="#/advisor/student/${s.id}">查看</a></td>
          </tr>`).join('')}
        </table>
      </div>`;
    }
    function paint() { appEl.querySelector('.staff-content').innerHTML = body(); wire(); }
    function wire() {
      appEl.querySelector('#f-path').addEventListener('change', e => { fPath = e.target.value; paint(); });
      appEl.querySelector('#f-special').addEventListener('change', e => { fSpecial = e.target.value; paint(); });
      appEl.querySelector('#f-kw').addEventListener('input', e => { kw = e.target.value; paint(); });
      const rst = appEl.querySelector('#f-reset');
      if (rst) rst.addEventListener('click', () => { fPath='all'; fSpecial='all'; kw=''; paint(); });
    }
    renderStaffShell(body(), 'advisor', 'students');
    wire();
  },

  /* ============================================================
     辅导员 · 学生详情
     ============================================================ */
  advisorStudentDetail(appEl, params) {
    const meta = MOCK_STUDENTS.find(s => s.id === params.id);
    if (!meta) { navigate('/404'); return; }
    const isMe = params.id === 'S1001' && App.state.session.role === 'advisor';
    const s = App.state.student;
    // 查看写入审计日志
    if (isMe) App.state.advisor.viewedAudit = true;
    const scores = s.assessment && s.assessment.scores;

    const html = `
    <div class="page-head">
      <div class="eyebrow"><a href="#/advisor/students" style="color:var(--amber-d)">← 返回学生列表</a></div>
      <h1>${meta.name} <span class="small muted" style="font-weight:400">${meta.className}</span></h1>
      <p>本次访问已写入审计日志 · 学生数据仅可查看，不可直接修改</p>
    </div>
    <div class="row gap8 mb12">
      ${meta.assessed ? badge('测评已完成','green') : badge('测评未完成','gray')}
      ${meta.status==='late' ? badge('长期未复盘','red') : ''}
      ${meta.askGuidance ? badge('主动申请指导','amber') : ''}
    </div>

    <div class="row" style="display:grid;grid-template-columns:2fr 1fr;gap:12px;align-items:start">
      <div>
        ${isMe && scores ? `
        <div class="card card-pad">
          <div class="card-title">六维画像</div>
          <div class="row gap12 mt8">
            ${radarSVG(DIMS.map(d=>({name:d.name,value:scores[d.key]||0})), 200)}
            <div class="grow small muted">${esc(s.portrait ? s.portrait.summary : '')}</div>
          </div>
        </div>` : `<div class="card card-pad"><div class="card-title">六维画像</div><p class="small muted mt8">画像数据仅对所带学生开放；演示账号下查看学生「${meta.name}」的完整画像需以对应学生身份体验。</p></div>`}

        <div class="card card-pad mt12">
          <div class="card-title">目标与计划</div>
          <div class="kv-grid mt8">
            <div class="kv"><div class="k">主目标</div><div class="v">${meta.primaryGoal}</div></div>
            <div class="kv"><div class="k">当前路径</div><div class="v">${meta.direction}</div></div>
            <div class="kv"><div class="k">计划制定</div><div class="v">${meta.planRate}%</div></div>
            <div class="kv"><div class="k">最近复盘</div><div class="v">${meta.lastReview || '—'}</div></div>
          </div>
          <div class="card-title mt16">计划完成趋势</div>
          ${progressBar(meta.planRate, 8)}
        </div>
      </div>

      <div>
        <div class="card card-pad">
          <div class="card-title">填写指导意见</div>
          <p class="small muted" style="margin:4px 0 8px">意见将写入学生指导记录，学生可查看；不直接修改学生数据。</p>
          <textarea class="textarea" id="adv-text" placeholder="例如：建议将 LeetCode 练习拆分到每天 30 分钟…"></textarea>
          <div class="row gap8 mt8">
            <button class="btn btn-soft btn-sm" id="adv-task">建议任务</button>
            <button class="btn btn-ghost btn-sm" id="adv-reassess">建议重新测评</button>
          </div>
          <button class="btn btn-primary btn-sm btn-block mt12" id="adv-save">提交指导意见</button>
        </div>

        <div class="card card-pad mt12">
          <div class="card-title">基础信息</div>
          <div class="kv-grid mt8">
            <div class="kv"><div class="k">年级</div><div class="v">2026 级</div></div>
            <div class="kv"><div class="k">专业大类</div><div class="v">计算机类</div></div>
            <div class="kv"><div class="k">发展意向</div><div class="v">${meta.path ? PATHS[meta.path]?.name : '未确定'}</div></div>
            <div class="kv"><div class="k">完整度</div><div class="v">${meta.complete}%</div></div>
          </div>
        </div>
      </div>
    </div>`;

    renderStaffShell(html, 'advisor', 'students');
    const root = appEl.querySelector('.staff-content');
    const doSave = () => {
      const txt = root.querySelector('#adv-text').value.trim();
      if (!txt) { toast('请先填写指导意见内容', 'error'); return; }
      toast('指导意见已提交，学生可在"复盘"中查看', 'success');
      root.querySelector('#adv-text').value = '';
    };
    root.querySelector('#adv-save').addEventListener('click', doSave);
    root.querySelector('#adv-task').addEventListener('click', () => {
      modal({
        title:'建议任务',
        body:h(`<div class="field"><label>建议任务内容</label><textarea class="textarea" id="sug-task" placeholder="建议学生补充的任务"></textarea></div>
          <div class="field"><label>建议完成时间</label><input class="input" id="sug-date" placeholder="如 2026-11"></div>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">发送建议</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{ ft.closest('.modal-mask').remove(); toast('建议任务已发送给学生','success'); });
        },
      });
    });
    root.querySelector('#adv-reassess').addEventListener('click', () => {
      confirmModal({ title:'建议重新测评', text:'将建议学生重新完成一次生涯测评，用于更新画像与推荐。该操作不会立即触发。', okText:'发送建议', onOk(){ toast('已建议重新测评','success'); } });
    });
  },

  /* ============================================================
     辅导员 · 指导意见
     ============================================================ */
  advisorComments(appEl) {
    const comments = [
      { id:'C1', student:'张雨', className:'计科2602', time:'2026-10-02 20:40', content:'建议把 LeetCode 练习拆分到每天 30 分钟，减少集中刷题带来的疲惫；10 月数据结构是主线，SQL 可以延后。', replied:true },
      { id:'C2', student:'陈晨', className:'计科2601', time:'2026-09-18 15:20', content:'留学准备中 GPA 优先，注意别让英语标化挤占课程学习；建议 11 月先联系一位导师了解实验室。', replied:false },
    ];
    const html = `
    <div class="page-head">
      <div class="eyebrow">辅导员工作台</div>
      <h1>指导意见</h1>
      <p>针对学生的指导意见记录，学生确认采纳后系统将保存目标与计划版本。</p>
    </div>
    ${comments.map(c => `
    <div class="card card-pad mb12">
      <div class="row between">
        <div class="row gap8">
          <div class="dc-icon" style="width:34px;height:34px;border-radius:9px;font-size:15px;background:var(--teal-s)">${c.student[0]}</div>
          <div><b>${c.student}</b><span class="small muted"> · ${c.className}</span>
            <div class="small faint">${c.time}</div></div>
        </div>
        ${c.replied ? badge('学生已查看','green') : badge('待学生确认','amber')}
      </div>
      <p class="mt12" style="font-size:14px;background:var(--paper);border-radius:9px;padding:10px 12px">${esc(c.content)}</p>
    </div>`).join('')}`;
    renderStaffShell(html, 'advisor', 'comments');
  },

  /* ============================================================
     辅导员 · 群体统计
     ============================================================ */
  advisorStatistics(appEl) {
    const list = MOCK_STUDENTS;
    const byPath = Object.values(PATHS).map(p => ({ name:p.name, n: list.filter(s=>s.path===p.id).length }));
    const maxN = Math.max(1, ...byPath.map(x=>x.n));
    const assessed = list.filter(s=>s.assessed).length;
    const planned = list.filter(s=>s.primaryGoal!=='—').length;
    const avgRate = Math.round(list.filter(s=>s.planRate>0).reduce((n,s)=>n+s.planRate,0) / Math.max(1,list.filter(s=>s.planRate>0).length));

    const html = `
    <div class="page-head">
      <div class="eyebrow">辅导员工作台</div>
      <h1>群体统计</h1>
      <p>基础群体分析，用于分类指导；不自动认定"风险学生"。</p>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="s-label">测评完成率</div><div class="s-value">${Math.round(assessed/list.length*100)}<em>%</em></div>${progressBar(assessed/list.length*100,6)}</div>
      <div class="stat-card"><div class="s-label">计划制定率</div><div class="s-value">${Math.round(planned/list.length*100)}<em>%</em></div>${progressBar(planned/list.length*100,6)}</div>
      <div class="stat-card"><div class="s-label">任务平均完成率</div><div class="s-value">${avgRate}<em>%</em></div>${progressBar(avgRate,6)}</div>
      <div class="stat-card"><div class="s-label">申请指导学生</div><div class="s-value">${list.filter(s=>s.askGuidance).length}<em> 人</em></div><div class="s-trend muted">待及时跟进</div></div>
    </div>

    <div class="row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px">
      <div class="card card-pad">
        <div class="card-title">发展路径分布</div>
        <div class="mt12" style="display:grid;gap:12px">
          ${byPath.map(p => `
            <div class="row gap8">
              <span style="width:56px;font-size:13px">${p.name}</span>
              <div class="progress grow"><i style="width:${p.n/maxN*100}%;background:${PATHS[p.id].color}"></i></div>
              <span class="num small" style="width:36px;text-align:right">${p.n} 人</span>
            </div>`).join('')}
        </div>
      </div>
      <div class="card card-pad">
        <div class="card-title">方向分布（Top 5）</div>
        <div class="mt12" style="display:grid;gap:10px">
          ${['后端开发工程师','数据分析师','计算机技术考研','海外计算机硕士','软件测试工程师'].map((n,i)=>`
            <div class="row gap8">
              <span class="small" style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${n}</span>
              <div class="progress grow"><i style="width:${[62,38,28,24,14][i]}%"></i></div>
              <span class="num small" style="width:30px;text-align:right">${[3,2,1,1,1][i]}</span>
            </div>`).join('')}
        </div>
      </div>
    </div>

    <div class="card card-pad mt12">
      <div class="card-title">完成度分布</div>
      <div class="row mt12" style="gap:0;align-items:flex-end;height:130px">
        ${['0-40%','40-70%','70-90%','90-100%'].map((r,i)=>{
          const n = [2,1,2,3][i];
          return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px">
            <div style="height:${n*26}px;width:46%;border-radius:7px 7px 0 0;background:${['#C67B34','#8FA9B4','#4C8FA8','#0E5A6D'][i]}"></div>
            <span class="small muted">${r}</span><span class="num small">${n}人</span></div>`;
        }).join('')}
      </div>
    </div>`;
    renderStaffShell(html, 'advisor', 'statistics');
  },

  /* ============================================================
     管理端 · 用户与白名单
     ============================================================ */
  adminUsers(appEl) {
    const whitelist = MOCK_WHITELIST.slice();
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 系统配置</div>
      <h1>用户与白名单</h1>
      <p>批量导入可注册学号、班级与初始校验信息；批量操作需二次确认。</p>
    </div>
    <div class="card card-pad mb12">
      <div class="row gap8">
        <button class="btn btn-primary btn-sm" id="batch-import">⬆ 批量导入白名单</button>
        <button class="btn btn-soft btn-sm" id="add-user">＋ 新增白名单</button>
        <div style="flex:1"></div>
        <span class="small muted">共 ${whitelist.length} 条 · 已注册 ${whitelist.filter(w=>w.used).length} 人</span>
      </div>
    </div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>学号</th><th>姓名</th><th>班级</th><th>初始校验码</th><th>状态</th><th></th></tr>
        ${whitelist.map(w => `
        <tr>
          <td class="cell-main num">${w.studentNo}</td><td>${w.name}</td><td>${w.className}</td>
          <td class="num faint">${w.verifyCode}</td>
          <td>${w.used ? badge('已注册','green') : badge('待注册','gray')}</td>
          <td>${w.used ? '' : `<button class="btn btn-paper btn-sm" data-del="${w.studentNo}">移除</button>`}</td>
        </tr>`).join('')}
      </table>
    </div>`;
    renderStaffShell(html, 'admin', 'users');
    const root = appEl.querySelector('.staff-content');
    root.querySelector('#batch-import').addEventListener('click', () => {
      modal({
        title:'批量导入白名单',
        body:h(`<div class="field"><label>粘贴 CSV（学号,姓名,班级,校验码）</label>
          <textarea class="textarea" id="csv" rows="6" placeholder="2026011311,吴迪,软工2602,202611&#10;2026011312,郑好,计科2603,202612"></textarea></div>
          <p class="small muted">重复学号将被拒绝并返回错误明细。</p>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">导入</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{
            const csv = ft.closest('.modal-mask').querySelector('#csv').value.trim();
            const lines = csv.split('\n').filter(Boolean);
            let ok=0, dup=0;
            lines.forEach(ln => {
              const [no,name,cls,code] = ln.split(',').map(x=>x.trim());
              if (!no || !name) return;
              if (MOCK_WHITELIST.find(w=>w.studentNo===no)) { dup++; return; }
              MOCK_WHITELIST.push({ studentNo:no, name, className:cls||'未知', verifyCode:code||'000000', used:false, status:'待注册' });
              ok++;
            });
            ft.closest('.modal-mask').remove();
            toast(`导入完成：成功 ${ok} 条${dup?`，拒绝重复 ${dup} 条`:''}`, ok?'success':'error');
            navigate('/admin/users');
          });
        },
      });
    });
    root.querySelector('#add-user').addEventListener('click', () => {
      modal({
        title:'新增白名单',
        body:h(`<div class="row gap8"><div class="field grow"><label>学号</label><input class="input" id="n-no"></div><div class="field grow"><label>姓名</label><input class="input" id="n-name"></div></div>
          <div class="row gap8"><div class="field grow"><label>班级</label><input class="input" id="n-cls" placeholder="如 计科2603"></div><div class="field grow"><label>校验码</label><input class="input" id="n-code"></div></div>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">添加</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{
            const m=ft.closest('.modal-mask');
            const no=m.querySelector('#n-no').value.trim(), nm=m.querySelector('#n-name').value.trim();
            if(!no||!nm){toast('请填写学号与姓名','error');return;}
            MOCK_WHITELIST.push({ studentNo:no, name:nm, className:m.querySelector('#n-cls').value||'未知', verifyCode:m.querySelector('#n-code').value||'000000', used:false, status:'待注册' });
            m.remove(); toast('已添加到白名单','success'); navigate('/admin/users');
          });
        },
      });
    });
    root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => {
      confirmModal({ title:'移除白名单', text:`确定移除学号 ${b.dataset.del} 吗？该操作会记录审计日志。`, okText:'移除', danger:true, onOk(){
        const i=MOCK_WHITELIST.findIndex(w=>w.studentNo===b.dataset.del); if(i>=0) MOCK_WHITELIST.splice(i,1);
        toast('已移除','success'); navigate('/admin/users');
      }});
    }));
  },

  /* ============================================================
     管理端 · 问卷管理
     ============================================================ */
  adminQuestionnaires(appEl) {
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 内容配置</div>
      <h1>问卷管理</h1>
      <p>问卷支持版本管理、发布与停用；已发布版本不可直接修改，修改须生成新版本。</p>
    </div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>问卷</th><th>类型</th><th>当前版本</th><th>题目数</th><th>状态</th><th>更新时间</th><th>操作</th></tr>
        ${QUESTIONNAIRES.map((q,i) => `
        <tr>
          <td><div class="cell-main">${q.icon} ${q.name}</div><div class="cell-sub">${esc(q.tip)}</div></td>
          <td>${i===0?'霍兰德兴趣简版':i===1?'职业价值观':i===2?'能力自评':'专业认知与发展倾向'}</td>
          <td class="num">v2</td>
          <td class="num">${q.questions.length}（简版）</td>
          <td>${badge('已发布','green')}</td>
          <td class="small">2026-09-01</td>
          <td>
            <button class="btn btn-soft btn-sm" data-preview="${i}">预览</button>
            <button class="btn btn-paper btn-sm" data-ver="${i}">创建新版本</button>
          </td>
        </tr>`).join('')}
      </table>
    </div>
    <div class="card card-pad mt12">
      <div class="card-title">计分说明</div>
      <p class="small muted" style="margin-top:6px">计分由确定性规则完成，不依赖大模型；相同答案得到相同分数。题目总量建议 60—75 题（原型为简版示例）。计分映射与维度权重保存在配置表，修改须生成新版本。</p>
    </div>`;
    renderStaffShell(html, 'admin', 'questionnaires');
    const root = appEl.querySelector('.staff-content');
    root.querySelectorAll('[data-preview]').forEach(b => b.addEventListener('click', () => {
      const q = QUESTIONNAIRES[parseInt(b.dataset.preview,10)];
      modal({
        title:`${q.icon} ${q.name} · 预览（${q.questions.length} 题）`,
        body:h(`<div class="prose" style="font-size:13px;max-height:52vh;overflow:auto">
          ${q.questions.map((qq,qi)=>`<p style="margin-bottom:10px"><b>${qi+1}. ${esc(qq.q)}</b>${qq.type==='rating'?`<span class="small muted">（5 级自评：${qq.labels.join(' → ')}）</span>`:`<br><span class="small muted">${qq.options.map(o=>o.text).join(' · ')}</span>`}</p>`).join('')}
        </div>`),
        foot: ft => ft.append(h(`<button class="btn btn-primary btn-sm">关闭</button>`, {})),
      });
    }));
    root.querySelectorAll('[data-ver]').forEach(b => b.addEventListener('click', () => {
      toast('已创建 v3 草稿（修改需审核后发布）', 'success');
    }));
  },

  /* ============================================================
     管理端 · 方向库
     ============================================================ */
  adminDirections(appEl) {
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 内容配置</div>
      <h1>方向库</h1>
      <p>维护路径、方向内容与展示顺序；停用方向不参与新推荐。</p>
    </div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>方向</th><th>路径</th><th>能力要求</th><th>匹配目标值</th><th>状态</th><th>更新时间</th><th>操作</th></tr>
        ${DIRECTIONS.map(d => `
        <tr>
          <td><div class="cell-main">${d.icon} ${d.name}</div></td>
          <td>${PATHS[d.path].name}</td>
          <td class="small">${d.abilities.join('、')}</td>
          <td class="small num">${DIMS.map(x=>x.name.slice(0,2)+':'+d.target[x.key]).join(' ')}</td>
          <td>${d.status==='published' ? badge('已发布','green') : badge('停用','gray')}</td>
          <td class="small">${d.updated}</td>
          <td>
            <button class="btn btn-soft btn-sm" data-edit="${d.id}">编辑</button>
            <button class="btn btn-paper btn-sm" data-toggle="${d.id}">${d.status==='published'?'停用':'启用'}</button>
          </td>
        </tr>`).join('')}
      </table>
    </div>`;
    renderStaffShell(html, 'admin', 'directions');
    const root = appEl.querySelector('.staff-content');
    root.querySelectorAll('[data-toggle]').forEach(b => b.addEventListener('click', () => {
      const d = DIRECTIONS.find(x => x.id === b.dataset.toggle);
      d.status = d.status === 'published' ? 'stopped' : 'published';
      toast(`${d.name} 已${d.status==='published'?'启用':'停用'}`, 'success');
      navigate('/admin/directions');
    }));
    root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
      const d = DIRECTIONS.find(x => x.id === b.dataset.edit);
      modal({
        title:`编辑 · ${d.name}`,
        body:h(`<div class="field"><label>方向简介</label><textarea class="textarea" id="ed-intro" rows="3">${esc(d.intro)}</textarea></div>
          <div class="field"><label>展示顺序</label><input class="input" id="ed-rank" value="${d.id.includes('backend')?1:2}"></div>
          <p class="small muted">修改方向内容将生成新版本，需教师审核后发布。</p>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">保存草稿</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{ d.intro = ft.closest('.modal-mask').querySelector('#ed-intro').value; ft.closest('.modal-mask').remove(); toast('草稿已保存（待审核发布）','success'); });
        },
      });
    }));
  },

  /* ============================================================
     管理端 · 培养方案
     ============================================================ */
  adminCurricula(appEl) {
    const items = MOCK_IMPORT_ITEMS;
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 培养方案</div>
      <h1>培养方案（PDF 导入）</h1>
      <p>上传培养方案 PDF → 自动解析 → 人工校核 → 审核发布；未审核数据不参与推荐。</p>
    </div>
    <div class="card card-pad mb12">
      <div class="row gap8">
        <button class="btn btn-primary btn-sm" id="upload-pdf">⬆ 上传培养方案 PDF</button>
        <div class="small muted grow">最近任务：<b>IM-003</b> · 2026 级计算机类培养方案 · 解析 42 条，待审核 ${items.filter(i=>i.status==='待审核').length} 条</div>
        <span class="badge badge-amber">IMPORT_REVIEW_REQUIRED</span>
      </div>
    </div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>课程代码</th><th>课程名称</th><th>学期</th><th>学分/学时</th><th>类别</th><th>模块</th><th>先修</th><th>置信度</th><th>状态</th><th></th></tr>
        ${items.map((it,i) => `
        <tr>
          <td class="num cell-main">${it.code}</td><td>${it.name}</td>
          <td class="num">${it.semester}</td><td class="num">${it.credits}/${it.hours}</td>
          <td class="small">${it.category}</td><td class="small">${it.module}</td>
          <td class="small">${it.prereq}</td>
          <td>${badge(it.confidence, it.confidence==='高'?'green':it.confidence==='中'?'amber':'red')}</td>
          <td>${badge(it.status, it.status==='待审核'?'amber':'gray')}</td>
          <td><button class="btn btn-soft btn-sm" data-review="${i}">校核</button></td>
        </tr>`).join('')}
      </table>
    </div>
    <div class="row mt12" style="justify-content:flex-end">
      <button class="btn btn-copper btn-sm" id="publish-all">审核通过并发布版本 v1.0</button>
    </div>`;
    renderStaffShell(html, 'admin', 'curricula');
    const root = appEl.querySelector('.staff-content');
    root.querySelector('#upload-pdf').addEventListener('click', () => {
      modal({
        title:'上传培养方案 PDF',
        body:h(`<div class="empty" style="padding:26px">
          <div class="e-icon">📄</div><div class="e-title">点击选择 PDF 文件</div>
          <div class="e-sub">自动解析课程名称、代码、学期、学分、学时、类别、模块与先修课程</div>
        </div><p class="small muted mt8">扫描版 PDF 将标记为需人工处理；跨页表格可人工合并校核。</p>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">开始解析</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{ ft.closest('.modal-mask').remove(); toast('解析任务已创建，完成后进入待审核区','success'); });
        },
      });
    });
    root.querySelectorAll('[data-review]').forEach(b => b.addEventListener('click', () => {
      const it = items[parseInt(b.dataset.review,10)];
      modal({
        title:`校核 · ${it.code} ${it.name}（第 ${it.page} 页）`,
        body:h(`<div class="kv-grid">
          <div class="kv"><div class="k">课程名称</div><input class="input" id="r-name" value="${esc(it.name)}"></div>
          <div class="kv"><div class="k">学分</div><input class="input" id="r-credits" value="${it.credits}"></div>
          <div class="kv"><div class="k">学时</div><input class="input" id="r-hours" value="${it.hours}"></div>
          <div class="kv"><div class="k">类别</div><input class="input" id="r-cat" value="${esc(it.category)}"></div>
        </div>
        <div class="field mt12"><label>能力标签</label><div class="row gap8 wrap" id="r-tags">
          ${ABILITY_TAGS.slice(0,6).map(t=>`<span class="chip-tag" data-tag="${t.id}">${t.name}</span>`).join('')}
        </div></div>
        <p class="small muted mt12">原文片段（第 ${it.page} 页）：${esc(it.code)} ${esc(it.name)} · ${it.credits} 学分 / ${it.hours} 学时</p>`),
        foot: ft => {
          const c=h(`<button class="btn btn-paper">取消</button>`), o=h(`<button class="btn btn-primary">确认校核</button>`);
          ft.append(c,o);
          c.addEventListener('click',()=>ft.closest('.modal-mask').remove());
          o.addEventListener('click',()=>{ it.status='待审核'; ft.closest('.modal-mask').remove(); toast('已记录校核修改','success'); });
        },
      });
    }));
    root.querySelector('#publish-all').addEventListener('click', () => {
      confirmModal({ title:'审核并发布', text:`将全部 ${items.filter(i=>i.status==='待审核').length} 条待审核课程标记为已发布（含 ${items.filter(i=>i.status==='待补录').length} 条待补录项将保留）。发布后版本不可修改。`, okText:'审核发布', onOk(){
        items.forEach(i=>{ if(i.status==='待审核') i.status='已发布'; });
        toast('培养方案 v1.0 已发布，可参与推荐','success'); navigate('/admin/curricula');
      }});
    });
  },

  /* ============================================================
     管理端 · 能力标签
     ============================================================ */
  adminAbilities(appEl) {
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 内容配置</div>
      <h1>能力标签</h1>
      <p>能力标签用于课程关联与方向能力要求；新增标签需审核。</p>
    </div>
    <div class="card card-pad mb12">
      <div class="row gap8">
        <input class="input" id="new-tag" placeholder="新增标签名称，如 云计算基础" style="max-width:260px">
        <button class="btn btn-primary btn-sm" id="add-tag">新增</button>
        <span class="small muted grow">共 ${ABILITY_TAGS.length} 个标签</span>
      </div>
    </div>
    <div class="row" style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
      ${ABILITY_TAGS.map(t => `
        <div class="card card-pad-md row between">
          <div class="row gap8">
            <span style="width:10px;height:10px;border-radius:3px;background:${t.color}"></span>
            <b>${t.name}</b>
          </div>
          <button class="btn btn-paper btn-sm" data-del-tag="${t.id}">删除</button>
        </div>`).join('')}
    </div>`;
    renderStaffShell(html, 'admin', 'abilities');
    const root = appEl.querySelector('.staff-content');
    root.querySelector('#add-tag').addEventListener('click', () => {
      const n = root.querySelector('#new-tag').value.trim();
      if (!n) { toast('请输入标签名称','error'); return; }
      ABILITY_TAGS.push({ id:'tag_'+Date.now(), name:n, color:'#0E5A6D' });
      root.querySelector('#new-tag').value=''; toast('已新增，等待审核','success'); navigate('/admin/abilities');
    });
    root.querySelectorAll('[data-del-tag]').forEach(b => b.addEventListener('click', () => {
      confirmModal({ title:'删除标签', text:'删除标签将解除相关课程关联（审计日志留存）。', okText:'删除', danger:true, onOk(){
        const i=ABILITY_TAGS.findIndex(x=>x.id===b.dataset.delTag); if(i>=0) ABILITY_TAGS.splice(i,1);
        toast('已删除','success'); navigate('/admin/abilities');
      }});
    }));
  },

  /* ============================================================
     管理端 · 任务模板
     ============================================================ */
  adminTemplates(appEl) {
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · 内容配置</div>
      <h1>任务模板</h1>
      <p>方向关联的学期目标与月度任务模板，供 AI 生成计划草案时使用。</p>
    </div>
    ${Object.entries(PLAN_TEMPLATES).map(([dirId, tpl]) => {
      const d = DIRECTIONS.find(x => x.id === dirId);
      return `
      <div class="card card-pad mb12">
        <div class="row between">
          <div class="row gap8">
            <div class="dc-icon" style="width:34px;height:34px;border-radius:9px;font-size:16px">${d.icon}</div>
            <div><b>${d.name}</b><div class="small muted">${tpl.semesterGoals.length} 个学期目标 · ${tpl.monthlyTasks.length} 项月度任务</div></div>
          </div>
          <button class="btn btn-paper btn-sm" data-edit-tpl="${dirId}">编辑</button>
        </div>
        <p class="small mt12" style="color:var(--ink-2)">${esc(tpl.goalSummary)}</p>
        <div class="row gap6 mt8 wrap">${tpl.semesterGoals.map(g=>badge(g.abilityTag.replace('_',' '),'teal')).join('')}</div>
      </div>`;
    }).join('')}`;
    renderStaffShell(html, 'admin', 'templates');
    appEl.querySelectorAll('[data-edit-tpl]').forEach(b => b.addEventListener('click', () => {
      toast('模板编辑将生成新版本（任务模板变更须审核后发布）', 'success');
    }));
  },

  /* ============================================================
     管理端 · 模型与提示词
     ============================================================ */
  adminModels(appEl) {
    const m = MOCK_MODELS;
    const html = `
    <div class="page-head">
      <div class="eyebrow">管理端 · AI 配置</div>
      <h1>模型与提示词</h1>
      <p>生产环境只允许发布状态提示词；每次 AI 调用记录 prompt_version 与 model_name。</p>
    </div>
    <div class="row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="card card-pad">
        <div class="card-title">模型配置</div>
        <div class="field mt8"><label>模型供应商</label><select class="input"><option selected>openai</option><option>anthropic</option><option>azure</option></select></div>
        <div class="field"><label>模型</label><input class="input" value="${m.model}"></div>
        <div class="row gap8"><div class="field grow"><label>超时（秒）</label><input class="input" value="${m.timeoutSec}"></div>
        <div class="field grow"><label>最大输出 token</label><input class="input" value="${m.maxTokens}"></div>
        <div class="field grow"><label>重试次数</label><input class="input" value="${m.retryCount}"></div></div>
        <div class="row gap8">
          <label class="row gap8 small" style="cursor:pointer"><input type="checkbox" checked style="accent-color:var(--teal)"> 启用 AI 服务</label>
          <button class="btn btn-primary btn-sm" style="margin-left:auto" id="save-model">保存配置</button>
        </div>
        <p class="small muted mt12">关闭公网模型后，账号、测评、画像、推荐排序、目标计划和任务记录仍可正常使用（降级到规则模板）。</p>
      </div>
      <div class="card card-pad">
        <div class="card-title">脱敏规则</div>
        <div class="small mt8" style="display:grid;gap:6px">
          <div class="row between" style="border-bottom:1px dashed var(--line-2);padding:6px 0"><span>姓名 / 学号 / 手机号</span>${badge('禁止发送','red')}</div>
          <div class="row between" style="border-bottom:1px dashed var(--line-2);padding:6px 0"><span>专业 / 年级 / 课程</span>${badge('可发送（脱敏）','teal')}</div>
          <div class="row between" style="border-bottom:1px dashed var(--line-2);padding:6px 0"><span>测评结果</span>${badge('仅维度与得分','teal')}</div>
          <div class="row between" style="border-bottom:1px dashed var(--line-2);padding:6px 0"><span>辅导员意见</span>${badge('默认不发送','gray')}</div>
          <div class="row between" style="padding:6px 0"><span>自由文本</span>${badge('正则遮蔽 + 限长','amber')}</div>
        </div>
      </div>
    </div>

    <div class="section-title">提示词版本</div>
    <div class="table-wrap">
      <table class="data">
        <tr><th>版本</th><th>场景</th><th>状态</th><th>发布时间</th><th>更新时间</th><th>操作</th></tr>
        ${m.prompts.map(p => `
        <tr>
          <td class="num cell-main">${p.version}</td><td>${p.scene}</td>
          <td>${p.status==='published' ? badge('已发布','green') : badge('草稿','gray')}</td>
          <td class="small">${p.publishedAt}</td><td class="small">${p.updatedAt}</td>
          <td><button class="btn btn-soft btn-sm" data-view-prompt="${p.version}">查看</button></td>
        </tr>`).join('')}
      </table>
    </div>`;
    renderStaffShell(html, 'admin', 'models');
    const root = appEl.querySelector('.staff-content');
    root.querySelector('#save-model').addEventListener('click', () => toast('模型配置已保存，配置变更已记录审计日志','success'));
    root.querySelectorAll('[data-view-prompt]').forEach(b => b.addEventListener('click', () => {
      const p = m.prompts.find(x=>x.version===b.dataset.viewPrompt);
      modal({
        title:`提示词 ${p.version} · ${p.scene}`,
        body:h(`<div class="legal-box" style="white-space:pre-wrap;font-size:12.5px">${esc(p.content)}</div>
          <p class="small muted mt12">提示词明确禁止生成结论性标签，必须输出可选建议与人工复核提示。</p>`),
        foot: ft => ft.append(h(`<button class="btn btn-primary btn-sm">关闭</button>`, {})),
      });
    }));
  },

  /* ============================================================
     管理端 · 审计日志
     ============================================================ */
  adminLogs(appEl) {
    const logs = MOCK_AUDIT;
    let filter = 'all';
    function body() {
      let list = logs;
      if (filter !== 'all') list = logs.filter(l => l.level === filter);
      return `
      <div class="page-head">
        <div class="eyebrow">管理端 · 可审计性</div>
        <h1>审计日志</h1>
        <p>登录、查看学生详情、导出、配置变更与 AI 调用均记录日志；日志不得由普通管理员随意删除。</p>
      </div>
      <div class="card card-pad mb12">
        <div class="filter-bar">
          <select class="input" id="log-filter">
            <option value="all" ${filter==='all'?'selected':''}>全部级别</option>
            <option value="info" ${filter==='info'?'selected':''}>信息</option>
            <option value="warn" ${filter==='warn'?'selected':''}>警告</option>
          </select>
          <input class="input" id="log-kw" placeholder="搜索操作 / 对象" style="min-width:180px">
          <div style="flex:1"></div>
          <button class="btn btn-soft btn-sm" id="log-export">⬇ 导出基础数据</button>
        </div>
      </div>
      <div class="table-wrap">
        <table class="data">
          <tr><th>时间</th><th>操作者</th><th>操作</th><th>对象</th><th>详情</th><th>级别</th></tr>
          ${list.map(l => `
          <tr>
            <td class="small num">${l.time}</td>
            <td class="small">${l.user}</td>
            <td class="small">${l.action}</td>
            <td class="small">${l.target}</td>
            <td class="small" style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(l.detail)}">${esc(l.detail)}</td>
            <td>${badge(l.level==='warn'?'警告':'信息', l.level==='warn'?'amber':'gray')}</td>
          </tr>`).join('')}
        </table>
      </div>`;
    }
    function paint() { appEl.querySelector('.staff-content').innerHTML = body(); wire(); }
    function wire() {
      const root = appEl.querySelector('.staff-content');
      root.querySelector('#log-filter').addEventListener('change', e => { filter = e.target.value; paint(); });
      const kw = root.querySelector('#log-kw');
      kw.addEventListener('input', () => { kw._v = kw.value; });
      root.querySelector('#log-export').addEventListener('click', () => {
        toast('导出任务已创建：导出操作者、范围与时间已记录日志', 'success');
      });
    }
    renderStaffShell(body(), 'admin', 'logs');
    wire();
  },
};
