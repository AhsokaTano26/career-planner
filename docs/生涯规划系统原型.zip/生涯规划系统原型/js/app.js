/* ============================================================
   生涯规划系统 · MVP 原型 —— 应用内核
   状态管理 / 路由 / 认证 / 壳层 / 业务逻辑
   ============================================================ */

/* ---------- 状态 ---------- */
const LS_KEY = 'career_proto_v2';

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) { /* ignore */ }
  return defaultState();
}
let App = { state: loadState() };
function save() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(App.state)); } catch (e) { /* ignore */ }
}
function resetDemo() {
  localStorage.removeItem(LS_KEY);
  App.state = defaultState();
  save();
  toast('演示数据已重置', 'success');
}

/* ---------- 路由 ---------- */
function navigate(path) {
  if (location.hash === '#' + path) { renderRoute(); return; }
  location.hash = path;
}
function currentPath() {
  return (location.hash.replace(/^#/, '') || '/login').split('?')[0];
}
function matchRoute(path) {
  for (const pattern of Object.keys(routeDefs)) {
    const pSegs = pattern.split('/').filter(Boolean);
    const aSegs = path.split('/').filter(Boolean);
    if (pSegs.length !== aSegs.length) continue;
    const params = {}; let ok = true;
    for (let i = 0; i < pSegs.length; i++) {
      if (pSegs[i].startsWith(':')) params[pSegs[i].slice(1)] = decodeURIComponent(aSegs[i]);
      else if (pSegs[i] !== aSegs[i]) { ok = false; break; }
    }
    if (ok) return { pattern, handler: routeDefs[pattern], params };
  }
  return null;
}

const PUBLIC_PATHS = ['/login', '/register', '/privacy', '/403', '/404'];

function guard(path) {
  const role = App.state.session.role;
  if (PUBLIC_PATHS.includes(path)) return null;
  if (!role) return '/login';
  if (path.startsWith('/student') && role !== 'student') return '/403';
  if (path.startsWith('/advisor') && role !== 'advisor') return '/403';
  if (path.startsWith('/admin') && role !== 'admin') return '/403';
  return null;
}

function renderRoute() {
  const path = currentPath();
  const redirect = guard(path);
  if (redirect) { location.hash = redirect; return; }
  const m = matchRoute(path);
  if (!m) { location.hash = '/404'; return; }
  const { handler, params } = m;
  const appEl = document.getElementById('app');
  appEl.innerHTML = '';
  try {
    handler(appEl, params);
  } catch (err) {
    console.error(err);
    appEl.innerHTML = `<div class="staff-content"><div class="card card-pad"><h3>页面渲染异常</h3><p class="muted">${esc(err.message)}</p></div></div>`;
  }
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', renderRoute);

/* ---------- 图标库 ---------- */
const ICONS = {
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 10.5 12 3l9 7.5M5 9.5V21h14V9.5"/></svg>',
  radar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 20 8v8l-8 5-8-5V8z"/><circle cx="12" cy="12" r="3"/></svg>',
  compass: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/></svg>',
  plan: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 9h18M7 14h4M7 17h7"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a8 8 0 0 1-11.5 7.2L4 21l1.8-5.5A8 8 0 1 1 21 12z"/></svg>',
  users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.7-3.5 3.3-5.5 6.5-5.5s5.8 2 6.5 5.5"/><circle cx="17.5" cy="9" r="2.5"/><path d="M16 15c2.6.3 4.6 2 5.2 5"/></svg>',
  comments: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 8.8 8.8 0 0 1-3.6-.7L3 21l1.8-5.4A8.4 8.4 0 1 1 21 11.5z"/><path d="M8 10h8M8 13.5h5"/></svg>',
  stats: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 20V4M4 20h16"/><path d="m7 15 4-4 3 3 5-6"/></svg>',
  whitelist: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
  form: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 9h3M8 13h6M8 17h4"/></svg>',
  dirs: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M6 8.5V14c0 1 .5 2 2 2h7.5"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 5.5v15M8 7h8"/></svg>',
  tag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 12 9-9h6l3 3v6l-9 9z"/><circle cx="15" cy="9" r="1.6"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
  cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/></svg>',
  log: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5h16M4 12h16M4 19h10"/><circle cx="19" cy="19" r="2.5"/></svg>',
  logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 12H4M4 12l4-4M4 12l4 4M9 4h10v16H9"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M5 12l6-6M5 12l6 6"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 3 2.7 5.6 6.1.8-4.5 4.2 1.2 6-5.5-3-5.5 3 1.2-6-4.5-4.2 6.1-.8z"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v5M12 16v5M3 12h5M16 12h5M5.6 5.6l3.5 3.5M14.9 14.9l3.5 3.5M5.6 18.4l3.5-3.5M14.9 9.1l3.5-3.5"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
};

/* ---------- 三轨生涯路径图（签名元素） ---------- */
function pathMapSVG(compact=false) {
  const lanes = [
    { y: 34, color:'#0E5A6D', name:'国内升学', sub:'考研 · 保研 · 读研深造' },
    { y: 104, color:'#C67B34', name:'就业', sub:'软件 · 互联网 · 数据分析' },
    { y: 174, color:'#3B6EA5', name:'出国留学', sub:'海外 CS · 数据科学硕士' },
  ];
  const H = 208, W = 560;
  let out = `<svg viewBox="0 0 ${W} ${H}" fill="none" class="pathmap" aria-label="三条生涯发展路径">`;
  // 起点
  out += `<circle cx="30" cy="${H/2}" r="11" fill="#23313B"/><circle cx="30" cy="${H/2}" r="4" fill="#fff"/>`;
  // 连接曲线
  lanes.forEach((l, i) => {
    const dy = l.y - H/2;
    const ctrl1 = 90, ctrl2 = 130;
    if (i === 1) {
      out += `<path d="M42 ${H/2} H ${ctrl2}" stroke="${l.color}" stroke-width="2.5"/>`;
    } else {
      out += `<path d="M42 ${H/2} C ${ctrl1} ${H/2}, ${ctrl1} ${l.y}, ${ctrl2} ${l.y}" stroke="${l.color}" stroke-width="2.5" opacity=".85"/>`;
    }
  });
  // 轨线 + 站点
  lanes.forEach(l => {
    out += `<line x1="140" y1="${l.y}" x2="${W-28}" y2="${l.y}" stroke="${l.color}" stroke-width="2" stroke-dasharray="4 7" opacity=".5"/>`;
    out += `<g>`;
    out += `<rect x="140" y="${l.y-26}" width="${W-168}" height="52" rx="15" fill="${l.color}" fill-opacity=".08" stroke="${l.color}" stroke-width="1.2"/>`;
    out += `<circle cx="164" cy="${l.y}" r="11" fill="${l.color}"/><circle cx="164" cy="${l.y}" r="3.5" fill="#fff"/>`;
    out += `<text x="184" y="${l.y-1}" font-size="14.5" font-weight="700" fill="#23313B" font-family="'Noto Sans SC',sans-serif">${l.name}</text>`;
    out += `<text x="184" y="${l.y+17}" font-size="11" fill="#6E7B85" font-family="'Noto Sans SC',sans-serif">${l.sub}</text>`;
    out += `<text x="${W-44}" y="${l.y+4}" font-size="17" fill="${l.color}" text-anchor="middle" font-weight="800">›</text>`;
    out += `</g>`;
  });
  out += `</svg>`;
  return out;
}

/* ============================================================
   认证视图
   ============================================================ */
const AuthViews = {
  login(appEl) {
    const s = App.state;
    let roleTab = s.session.role || 'student';
    const view = h(`
    <div class="auth-wrap">
      <div class="auth-inner">
        <div class="auth-hero">
          <div class="ah-brand">
            <div class="ah-logo">涯</div>
            <div><div style="font-weight:800;font-size:16px">生涯规划系统</div>
            <div style="font-size:11.5px;color:var(--muted)">计算机与软件大类新生 · MVP 试用版</div></div>
          </div>
          <h1>把方向的探索，<br>变成<em>可执行的学期计划</em></h1>
          <p class="ah-sub">通过结构化测评认识自己，在三条发展路径中找到 3—5 个可解释的备选方向，并逐步转化为目标、计划与阶段复盘。</p>
          <div class="ah-pathmap">${pathMapSVG()}</div>
        </div>
        <div class="auth-card">
          <div class="ac-title">登录</div>
          <div class="ac-sub">本原型使用浏览器本地数据，仅作交互演示</div>
          <div class="seg" style="width:100%;margin-bottom:18px">
            ${['student','advisor','admin'].map(r => `<button data-role="${r}" class="${roleTab===r?'active':''}">${({student:'学生',advisor:'辅导员',admin:'管理员'})[r]}</button>`).join('')}
          </div>
          <div class="field">
            <label for="login-id">学号 / 工号</label>
            <input class="input" id="login-id" placeholder="如 2026011301" value="${roleTab==='student'?'2026011301':roleTab==='advisor'?'A2001':'M3001'}">
          </div>
          <div class="field">
            <label for="login-pwd">密码</label>
            <input class="input" id="login-pwd" type="password" placeholder="演示账号密码 123456" value="123456">
          </div>
          <button class="btn btn-primary btn-lg btn-block" id="login-btn">登 录</button>
          <div class="row" style="margin-top:16px;justify-content:space-between;font-size:13px">
            <a href="#/register">白名单学号注册</a>
            <button style="border:none;background:none;color:var(--muted);font-size:13px;text-decoration:underline" id="reset-demo">重置演示数据</button>
          </div>
          <div style="margin-top:20px;padding-top:16px;border-top:1px dashed var(--line-2)">
            <div style="font-size:12px;color:var(--muted);margin-bottom:8px">演示账号 · 一键进入</div>
            <div class="row gap8 wrap" id="quick-roles">
              <button class="btn btn-soft btn-sm" data-r="student">👨‍🎓 学生 · 李明</button>
              <button class="btn btn-soft btn-sm" data-r="advisor">👩‍🏫 辅导员 · 王老师</button>
              <button class="btn btn-soft btn-sm" data-r="admin">🛠️ 管理员</button>
            </div>
          </div>
        </div>
      </div>
    </div>`);

    const tabEls = view.querySelectorAll('.seg button');
    tabEls.forEach(b => b.addEventListener('click', () => {
      roleTab = b.dataset.role;
      tabEls.forEach(x => x.classList.toggle('active', x === b));
      const id = view.querySelector('#login-id');
      id.value = roleTab === 'student' ? '2026011301' : roleTab === 'advisor' ? 'A2001' : 'M3001';
    }));
    view.querySelector('#quick-roles').querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => doLogin(b.dataset.r));
    });
    view.querySelector('#login-btn').addEventListener('click', () => {
      const acc = MOCK_ACCOUNTS.find(a => a.role === roleTab);
      if (!acc) { toast('该角色暂无演示账号', 'error'); return; }
      doLogin(roleTab);
    });
    view.querySelector('#reset-demo').addEventListener('click', resetDemo);
    function doLogin(role) {
      App.state.session = { role, uid: MOCK_ACCOUNTS.find(a => a.role === role)?.uid || null };
      save();
      toast(`已登录：${({student:'学生',advisor:'辅导员',admin:'管理员'})[role]}`, 'success');
      navigate(role === 'student' ? '/student/home' : role === 'advisor' ? '/advisor/dashboard' : '/admin/users');
    }
    appEl.appendChild(view);
  },

  register(appEl) {
    const view = h(`
    <div class="auth-wrap"><div class="auth-inner" style="grid-template-columns:1fr">
      <div style="max-width:480px;margin:0 auto;width:100%">
        <a href="#/login" class="btn btn-paper btn-sm" style="margin-bottom:16px">${ICONS.back} 返回登录</a>
        <div class="auth-card">
          <div class="ac-title">白名单学号注册</div>
          <div class="ac-sub">仅限辅导员已导入白名单的学号注册，非白名单无法注册</div>
          <div class="field"><label for="reg-no">学号</label><input class="input" id="reg-no" placeholder="如 2026011309"></div>
          <div class="field"><label for="reg-name">姓名</label><input class="input" id="reg-name" placeholder="你的真实姓名"></div>
          <div class="field"><label for="reg-code">初始校验码</label><input class="input" id="reg-code" placeholder="白名单中的初始校验信息"></div>
          <div class="field"><label for="reg-pwd">设置密码</label><input class="input" type="password" id="reg-pwd" placeholder="至少 8 位"></div>
          <button class="btn btn-primary btn-lg btn-block" id="reg-btn">注册</button>
          <div class="row mt12" style="font-size:13px">
            <a href="#/login">已有账号？去登录</a>
          </div>
        </div>
      </div>
    </div></div>`);
    view.querySelector('#reg-btn').addEventListener('click', () => {
      const no = view.querySelector('#reg-no').value.trim();
      const item = MOCK_WHITELIST.find(w => w.studentNo === no && !w.used);
      if (!item) { toast('该学号不在白名单或已注册', 'error'); return; }
      const code = view.querySelector('#reg-code').value.trim();
      if (code !== item.verifyCode) { toast('初始校验码不匹配', 'error'); return; }
      const name = view.querySelector('#reg-name').value.trim();
      if (!name) { toast('请填写姓名', 'error'); return; }
      // 标记白名单已使用，创建全新学生会话，进入首登隐私授权流程
      item.used = true; item.status = '已注册';
      App.state.student = freshStudent(item.studentNo, name, item.className);
      App.state.session = { role:'student', uid: App.state.student.user.id };
      save();
      toast('注册成功，首次登录需完成隐私授权', 'success');
      setTimeout(() => navigate('/privacy'), 700);
    });
    appEl.appendChild(view);
  },

  privacy(appEl) {
    const view = h(`
    <div class="auth-wrap"><div class="auth-inner" style="grid-template-columns:1fr">
      <div style="max-width:560px;margin:0 auto;width:100%">
        <div class="auth-card">
          <div class="ac-title">隐私告知与 AI 使用说明</div>
          <div class="ac-sub">首次使用前需阅读并同意，未同意不进入测评与规划流程</div>
          <div class="prose">
            <h3>一、我们收集什么</h3>
            <p>仅采集完成生涯规划所需的最基本信息：学号、专业大类、学业基础自评、兴趣偏好、能力自评、职业价值观、实践经历与发展意向。不采集心理健康、疾病、家庭收入等敏感信息。</p>
            <h3>二、AI 如何使用你的数据</h3>
            <p>AI 服务调用前会对数据进行<strong>去标识化与最小化</strong>处理：姓名、学号、手机号、邮箱等直接标识信息<strong>不会</strong>发送至公网大模型。所有 AI 生成内容标识"智能生成，供探索参考"，不构成结论性判断。</p>
            <h3>三、你的权利</h3>
            <p>你可随时查看、更正本人的填报信息，并可申请删除；查看、导出与 AI 调用行为均记录审计日志。</p>
            <div class="legal-box">授权文本版本：privacy-consent v1.0（2026-08-01）· 本项目面向在校本科生试用，数据保存在项目控制的数据库中。</div>
          </div>
          <div class="row gap8 mt16" style="justify-content:flex-end">
            <button class="btn btn-paper" id="priv-no">暂不同意</button>
            <button class="btn btn-primary" id="priv-yes">我已知晓并同意</button>
          </div>
        </div>
      </div>
    </div></div>`);
    view.querySelector('#priv-no').addEventListener('click', () => { toast('未同意前无法进入测评与规划', 'error'); });
    view.querySelector('#priv-yes').addEventListener('click', () => {
      const s = App.state.student;
      s.consent = { version:'privacy-consent v1.0', agreedAt: nowFull() };
      save();
      toast('授权已记录', 'success');
      navigate('/student/home');
    });
    appEl.appendChild(view);
  },

  _403(appEl) {
    appEl.appendChild(h(`<div class="auth-wrap"><div class="empty" style="max-width:420px;width:100%">
      <div class="e-icon">🚫</div><div class="e-title">无权访问该页面</div>
      <div class="e-sub">当前角色没有该模块的权限，请联系管理员或切换角色。</div>
      <div class="row gap8 mt16" style="justify-content:center"><button class="btn btn-primary btn-sm" id="g-home">返回我的工作台</button></div>
    </div></div>`)).querySelector('#g-home').addEventListener('click', () => navigate(roleHome(App.state.session.role)));
  },

  _404(appEl) {
    appEl.appendChild(h(`<div class="auth-wrap"><div class="empty" style="max-width:420px;width:100%">
      <div class="e-icon">🧭</div><div class="e-title">页面走丢了</div>
      <div class="e-sub">你访问的地址不存在，可能已改版。</div>
      <div class="row gap8 mt16" style="justify-content:center"><button class="btn btn-primary btn-sm" id="g-home">返回首页</button></div>
    </div></div>`)).querySelector('#g-home').addEventListener('click', () => navigate(roleHome(App.state.session.role)));
  },
};

function roleHome(role) {
  return role === 'student' ? '/student/home' : role === 'advisor' ? '/advisor/dashboard' : '/admin/users';
}

/* ============================================================
   壳层：学生端
   ============================================================ */
function renderStudentShell(contentHtml, activeTab) {
  const s = App.state.student;
  const appEl = document.getElementById('app');
  const tabs = [
    { key:'home',  label:'首页', icon:ICONS.home,  path:'/student/home' },
    { key:'portrait', label:'画像', icon:ICONS.radar, path:'/student/portrait' },
    { key:'plan',  label:'计划', icon:ICONS.plan,  path:'/student/plan' },
    { key:'directions', label:'方向', icon:ICONS.compass, path:'/student/directions' },
    { key:'ai',    label:'AI咨询', icon:ICONS.chat, path:'/student/ai-chat' },
  ];
  const needDot = ['portrait','plan'].includes(activeTab) && !s.portrait && !s.plan;
  const shell = h(`
  <div class="stage-student">
    <div class="app-frame">
      <header class="st-appbar">
        <div class="row between">
          <div class="brand-row">
            <div class="st-brand">涯<small></small></div>
            <div>
              <div style="font-weight:700;font-size:14.5px">${esc(s.user.name)}</div>
              <div style="font-size:11px;color:var(--muted)">${esc(s.user.studentNo)} · ${esc(s.user.className)}</div>
            </div>
          </div>
          <div class="who">
            <button class="btn btn-paper btn-sm" data-act="consent" style="margin-right:2px">隐私</button>
            <button class="btn btn-paper btn-icon" data-act="logout" aria-label="退出登录" style="margin-right:-6px">${ICONS.logout}</button>
          </div>
        </div>
      </header>
      <main>${contentHtml}</main>
    </div>
    <nav class="st-tabbar"><div class="inner">
      ${tabs.map(t => `<button class="st-tab ${t.key===activeTab?'active':''}" data-path="${t.path}">
        <span class="${needDot?'dot-badge':''}">${t.icon}</span><span>${t.label}</span></button>`).join('')}
    </div></nav>
  </div>`);
  shell.querySelectorAll('.st-tab').forEach(b => b.addEventListener('click', () => navigate(b.dataset.path)));
  shell.querySelector('[data-act="logout"]').addEventListener('click', () => {
    App.state.session = { role:null, uid:null }; save(); navigate('/login'); toast('已退出登录');
  });
  shell.querySelector('[data-act="consent"]').addEventListener('click', () => showConsentSheet());
  appEl.appendChild(shell);
}

function showConsentSheet() {
  const s = App.state.student;
  modal({
    title: '隐私告知 · 授权记录',
    body: h(`<div class="prose" style="font-size:13.5px">
      <p><strong>授权版本：</strong>${esc(s.consent.version || '未授权')}</p>
      <p><strong>同意时间：</strong>${esc(s.consent.agreedAt || '—')}</p>
      <p>数据将去标识化后调用 AI 服务；姓名、学号等直接标识信息不会发送至公网模型。</p>
      <p>你可随时查看与更正本人填报信息。</p>
    </div>`),
    foot: ft => ft.append(h(`<button class="btn btn-primary btn-sm">我知道了</button>`, {})),
  });
}

/* ============================================================
   壳层：辅导员 / 管理端
   ============================================================ */
function renderStaffShell(contentHtml, role, activeKey) {
  const nav = role === 'advisor' ? [
    { key:'dashboard',   label:'工作总览',   icon:ICONS.home,     path:'/advisor/dashboard' },
    { key:'students',    label:'学生列表',   icon:ICONS.users,    path:'/advisor/students' },
    { key:'comments',    label:'指导意见',   icon:ICONS.comments, path:'/advisor/comments' },
    { key:'statistics',  label:'群体统计',   icon:ICONS.stats,    path:'/advisor/statistics' },
  ] : [
    { key:'users',         label:'用户与白名单', icon:ICONS.whitelist, path:'/admin/users' },
    { key:'questionnaires',label:'问卷管理',    icon:ICONS.form,       path:'/admin/questionnaires' },
    { key:'directions',    label:'方向库',      icon:ICONS.dirs,       path:'/admin/directions' },
    { key:'curricula',     label:'培养方案',    icon:ICONS.book,       path:'/admin/curricula' },
    { key:'abilities',     label:'能力标签',    icon:ICONS.tag,        path:'/admin/abilities' },
    { key:'templates',     label:'任务模板',    icon:ICONS.copy,       path:'/admin/templates' },
    { key:'models',        label:'模型与提示词', icon:ICONS.cpu,       path:'/admin/models' },
    { key:'logs',          label:'审计日志',    icon:ICONS.log,        path:'/admin/logs' },
  ];
  const me = MOCK_ACCOUNTS.find(a => a.uid === App.state.session.uid) || {};
  const roleName = role === 'advisor' ? '辅导员工作台' : '管理端工作台';
  const title = nav.find(n => n.key === activeKey);
  const shell = h(`
  <div class="staff-layout">
    <aside class="staff-side">
      <div class="side-brand">
        <div class="sb-logo">涯</div>
        <div><div class="sb-name">生涯规划系统</div><div class="sb-sub">MVP 试用版</div></div>
      </div>
      <div class="side-group">${roleName}</div>
      ${nav.map(n => `<button class="side-link ${n.key===activeKey?'active':''}" data-path="${n.path}">${n.icon}<span>${n.label}</span></button>`).join('')}
      <div class="side-foot">
        <div style="font-weight:600;color:#fff;margin-bottom:2px">${esc(me.name || '')}</div>
        <div>${esc(me.dept || '系统管理员')}</div>
        <button style="margin-top:8px;border:none;background:rgba(255,255,255,.1);color:#fff;border-radius:8px;padding:5px 12px;font-size:12px" data-act="logout">退出登录</button>
      </div>
    </aside>
    <div class="staff-main">
      <div class="staff-top">
        <div class="st-title">${title ? title.label : ''}<span class="st-role">${role === 'advisor' ? '计算机学院' : '系统配置'}</span></div>
        <div class="row gap8">
          <button class="btn btn-paper btn-sm" data-act="reset">重置演示</button>
          <span class="badge badge-teal">已登录</span>
        </div>
      </div>
      <div class="staff-content">${contentHtml}</div>
    </div>
  </div>`);
  shell.querySelectorAll('.side-link').forEach(b => b.addEventListener('click', () => navigate(b.dataset.path)));
  shell.querySelector('[data-act="logout"]').addEventListener('click', () => { App.state.session={role:null,uid:null}; save(); navigate('/login'); toast('已退出登录'); });
  shell.querySelector('[data-act="reset"]').addEventListener('click', resetDemo);
  document.getElementById('app').appendChild(shell);
}

/* ============================================================
   业务逻辑：测评计分 / 画像 / 推荐 / 计划
   ============================================================ */
const AppCore = {
  // 从 questionnaire answers 计算六维得分（确定性规则，不依赖大模型）
  computeScores(answers) {
    const acc = { interest:0, values:0, ability:0, academic:0, tendency:0 };
    const cnt = { interest:0, values:0, tendency:0 };
    const rating = { programming:0, math:0, english:0, communication:0, organization:0 };
    let ratingCnt = 0;

    for (const qid in answers) {
      const val = answers[qid];
      if (val === null || val === undefined) continue;
      if (typeof val === 'object') {
        // rating: {programming: 4}
        for (const k in val) if (k in rating) { rating[k] = val[k]; ratingCnt++; }
        continue;
      }
      // 按选项文本匹配题目选项（确定性规则）
      let opt = null;
      for (const qz of QUESTIONNAIRES) {
        for (const q of qz.questions) {
          const o = (q.options || []).find(o => o.text === val);
          if (o) { opt = o; break; }
        }
        if (opt) break;
      }
      if (opt && opt.scores) {
        for (const dim in opt.scores) {
          acc[dim] = (acc[dim] || 0) + opt.scores[dim];
          if (dim in cnt) cnt[dim] = (cnt[dim] || 0) + 1;
        }
      }
    }
    // 兴趣 / 价值观 / 倾向 → 归一化到 0-100
    const norm = (dim, maxPerQ=5) => {
      const total = cnt[dim] * maxPerQ;
      return total ? Math.round(acc[dim] / total * 100) : 0;
    };
    const interest = norm('interest');
    const values = norm('values');
    const tendency = norm('tendency', 8); // 倾向题选项分值最大 8

    // 能力 & 学业基础：来自自评（5 分制 → 百分制）
    const to100 = v => Math.round((v - 1) / 4 * 100);
    const ability = ratingCnt ? Math.round(
      (to100(rating.programming) + to100(rating.math) + to100(rating.english) + to100(rating.communication) + to100(rating.organization)) / 5
    ) : 0;
    // 学业基础主要由数学/英语/编程自评构成
    const academic = ratingCnt ? Math.round(
      (to100(rating.math) * 0.4 + to100(rating.english) * 0.3 + to100(rating.programming) * 0.3)
    ) : 0;

    return {
      interest: Math.max(4, interest),
      values: Math.max(4, values),
      tendency: Math.max(4, tendency),
      ability: Math.max(4, ability),
      academic: Math.max(4, academic),
      practice: practiceScore(App.state.student.profile.experiences || []),
    };
  },

  // 生成画像快照
  generatePortrait(scores, profile) {
    const strengths = [], explore = [];
    const dimName = { interest:'兴趣', values:'职业价值观', ability:'能力基础', academic:'学业基础', tendency:'发展倾向', practice:'实践经历' };
    const sorted = Object.entries(scores).sort((a,b) => b[1]-a[1]);
    const top = sorted.slice(0,2), low = sorted.slice(-2);
    top.forEach(([k,v]) => { if (v >= 60) strengths.push(`${dimName[k]}较强（${v} 分），是当前优势维度`); });
    low.forEach(([k,v]) => { if (v < 60) explore.push(`${dimName[k]}尚在起步（${v} 分），建议作为探索重点`); });
    if (!strengths.length) strengths.push('各维度相对均衡，建议结合兴趣与课程进一步探索');
    const devName = { employment:'就业', graduate:'国内升学', overseas:'出国留学' };
    const summary = `你的画像显示：兴趣偏${scores.interest>=60?'技术探索与动手实践':'多面发展'}，职业价值观${scores.values>=60?'倾向成长与挑战':'倾向稳健'}，能力基础${scores.ability>=60?'较好':'仍在积累'}，发展倾向暂定为「${devName[profile.developmentIntention] || '待探索'}」。`;
    return {
      version: 2, generatedAt: nowFull(),
      sourceVersion: '问卷 v2 + 自主填报 v3',
      summary, strengths, explore,
      completeness: profile.complete || 70,
      feedback: null,
    };
  },

  // 推荐引擎：规则过滤 + 结构化评分
  runRecommendation(scores, profile) {
    const devPath = profile.developmentIntention;
    // 规则过滤：按发展倾向过滤候选方向
    let candidates = DIRECTIONS.filter(d => d.status === 'published');
    if (devPath && PATHS[devPath]) {
      const fav = App.state.student.favorites || [];
      const inPath = candidates.filter(d => d.path === devPath);
      if (inPath.length) candidates = inPath.concat(candidates.filter(d => fav.includes(d.id) && d.path !== devPath));
    }
    // 必要条件过滤（能力低于最低要求 → 不否决但计入差距；这里仅过滤停用）
    candidates = candidates.filter(d => d.status === 'published');

    const results = candidates.map(d => {
      let score = 0;
      const reasons = [], strengths = [], gaps = [];
      DIMS.forEach(dim => {
        const studentV = scores[dim.key];
        const targetV = d.target[dim.key];
        const match = Math.max(0, 1 - Math.abs(studentV - targetV) / 100);
        score += dim.weight * match;
        // 生成理由
        if (dim.key === 'interest' && studentV >= 65) reasons.push('兴趣特征与方向的技术探索属性契合');
        if (dim.key === 'values' && studentV >= 60) reasons.push('职业价值观与方向回报特征匹配');
        if (dim.key === 'academic' && studentV >= 65) reasons.push('学业基础（数学/英语）符合方向要求');
        if (dim.key === 'tendency' && studentV >= 60) reasons.push('发展倾向与该路径方向一致');
      });
      // 差距
      if (scores.ability < d.minAbility) gaps.push(`编程/技术能力低于方向建议值（当前 ${scores.ability}，建议 ${d.minAbility}+）`);
      if (scores.academic < d.minAcademic) gaps.push(`学业基础低于方向建议（当前 ${scores.academic}，建议 ${d.minAcademic}+）`);
      if (!reasons.length) reasons.push('各维度与方向需求较为匹配');
      if (!strengths.length) strengths.push(scores.ability >= 60 ? '能力基础较好，具备入门条件' : '兴趣与学习意愿是该方向的有利因素');
      if (!gaps.length) gaps.push('当前数据未发现明显短板');
      return {
        directionId: d.id, name: d.name, path: d.path, icon: d.icon, targetScore: Math.round(score * 100),
        reasons: reasons.slice(0,3), strengths: strengths.slice(0,3), gaps: gaps.slice(0,3),
        semesterActions: d.activities.slice(0,2),
      };
    }).sort((a,b) => b.targetScore - a.targetScore);

    // 可信程度
    let confidence = 'LOW';
    const completeness = profile.complete || 70;
    if (completeness >= 80 && results[0] && results[1] && (results[0].targetScore - results[1].targetScore) >= 5) confidence = 'HIGH';
    else if (completeness >= 60) confidence = 'MEDIUM';
    return {
      runId: '19000' + Math.floor(Math.random()*9 + 1),
      ruleVersion: 'R1.0', profileVersion: 2,
      generatedAt: nowFull(),
      confidence, results: results.slice(0,4),
    };
  },

  // 生成学期计划草案
  generatePlan(directionId) {
    const tpl = PLAN_TEMPLATES[directionId];
    const dir = DIRECTIONS.find(d => d.id === directionId);
    if (!tpl || !dir) return null;
    return {
      source: 'ai', confirmed: false, version: 'P-v1',
      goalSummary: tpl.goalSummary,
      semesterGoals: tpl.semesterGoals,
      monthlyTasks: tpl.monthlyTasks,
      notes: tpl.notes,
    };
  },

  // 依据计划生成任务看板
  buildTasksFromPlan(plan) {
    return plan.monthlyTasks.map((t, i) => ({
      id: 'T' + (i + 1), month: t.month, title: t.title, type: t.taskType,
      estHours: t.estimatedHours, status: 'pending', checkedInAt: null, note: null,
    }));
  },

  // AI 咨询回复（本地知识库匹配，模拟流式）
  aiReply(text) {
    const t = text.trim();
    for (const item of AI_KB) {
      if (item.k.some(k => t.includes(k))) return { text: item.r, esc: !!item.esc };
    }
    return { text: '这是一个好的探索问题。建议你先完成测评查看六维画像，再从"方向"页浏览三条路径下的方向卡片；如果希望对比具体方向，告诉我你想比较哪两个方向。你也可以问关于专业认知、升学/就业/留学比较、学习安排和计划优化的问题。' };
  },
};

// 实践经历得分
function practiceScore(experiences) {
  const n = (experiences || []).length;
  if (n >= 3) return 80;
  if (n === 2) return 62;
  if (n === 1) return 45;
  return 22;
}

/* ---------- 路由表 ---------- */
const routeDefs = {
  '/login': (el) => AuthViews.login(el),
  '/register': (el) => AuthViews.register(el),
  '/privacy': (el) => AuthViews.privacy(el),
  '/403': (el) => AuthViews._403(el),
  '/404': (el) => AuthViews._404(el),
  '/student/home': (el) => StudentViews.home(el),
  '/student/profile': (el) => StudentViews.profile(el),
  '/student/assessment': (el) => StudentViews.assessment(el),
  '/student/portrait': (el) => StudentViews.portrait(el),
  '/student/directions': (el) => StudentViews.directions(el),
  '/student/directions/:id': (el, p) => StudentViews.directionDetail(el, p),
  '/student/recommendations': (el) => StudentViews.recommendations(el),
  '/student/goals': (el) => StudentViews.goals(el),
  '/student/plan': (el) => StudentViews.plan(el),
  '/student/tasks': (el) => StudentViews.tasks(el),
  '/student/reviews': (el) => StudentViews.reviews(el),
  '/student/ai-chat': (el) => StudentViews.aiChat(el),
  '/advisor/dashboard': (el) => StaffViews.advisorDashboard(el),
  '/advisor/students': (el) => StaffViews.advisorStudents(el),
  '/advisor/student/:id': (el, p) => StaffViews.advisorStudentDetail(el, p),
  '/advisor/comments': (el) => StaffViews.advisorComments(el),
  '/advisor/statistics': (el) => StaffViews.advisorStatistics(el),
  '/admin/users': (el) => StaffViews.adminUsers(el),
  '/admin/questionnaires': (el) => StaffViews.adminQuestionnaires(el),
  '/admin/directions': (el) => StaffViews.adminDirections(el),
  '/admin/curricula': (el) => StaffViews.adminCurricula(el),
  '/admin/abilities': (el) => StaffViews.adminAbilities(el),
  '/admin/templates': (el) => StaffViews.adminTemplates(el),
  '/admin/models': (el) => StaffViews.adminModels(el),
  '/admin/logs': (el) => StaffViews.adminLogs(el),
};

/* ---------- 启动 ---------- */
document.addEventListener('DOMContentLoaded', () => {
  // 学生首次登录隐私门禁
  const path = currentPath();
  if (App.state.session.role === 'student' && path.startsWith('/student') && !App.state.student.consent.agreedAt) {
    location.hash = '/privacy';
    renderRoute();
    return;
  }
  renderRoute();
});
