/* ============================================================
   生涯规划系统 · MVP 原型 —— 模拟数据层
   ============================================================ */

// 六维画像维度（与推荐权重一致）
const DIMS = [
  { key:'interest',  name:'兴趣',      weight:0.20 },
  { key:'values',    name:'职业价值观', weight:0.15 },
  { key:'ability',   name:'能力基础',  weight:0.25 },
  { key:'academic',  name:'学业基础',  weight:0.15 },
  { key:'tendency',  name:'发展倾向',  weight:0.20 },
  { key:'practice',  name:'实践经历',  weight:0.05 },
];

const PATHS = {
  graduate:  { id:'graduate',  name:'国内升学', short:'升学', color:'#0E5A6D', desc:'考研 / 保研 / 攻读计算机相关研究生' },
  employment:{ id:'employment',name:'就业',     short:'就业', color:'#C67B34', desc:'进入软件、互联网等行业岗位' },
  overseas:  { id:'overseas',  name:'出国留学', short:'留学', color:'#3B6EA5', desc:'申请海外计算机 / 数据科学方向硕士' },
};

// 方向库（每条路径 3 个方向，含六维目标值与完整内容）
const DIRECTIONS = [
  {
    id:'graduate_cs', name:'计算机技术考研', path:'graduate', icon:'🎓',
    intro:'面向国内计算机科学与技术及相关学科的硕士培养，考研/保研是本科新生最常见的升学通道之一。',
    target:{ interest:60, values:60, ability:65, academic:85, tendency:75, practice:45 },
    minAbility:50, minAcademic:70,
    learning:['高等数学、线性代数与概率论','数据结构与算法','计算机组成原理、操作系统','计算机网络','英语与思想政治理论'],
    abilities:['数理逻辑','算法思维','英语阅读','抗压与自律'],
    courses:['《数据结构》《计算机组成原理》《操作系统》','《高等数学》《线性代数》','四六级 / 考研英语'],
    activities:['参加 ACM / 程序设计竞赛','参加数学建模竞赛','加入实验室参与导师课题','寒暑假系统复习数学与英语'],
    pathDesc:['大一大二：夯实数学与英语，选修数据结构','大二下：确定目标院校与专业方向','大三：系统复习 + 真题训练','大四：初试 / 复试 / 录取'],
    misconceptions:['考研必须从大一就全力复习（应分阶段安排）','只有考不上研才去就业（两者可以并行准备）'],
    updated:'2026-07-30', status:'published',
  },
  {
    id:'graduate_ai', name:'人工智能方向深造', path:'graduate', icon:'🤖',
    intro:'聚焦机器学习、深度学习与数据科学的研究型方向，需要较强的数学与编程基础，适合对智能技术有长期兴趣的学生。',
    target:{ interest:75, values:55, ability:80, academic:80, tendency:75, practice:40 },
    minAbility:60, minAcademic:70,
    learning:['微积分、线性代数、概率统计','Python 与 NumPy / PyTorch','机器学习、深度学习基础','英语文献阅读'],
    abilities:['数学推导','编程实现','英语文献阅读','自主学习'],
    courses:['《机器学习》吴恩达系列 / 周志华《机器学习》','《深度学习》花书（选读）','《概率论与数理统计》'],
    activities:['完成 1—2 个 Kaggle / 天池入门赛','复现一篇经典论文的模型','参加 AI 方向的开放实验室','关注顶会与开源社区'],
    pathDesc:['大一大二：数学 + Python 基础','大二：机器学习理论 + 动手实践','大三：科研项目 / 竞赛 + 考研或保研','大四：申请院校'],
    misconceptions:['AI 方向只需要写代码（数学是底层基础）','必须上研究生才能接触 AI（本科也能做出入门项目）'],
    updated:'2026-07-28', status:'published',
  },
  {
    id:'employment_backend', name:'后端开发工程师', path:'employment', icon:'🖥️',
    intro:'面向软件系统的服务端设计、开发与运维，是软件行业需求量大、成长路径清晰的就业方向之一。',
    target:{ interest:80, values:70, ability:85, academic:70, tendency:70, practice:50 },
    minAbility:65, minAcademic:50,
    learning:['Java / Go / Python 服务端语言','数据结构与算法','数据库与 SQL','计算机网络与操作系统基础','Linux 与常用工具'],
    abilities:['编程实现','问题分解','逻辑严谨','团队协作'],
    courses:['《Java 程序设计》《数据库原理》','《数据结构与算法》','《计算机网络》','《操作系统》'],
    activities:['完成 1—2 个后端小项目并部署上线','参加开源项目贡献','参加蓝桥杯 / 程序设计竞赛','参与学校软件开发类社团或工作室'],
    pathDesc:['大一大二：打好编程与数据结构基础','大二：掌握一门主流语言并做项目','大三：暑期实习 + 刷题','大四：秋招 / 校招'],
    misconceptions:['后端只会 CRUD 就够了（算法与工程能力同样重要）','必须先去大厂才有发展（成长比平台更重要）'],
    updated:'2026-07-31', status:'published',
  },
  {
    id:'employment_frontend', name:'前端开发工程师', path:'employment', icon:'🎨',
    intro:'负责 Web、移动端产品的界面交互与用户体验实现，技术栈更新快、上手路径相对平缓。',
    target:{ interest:65, values:65, ability:70, academic:55, tendency:70, practice:45 },
    minAbility:55, minAcademic:40,
    learning:['HTML / CSS / JavaScript / TypeScript','Vue / React 等框架','浏览器原理与工程化工具','Node.js 与数据请求'],
    abilities:['审美与交互感觉','编程实现','快速学习','沟通协作'],
    courses:['《JavaScript 高级程序设计》','Vue3 官方文档与实战','《网络是怎样连接的》'],
    activities:['把学到的页面做成可访问的小项目','临摹并重构优秀网站','参与校园网站或社团项目','关注前端周报与开源库'],
    pathDesc:['大一大二：HTML/CSS/JS 三件套','大二：框架 + 工程化','大三：实习 + 作品集','大四：秋招'],
    misconceptions:['前端比后端简单（前端同样需要算法与工程能力）','会写页面就算前端工程师（工程化与性能更重要）'],
    updated:'2026-07-29', status:'published',
  },
  {
    id:'data_analysis', name:'数据分析师', path:'employment', icon:'📊',
    intro:'面向业务数据采集、清洗、分析与可视化，连接业务与数据，是数据方向中入门相对友好、应用广泛的岗位。',
    target:{ interest:70, values:60, ability:75, academic:65, tendency:70, practice:40 },
    minAbility:55, minAcademic:50,
    learning:['SQL 与数据处理','Python（Pandas / Matplotlib）','统计学基础','业务分析框架与可视化'],
    abilities:['数据敏感度','逻辑分析','业务理解','表达呈现'],
    courses:['《SQL 必知必会》','《利用 Python 进行数据分析》','《统计学基础》'],
    activities:['完成 1 个真实数据集的分析报告','参加数据竞赛入门','为社团做数据可视化','学习 Excel 高级技巧'],
    pathDesc:['大一大二：Excel + SQL + 统计学','大二：Python 数据分析','大三：项目 + 实习','大四：秋招'],
    misconceptions:['数据分析只是画图表（核心是业务问题定义）','必须懂机器学习才能做分析（业务思维更重要）'],
    updated:'2026-07-27', status:'published',
  },
  {
    id:'software_testing', name:'软件测试工程师', path:'employment', icon:'🔍',
    intro:'负责软件质量保障，包括功能测试、自动化测试、性能测试与质量体系建设，软件工程中的重要一环。',
    target:{ interest:55, values:60, ability:65, academic:50, tendency:65, practice:35 },
    minAbility:50, minAcademic:40,
    learning:['软件测试基础与用例设计','自动化测试（Selenium / pytest）','接口测试与性能测试','SQL 与 Linux 基础'],
    abilities:['细心与耐心','逻辑严谨','沟通表达','工程工具使用'],
    courses:['《软件测试的艺术》','自动化测试实战','《计算机网络》'],
    activities:['为开源项目写测试用例','参与社团项目的质量保障','学习接口测试工具','了解主流测试平台'],
    pathDesc:['大一大二：软件基础 + 测试理论','大二：自动化测试工具','大三：项目实践 + 实习','大四：秋招'],
    misconceptions:['测试没有技术含量（自动化与质量体系很专业）','测试是开发的备选（两者是不同专业方向）'],
    updated:'2026-07-26', status:'published',
  },
  {
    id:'product_manager', name:'产品经理', path:'employment', icon:'🧭',
    intro:'负责需求分析、产品规划与团队协作，是连接技术、设计与业务的岗位，强调用户思维与沟通能力。',
    target:{ interest:60, values:70, ability:55, academic:45, tendency:70, practice:55 },
    minAbility:40, minAcademic:30,
    learning:['需求分析与用户研究','产品设计与原型工具','数据分析与 A/B 测试','项目管理与沟通'],
    abilities:['沟通表达','逻辑分析','同理心','组织协调'],
    courses:['《人人都是产品经理》（入门）','《俞军产品方法论》','交互设计基础'],
    activities:['参与或发起校园产品实践','撰写产品分析报告','运营个人项目 / 自媒体','参加产品经理比赛'],
    pathDesc:['大一大二：了解互联网业务与用户','大二：学习产品方法论','大三：实习 + 作品集','大四：秋招'],
    misconceptions:['产品经理不需要懂技术（懂技术是显著优势）','产品经理只是画原型（本质是决策与协作）'],
    updated:'2026-07-25', status:'published',
  },
  {
    id:'overseas_cs', name:'海外计算机硕士留学', path:'overseas', icon:'✈️',
    intro:'面向申请海外 CS 硕士项目的路径，重点关注 GPA、英语成绩、科研/实习经历与文书准备。',
    target:{ interest:70, values:65, ability:70, academic:85, tendency:85, practice:45 },
    minAbility:55, minAcademic:75,
    learning:['GPA 保持（均分 85+ 更有竞争力）','托福 / 雅思 / GRE','科研或项目经历','英文文书与推荐信'],
    abilities:['英语运用','学术基础','自主学习','跨文化沟通'],
    courses:['核心专业课程（数据结构、系统）','英语强化课程','托福/雅思备考材料'],
    activities:['保持高 GPA 并选修高阶课程','参加实验室科研项目','参加国际会议或竞赛','联系目标学校与导师'],
    pathDesc:['大一大二：GPA + 英语','大二：科研/竞赛入门','大三：标化考试 + 文书','大四：递交申请'],
    misconceptions:['留学只看出国考试（GPA 与科研同样重要）','留学比国内升学更轻松（成本与准备压力都更大）'],
    updated:'2026-07-28', status:'published',
  },
  {
    id:'overseas_data', name:'数据科学留学', path:'overseas', icon:'🌐',
    intro:'面向海外数据科学 / 分析类硕士项目，结合数学、编程与商业理解，是近年申请热门方向。',
    target:{ interest:75, values:65, ability:80, academic:80, tendency:85, practice:40 },
    minAbility:60, minAcademic:70,
    learning:['数学与统计基础','Python / SQL','机器学习基础','英语标化成绩'],
    abilities:['数学统计','编程实现','英语运用','逻辑分析'],
    courses:['《概率论与数理统计》《线性代数》','Python 数据分析','机器学习基础'],
    activities:['完成数据分析项目','参加 Kaggle 比赛','保持高 GPA','准备英语标化'],
    pathDesc:['大一大二：GPA + 数学 + 英语','大二：Python/统计/ML','大三：科研/比赛 + 标化','大四：申请'],
    misconceptions:['数据科学留学只看编程（统计与数学是核心）','项目经历越多越好（质量比数量重要）'],
    updated:'2026-07-27', status:'published',
  },
];

// 四类测评（简版示例：每类含若干题，答题时间预估）
const QUESTIONNAIRES = [
  {
    id:'holland', name:'霍兰德兴趣简版', icon:'🧩', minutes:4,
    tip:'通过你对学习与活动的偏好，刻画兴趣类型与倾向强度。',
    questions:[
      { q:'以下学习活动，你最愿意投入时间的是？',
        options:[
          { text:'调试程序直到它运行起来', scores:{ interest:5, tendency:2 } },
          { text:'研究数学与逻辑推导',     scores:{ interest:4, tendency:1 } },
          { text:'组织一场社团活动',       scores:{ interest:2, tendency:0 } },
          { text:'做一份数据分析报告',     scores:{ interest:3, tendency:1 } },
        ]},
      { q:'遇到一个陌生软件系统，你通常会？',
        options:[
          { text:'拆开看它的实现原理',     scores:{ interest:5, tendency:2 } },
          { text:'研究它解决什么问题、给谁用', scores:{ interest:3, tendency:0 } },
          { text:'记录下来，以后再说',     scores:{ interest:1, tendency:0 } },
          { text:'尝试改进它的交互体验',   scores:{ interest:3, tendency:1 } },
        ]},
      { q:'下列问题，你更愿意解决哪一类？',
        options:[
          { text:'“如何让系统更快更稳”这样的技术问题', scores:{ interest:5, tendency:2 } },
          { text:'“如何让更多人喜欢这个产品”这样的用户问题', scores:{ interest:3, tendency:1 } },
          { text:'“数据背后说明了什么”这样的分析问题', scores:{ interest:4, tendency:1 } },
          { text:'“如何管理一个团队”这样的组织问题', scores:{ interest:2, tendency:0 } },
        ]},
      { q:'课余时间，你更可能出现在？',
        options:[
          { text:'实验室 / 工作室写代码',   scores:{ interest:5, tendency:2 } },
          { text:'图书馆自习或读文献',     scores:{ interest:3, tendency:1 } },
          { text:'学生组织或志愿者现场',   scores:{ interest:2, tendency:0 } },
          { text:'线下读书会 / 分享会',    scores:{ interest:3, tendency:1 } },
        ]},
      { q:'你对哪类课程的期待最高？',
        options:[
          { text:'《数据结构》《操作系统》', scores:{ interest:5, tendency:2 } },
          { text:'《线性代数》《概率统计》', scores:{ interest:4, tendency:1 } },
          { text:'《沟通与表达》《管理学》', scores:{ interest:2, tendency:0 } },
          { text:'《数据库》《可视化》',     scores:{ interest:3, tendency:1 } },
        ]},
      { q:'完成一个学期项目，你希望的状态是？',
        options:[
          { text:'主导技术实现，自己写核心代码', scores:{ interest:5, tendency:2 } },
          { text:'规划整体方案并统筹分工',     scores:{ interest:2, tendency:1 } },
          { text:'负责数据整理与报告呈现',     scores:{ interest:3, tendency:1 } },
          { text:'保证质量、把每个细节做扎实', scores:{ interest:3, tendency:1 } },
        ]},
    ],
  },
  {
    id:'values', name:'职业价值观', icon:'🧭', minutes:3,
    tip:'了解你在职业选择中最看重什么，帮助判断方向与价值观的匹配。',
    questions:[
      { q:'选择工作时，你最看重？',
        options:[
          { text:'快速成长与能力提升',   scores:{ values:5 } },
          { text:'稳定与工作生活平衡',   scores:{ values:2 } },
          { text:'收入水平与回报',       scores:{ values:3 } },
          { text:'社会贡献与影响力',     scores:{ values:4 } },
        ]},
      { q:'你更愿意在怎样的环境中工作？',
        options:[
          { text:'技术驱动、不断更新迭代', scores:{ values:5 } },
          { text:'人际关系简单、流程清晰', scores:{ values:3 } },
          { text:'自由灵活、自己掌控节奏', scores:{ values:4 } },
          { text:'面向客户、成果即时反馈', scores:{ values:2 } },
        ]},
      { q:'面对职业中的不确定性，你更倾向于？',
        options:[
          { text:'接受挑战，尝试高风险高回报', scores:{ values:5 } },
          { text:'稳步积累，减少不必要的风险', scores:{ values:2 } },
          { text:'保持多条退路，灵活调整',     scores:{ values:4 } },
          { text:'跟随行业趋势与他人选择',     scores:{ values:3 } },
        ]},
      { q:'你希望自己的工作最终带来什么？',
        options:[
          { text:'解决真实世界的复杂问题', scores:{ values:5 } },
          { text:'个人技术名望与专业成就', scores:{ values:4 } },
          { text:'丰厚的物质回报',         scores:{ values:2 } },
          { text:'帮助到具体的人',         scores:{ values:4 } },
        ]},
      { q:'如果两份工作薪资相近，你会选？',
        options:[
          { text:'技术含量更高、更有挑战的那份', scores:{ values:5 } },
          { text:'通勤更近、加班更少的那份',     scores:{ values:2 } },
          { text:'发展前景更清晰的那份',         scores:{ values:4 } },
          { text:'团队氛围更好的那份',           scores:{ values:3 } },
        ]},
    ],
  },
  {
    id:'ability', name:'能力自评', icon:'⚙️', minutes:2,
    tip:'客观评估当前各项基础能力，用于与方向的能力要求做匹配。',
    questions:[
      { q:'程序设计 / 写代码能力', type:'rating', dim:'programming', labels:['很弱','较弱','一般','较强','很强'],
        opts:['完全没写过代码','写过简单脚本','能独立完成课程作业','能完成完整小项目','有项目开发经验'] },
      { q:'数学能力', type:'rating', dim:'math', labels:['很弱','较弱','一般','较强','很强'],
        opts:['比较吃力','基础一般','跟得上课程','成绩中上','数学是优势学科'] },
      { q:'英语能力', type:'rating', dim:'english', labels:['很弱','较弱','一般','较强','很强'],
        opts:['基础薄弱','需要努力','四六级可冲','阅读专业资料无碍','可顺畅听说读写'] },
      { q:'沟通表达与协作', type:'rating', dim:'communication', labels:['很弱','较弱','一般','较强','很强'],
        opts:['不爱表达','不太主动','能正常协作','善于沟通','能组织带动他人'] },
      { q:'组织与执行', type:'rating', dim:'organization', labels:['很弱','较弱','一般','较强','很强'],
        opts:['很少负责事情','需要指导','能完成分内事','能牵头小任务','善于统筹推进'] },
    ],
  },
  {
    id:'tendency', name:'专业认知与发展倾向', icon:'🧭', minutes:3,
    tip:'了解你对专业发展的初步倾向，帮助系统筛选更合适的方向。',
    questions:[
      { q:'毕业后，你目前的初步打算是？',
        options:[
          { text:'考研 / 保研继续深造',     scores:{ tendency:8 } },
          { text:'直接就业，进入行业工作',  scores:{ tendency:4 } },
          { text:'出国留学读研',           scores:{ tendency:8 } },
          { text:'还在探索，不太确定',     scores:{ tendency:2 } },
        ]},
      { q:'你更享受哪种学习过程？',
        options:[
          { text:'把理论学深学透',   scores:{ tendency:4, interest:3 } },
          { text:'动手做出看得见的成果', scores:{ tendency:2, interest:5 } },
          { text:'数据与实验里找规律', scores:{ tendency:3, interest:4 } },
          { text:'和人讨论、获取多元视角', scores:{ tendency:2, interest:2 } },
        ]},
      { q:'以下描述，哪句最接近你对大学的目标？',
        options:[
          { text:'为读研打基础，GPA 和科研优先', scores:{ tendency:8 } },
          { text:'尽早积累实习与项目，为就业做准备', scores:{ tendency:3 } },
          { text:'同时保持 GPA 与英语，给留学留选项', scores:{ tendency:7 } },
          { text:'先广泛探索，一年后再定方向',     scores:{ tendency:1 } },
        ]},
      { q:'如果必须现在选一个侧重点，你更愿意？',
        options:[
          { text:'深入理论，知其所以然',  scores:{ tendency:4, interest:3 } },
          { text:'应用实践，把东西做出来', scores:{ tendency:3, interest:5 } },
          { text:'兼顾两者，保持平衡',    scores:{ tendency:2, interest:3 } },
        ]},
    ],
  },
];

// 方向 → 任务模板（计划生成来源）
const PLAN_TEMPLATES = {
  employment_backend: {
    goalSummary:'本学期完成后端技术基础入门：掌握 Java 语法与数据结构基础，完成 1 个可运行的小项目。',
    semesterGoals:[
      { title:'掌握 Java 基础与面向对象编程', abilityTag:'programming_basic' },
      { title:'完成数据结构与算法入门',       abilityTag:'algorithm_basic' },
      { title:'学习数据库与 SQL 基础',        abilityTag:'database_basic' },
      { title:'完成 1 个控制台 / Web 后端小项目', abilityTag:'project_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'完成 Java 语法与面向对象章节学习', taskType:'LEARNING', estimatedHours:12 },
      { month:'2026-09', title:'LeetCode 简单题 15 道（数组与字符串）', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-10', title:'完成《数据结构》栈与队列的学习与练习', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-10', title:'搭建开发环境，完成一个通讯录小项目', taskType:'PRACTICE', estimatedHours:12 },
      { month:'2026-11', title:'学习 SQL 基础并完成 20 道练习题', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-11', title:'参加蓝桥杯报名并完成首轮模拟', taskType:'PRACTICE', estimatedHours:6 },
    ],
    notes:['任务可随课程安排与兴趣变化调整。'],
  },
  graduate_cs: {
    goalSummary:'本学期夯实数学与英语基础，确立考研备选目标，并开始数据结构系统学习。',
    semesterGoals:[
      { title:'稳定高数 / 线代成绩并预习考研考点', abilityTag:'math_basic' },
      { title:'通过四级并开始六级词汇积累', abilityTag:'english_basic' },
      { title:'系统学习数据结构', abilityTag:'algorithm_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'制定本学期数学与英语学习计划', taskType:'LEARNING', estimatedHours:4 },
      { month:'2026-09', title:'高数课程同步复习并整理错题本', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-10', title:'完成数据结构前 4 章学习', taskType:'LEARNING', estimatedHours:12 },
      { month:'2026-10', title:'六级词汇完成 500 词', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-11', title:'了解目标院校与专业方向清单', taskType:'CAREER', estimatedHours:3 },
      { month:'2026-11', title:'参加一场数学建模或编程讲座', taskType:'PRACTICE', estimatedHours:3 },
    ],
    notes:['考研准备按阶段推进，不必大一全力冲刺。'],
  },
  graduate_ai: {
    goalSummary:'本学期入门 Python 与机器学习基础，建立数学与编程双基础。',
    semesterGoals:[
      { title:'掌握 Python 语法与常用库', abilityTag:'programming_basic' },
      { title:'巩固高等数学与线性代数', abilityTag:'math_basic' },
      { title:'了解机器学习基本概念', abilityTag:'ml_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'完成 Python 语法入门课程', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-09', title:'完成 NumPy / Pandas 基础练习', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-10', title:'完成吴恩达机器学习课程前 5 周', taskType:'LEARNING', estimatedHours:12 },
      { month:'2026-10', title:'提交 1 个入门级 Kaggle 练习', taskType:'PRACTICE', estimatedHours:10 },
      { month:'2026-11', title:'复习线性代数重点章节', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-11', title:'整理 AI 学习路径笔记并复盘', taskType:'REVIEW', estimatedHours:4 },
    ],
    notes:['AI 学习以动手为主线，理论随实践补足。'],
  },
  employment_frontend: {
    goalSummary:'本学期完成前端三件套与一个框架入门，产出可访问的个人页面。',
    semesterGoals:[
      { title:'掌握 HTML/CSS/JavaScript 基础', abilityTag:'frontend_basic' },
      { title:'Vue 3 入门并完成一个小页面', abilityTag:'frontend_framework' },
      { title:'产出 1 个可在线访问的个人主页', abilityTag:'project_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'完成 HTML 与 CSS 布局基础', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-09', title:'JavaScript 基础语法练习', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-10', title:'Vue3 官方教程前 10 章', taskType:'LEARNING', estimatedHours:12 },
      { month:'2026-10', title:'仿写 1 个网页组件库小卡片', taskType:'PRACTICE', estimatedHours:8 },
      { month:'2026-11', title:'完成个人主页并部署到线上', taskType:'PRACTICE', estimatedHours:10 },
      { month:'2026-11', title:'阅读前端周报并写 1 篇学习总结', taskType:'REVIEW', estimatedHours:4 },
    ],
    notes:['先动手做，再回补理论。'],
  },
  data_analysis: {
    goalSummary:'本学期入门数据分析链路：Excel + SQL + Python 可视化，完成 1 份真实数据集分析报告。',
    semesterGoals:[
      { title:'掌握 SQL 基础查询', abilityTag:'database_basic' },
      { title:'Python 数据分析基础（Pandas/Matplotlib）', abilityTag:'data_basic' },
      { title:'完成 1 份数据分析小报告', abilityTag:'project_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'完成 SQL 基础学习与 20 道练习题', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-09', title:'Excel 高级技巧（透视表 / 函数）', taskType:'LEARNING', estimatedHours:6 },
      { month:'2026-10', title:'Python 数据分析入门教程', taskType:'LEARNING', estimatedHours:12 },
      { month:'2026-10', title:'选择一个数据集做探索性分析', taskType:'PRACTICE', estimatedHours:10 },
      { month:'2026-11', title:'完成分析报告并可视化呈现', taskType:'PRACTICE', estimatedHours:8 },
      { month:'2026-11', title:'分享报告并收集同学反馈', taskType:'REVIEW', estimatedHours:3 },
    ],
    notes:['优先用真实数据，分析讲清楚"为什么"。'],
  },
  software_testing: {
    goalSummary:'本学期建立软件测试基础认知，完成测试用例设计与自动化入门。',
    semesterGoals:[
      { title:'掌握软件测试基础与用例设计', abilityTag:'testing_basic' },
      { title:'Selenium / pytest 自动化入门', abilityTag:'automation_basic' },
      { title:'为 1 个开源项目写测试用例', abilityTag:'project_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'阅读《软件测试的艺术》前 5 章', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-09', title:'学习黑盒 / 白盒用例设计方法', taskType:'LEARNING', estimatedHours:6 },
      { month:'2026-10', title:'Selenium 自动化脚本入门', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-10', title:'为学校教务系统写 20 条测试用例', taskType:'PRACTICE', estimatedHours:8 },
      { month:'2026-11', title:'pytest 单元测试实践', taskType:'PRACTICE', estimatedHours:8 },
      { month:'2026-11', title:'整理测试学习笔记与经验', taskType:'REVIEW', estimatedHours:3 },
    ],
    notes:['测试的核心是"如何证明它正确"，先学方法再学工具。'],
  },
  product_manager: {
    goalSummary:'本学期建立产品思维，完成 1 份产品分析报告并参与 1 次校园产品实践。',
    semesterGoals:[
      { title:'学习需求分析与产品方法论', abilityTag:'product_basic' },
      { title:'完成 1 份产品分析报告', abilityTag:'project_basic' },
      { title:'参与校园产品 / 运营实践', abilityTag:'team_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'阅读《人人都是产品经理》入门章节', taskType:'LEARNING', estimatedHours:6 },
      { month:'2026-09', title:'体验并拆解 3 款校园场景 App', taskType:'LEARNING', estimatedHours:5 },
      { month:'2026-10', title:'完成 1 份产品分析报告初稿', taskType:'PRACTICE', estimatedHours:8 },
      { month:'2026-10', title:'学习原型工具 Figma 基础', taskType:'LEARNING', estimatedHours:6 },
      { month:'2026-11', title:'参与社团活动并做活动复盘', taskType:'PRACTICE', estimatedHours:6 },
      { month:'2026-11', title:'迭代分析报告并分享', taskType:'REVIEW', estimatedHours:4 },
    ],
    notes:['产品思维来自持续观察真实用户。'],
  },
  overseas_cs: {
    goalSummary:'本学期保持 GPA 并强化英语，建立海外留学申请的长期节奏。',
    semesterGoals:[
      { title:'保持 GPA 并选修 1 门高阶课程', abilityTag:'academic_keep' },
      { title:'通过四级，启动雅思 / 托福词汇', abilityTag:'english_basic' },
      { title:'初步了解目标院校与申请时间线', abilityTag:'overseas_info' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'制定 GPA 目标与课程学习计划', taskType:'LEARNING', estimatedHours:3 },
      { month:'2026-09', title:'启动雅思词汇（每天 30 词）', taskType:'LEARNING', estimatedHours:9 },
      { month:'2026-10', title:'参加四六级考试', taskType:'LEARNING', estimatedHours:6 },
      { month:'2026-10', title:'浏览 5 所目标院校官网与申请要求', taskType:'CAREER', estimatedHours:4 },
      { month:'2026-11', title:'联系导师或实验室，了解科研机会', taskType:'CAREER', estimatedHours:3 },
      { month:'2026-11', title:'整理学期成绩并复盘', taskType:'REVIEW', estimatedHours:3 },
    ],
    notes:['留学是长期工程，GPA 和英语是两条主线。'],
  },
  overseas_data: {
    goalSummary:'本学期打牢数学与 Python 基础，保持 GPA，建立数据科学留学路线。',
    semesterGoals:[
      { title:'保持 GPA 并夯实数学基础', abilityTag:'math_basic' },
      { title:'Python / SQL 数据分析入门', abilityTag:'data_basic' },
      { title:'启动英语标化备考', abilityTag:'english_basic' },
    ],
    monthlyTasks:[
      { month:'2026-09', title:'高数 / 线代复习并完成课后题', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-09', title:'Python 数据分析入门教程', taskType:'LEARNING', estimatedHours:10 },
      { month:'2026-10', title:'完成 1 个数据分析小项目', taskType:'PRACTICE', estimatedHours:10 },
      { month:'2026-10', title:'雅思 / 托福词汇积累 400 词', taskType:'LEARNING', estimatedHours:8 },
      { month:'2026-11', title:'浏览目标院校数据科学项目要求', taskType:'CAREER', estimatedHours:4 },
      { month:'2026-11', title:'复盘学期学习并调整计划', taskType:'REVIEW', estimatedHours:3 },
    ],
    notes:['数学 + 编程 + 英语三条线并行推进。'],
  },
};

// 能力标签（管理端）
const ABILITY_TAGS = [
  { id:'programming_basic', name:'编程基础', color:'#0E5A6D' },
  { id:'algorithm_basic',   name:'算法思维', color:'#C67B34' },
  { id:'math_basic',        name:'数学基础', color:'#3B6EA5' },
  { id:'english_basic',     name:'英语能力', color:'#6E7B85' },
  { id:'database_basic',    name:'数据库',   color:'#2F855A' },
  { id:'frontend_basic',    name:'前端基础', color:'#8B5BBF' },
  { id:'frontend_framework',name:'前端框架', color:'#4C9FBE' },
  { id:'data_basic',        name:'数据分析', color:'#3F8E6B' },
  { id:'ml_basic',          name:'机器学习', color:'#A5622A' },
  { id:'testing_basic',     name:'软件测试', color:'#C44E4E' },
  { id:'automation_basic',  name:'自动化',   color:'#5B7DB1' },
  { id:'product_basic',     name:'产品思维', color:'#B0744C' },
  { id:'team_basic',        name:'协作沟通', color:'#6C5B9E' },
  { id:'project_basic',     name:'项目实践', color:'#3A8E7C' },
  { id:'overseas_info',     name:'留学规划', color:'#4B7E9B' },
  { id:'academic_keep',     name:'学业保持', color:'#7A6E4B' },
];

// AI 咨询知识库（关键词 → 回复模板）
const AI_KB = [
  { k:['心理','抑郁','焦虑','情绪','压力'],
    r:'涉及心理健康的话题建议你优先求助学校的心理咨询中心或辅导员，这比任何线上建议都可靠。学习与生活上的困惑我很乐意继续陪你梳理。',
    esc:true },
  { k:['法律','医疗','疾病','违法'],
    r:'这类问题超出 AI 生涯顾问的能力范围，请务必咨询专业机构（学校法务、正规医院等），我们不做判断和处置建议。',
    esc:true },
  { k:['后端','开发工程师','Java','编程'],
    r:'后端方向的核心是打好数据结构与算法、掌握一门主流语言并持续做小项目。我建议：大一下学期前完成 Java 语法入门，每学期完成 1—2 个能跑起来的项目，大三前开始刷题和找实习。你可以在"方向推荐"里查看后端方向的完整能力要求与课程清单。' },
  { k:['前端','Vue','HTML'],
    r:'前端入门路径相对平缓：先 HTML/CSS/JavaScript 三件套，再学 Vue/React 框架，重点是持续产出可见的作品。每个阶段做一个能点开的页面，比只看教程有效得多。推荐你在"计划"里用后端模板替换成前端模板体验一下。' },
  { k:['考研','升学','保研'],
    r:'考研是长期工程，分阶段推进：大一大二夯实数学英语与数据结构，大二下确定目标院校，大三系统复习。关键是保持 GPA，很多学校保研和复试都看重成绩。注意：考研与就业可以并行准备，不必大一就进入全力冲刺。' },
  { k:['留学','出国','雅思','托福'],
    r:'留学申请的三条主线：GPA、英语标化、科研或项目经历。大一重点是保持高分 GPA 并启动英语词汇积累；大二起接触科研或竞赛；大三完成标化考试并准备文书。建议先浏览 3—5 所目标院校官网，把申请时间线列出来。' },
  { k:['数据分析','数据科学'],
    r:'数据分析入门链路：Excel/SQL → Python（Pandas/Matplotlib）→ 统计学基础 → 真实数据集项目。这个方向对业务理解要求高，建议从"用数据回答一个真实问题"开始，而不是只学工具。' },
  { k:['AI','人工智能','机器学习'],
    r:'AI 方向需要数学与编程双基础：大一大二抓高等数学、线性代数与 Python，再学机器学习基础。强烈建议边学边做：复现一个小项目或打一场入门赛，比只看课程有效得多。' },
  { k:['产品','产品经理','PM'],
    r:'产品经理的本质是"发现问题、定义方案、推动落地"。入门可以先做三件事：拆解身边 3 款 App 的定位与功能、学一点原型工具、参与一次真实的学生组织或社团项目。技术背景是显著加分项。' },
  { k:['计划','安排','时间','怎么开始'],
    r:'建议按"学期目标 → 月度任务 → 周执行"三级拆解。你已经生成了学期计划草案，可以在"计划"页逐条确认或修改，把大目标变成每周可执行的小动作。记住：计划要小到明天就能开始。' },
  { k:['方向','迷茫','不知道','怎么选'],
    r:'方向选择不用一步到位。建议：先完成测评看六维画像，浏览三条路径下的方向卡，收藏 2—3 个感兴趣的方向；再选 1 个主目标 + 1 个备选目标，用一学期的时间通过课程和项目去验证兴趣。你的推荐结果里有"为什么推荐给我"的完整解释，可以反复阅读。' },
  { k:['复盘','反思','总结'],
    r:'阶段复盘关注四件事：完成情况、未完成原因、兴趣/能力变化、下一步调整。你可以直接在"复盘"页按月填写，系统会基于你的任务记录生成阶段总结与调整建议，建议每学期至少完成 1 次正式复盘。' },
  { k:['实习','简历','求职','找工作'],
    r:'就业方向建议节奏：大一大二打基础和做项目，大二下开始关注暑期实习，大三集中找实习并准备简历与面试。一份"能讲清楚自己做了什么"的项目经历，比罗列证书更有用。' },
];

// 演示用户 / 白名单
const MOCK_ACCOUNTS = [
  { role:'student',  uid:'S1001', name:'李明', studentNo:'2026011301', className:'计科2601', password:'123456' },
  { role:'advisor',  uid:'A2001', name:'王老师', dept:'计算机学院辅导员', password:'123456' },
  { role:'admin',    uid:'M3001', name:'系统管理员', password:'123456' },
];

// 辅导员端学生列表（用于演示筛选与统计）
const MOCK_STUDENTS = [
  { id:'S1001', name:'李明',  className:'计科2601', complete:92, assessed:true,  path:'employment', direction:'后端开发工程师', primaryGoal:'后端开发',  planRate:71, lastReview:'2026-10-02', askGuidance:false, status:'good' },
  { id:'S1002', name:'张雨',  className:'计科2602', complete:78, assessed:true,  path:'graduate',   direction:'计算机技术考研', primaryGoal:'考研上岸',  planRate:64, lastReview:'2026-09-28', askGuidance:true,  status:'review' },
  { id:'S1003', name:'王浩',  className:'软工2601', complete:45, assessed:false, path:null, direction:'未确定', primaryGoal:'—', planRate:0, lastReview:null, askGuidance:false, status:'todo' },
  { id:'S1004', name:'陈晨',  className:'计科2601', complete:86, assessed:true,  path:'overseas',   direction:'海外计算机硕士', primaryGoal:'出国读研', planRate:58, lastReview:'2026-08-15', askGuidance:false, status:'late' },
  { id:'S1005', name:'赵敏',  className:'软工2602', complete:70, assessed:true,  path:'employment', direction:'数据分析师',     primaryGoal:'数据分析',  planRate:82, lastReview:'2026-10-01', askGuidance:false, status:'good' },
  { id:'S1006', name:'刘洋',  className:'计科2602', complete:33, assessed:false, path:null, direction:'未确定', primaryGoal:'—', planRate:0, lastReview:null, askGuidance:true,  status:'todo' },
  { id:'S1007', name:'孙悦',  className:'软工2601', complete:88, assessed:true,  path:'graduate',   direction:'人工智能方向深造', primaryGoal:'AI 深造', planRate:76, lastReview:'2026-09-20', askGuidance:false, status:'good' },
  { id:'S1008', name:'周杰',  className:'计科2601', complete:61, assessed:true,  path:'employment', direction:'软件测试工程师', primaryGoal:'测试方向', planRate:49, lastReview:'2026-07-30', askGuidance:false, status:'late' },
];

// 管理端：白名单
const MOCK_WHITELIST = [
  { studentNo:'2026011301', name:'李明', className:'计科2601', verifyCode:'202601', used:true,  status:'已注册' },
  { studentNo:'2026011302', name:'张雨', className:'计科2602', verifyCode:'202602', used:true,  status:'已注册' },
  { studentNo:'2026011303', name:'王浩', className:'软工2601', verifyCode:'202603', used:false, status:'待注册' },
  { studentNo:'2026011304', name:'陈晨', className:'计科2601', verifyCode:'202604', used:true,  status:'已注册' },
  { studentNo:'2026011305', name:'赵敏', className:'软工2602', verifyCode:'202605', used:true,  status:'已注册' },
  { studentNo:'2026011306', name:'刘洋', className:'计科2602', verifyCode:'202606', used:false, status:'待注册' },
  { studentNo:'2026011307', name:'孙悦', className:'软工2601', verifyCode:'202607', used:true,  status:'已注册' },
  { studentNo:'2026011308', name:'周杰', className:'计科2601', verifyCode:'202608', used:true,  status:'已注册' },
  { studentNo:'2026011309', name:'吴迪', className:'软工2602', verifyCode:'202609', used:false, status:'待注册' },
];

// 管理端：培养方案 PDF 导入审核队列
const MOCK_IMPORT_ITEMS = [
  { id:'IM-003', code:'CS101', name:'程序设计基础',  semester:'1', credits:4, hours:64, category:'学科基础课', module:'编程基础', prereq:'—', page:3, confidence:'高', status:'待审核' },
  { id:'IM-003', code:'CS201', name:'数据结构',      semester:'2', credits:4, hours:64, category:'学科基础课', module:'算法与数据结构', prereq:'程序设计基础', page:5, confidence:'高', status:'待审核' },
  { id:'IM-003', code:'MA101', name:'高等数学（上）', semester:'1', credits:5, hours:80, category:'公共基础课', module:'数学', prereq:'—', page:2, confidence:'高', status:'待审核' },
  { id:'IM-003', code:'CS305', name:'操作系统',       semester:'4', credits:4, hours:64, category:'专业核心课', module:'系统', prereq:'数据结构', page:9, confidence:'中', status:'待审核' },
  { id:'IM-003', code:'CS310', name:'数据库原理',     semester:'4', credits:3, hours:48, category:'专业核心课', module:'数据', prereq:'数据结构', page:11, confidence:'中', status:'待审核' },
  { id:'IM-003', code:'CS298', name:'软件工程导论',   semester:'5', credits:2, hours:32, category:'专业限选课', module:'工程', prereq:'—', page:13, confidence:'低', status:'待补录' },
];

// 管理端：审计日志
const MOCK_AUDIT = [
  { time:'2026-10-03 09:12', user:'系统', action:'AI调用', target:'recommendation/explain', detail:'模型 gpt-4o-mini · prompt v1.3 · 成功 · 412ms', level:'info' },
  { time:'2026-10-03 09:05', user:'李明(S1001)', action:'查看学生详情', target:'本人画像', detail:'profile_snapshot v2 访问', level:'info' },
  { time:'2026-10-02 20:41', user:'王老师(A2001)', action:'查看学生详情', target:'S1002 张雨', detail:'经 advisor_student_relation 校验', level:'info' },
  { time:'2026-10-02 20:40', user:'王老师(A2001)', action:'填写指导意见', target:'S1002 张雨', detail:'意见已写入，学生可查看', level:'info' },
  { time:'2026-10-01 15:22', user:'系统管理员', action:'配置变更', target:'问卷 holland 发布 v2', detail:'发布后不可修改', level:'warn' },
  { time:'2026-09-30 11:03', user:'系统', action:'AI调用', target:'plan/generate', detail:'模型 gpt-4o-mini · prompt v1.2 · 成功 · 890ms', level:'info' },
  { time:'2026-09-29 08:55', user:'未知', action:'登录失败', target:'student 2026011399', detail:'密码错误 ×3，已锁定 15 分钟', level:'warn' },
  { time:'2026-09-28 17:30', user:'系统管理员', action:'数据导出', target:'试用反馈汇总', detail:'范围：2026-09 月，已记录', level:'info' },
  { time:'2026-09-27 14:12', user:'系统管理员', action:'PDF导入', target:'培养方案 2026级计科', detail:'共解析 42 条，待审核', level:'info' },
  { time:'2026-09-26 10:40', user:'李明(S1001)', action:'登录成功', target:'/student/home', detail:'IP 172.16.x.x', level:'info' },
];

// 管理端：模型配置
const MOCK_MODELS = {
  provider:'openai',
  model:'gpt-4o-mini',
  enabled:true,
  timeoutSec:20,
  maxTokens:600,
  maxInputLen:2000,
  retryCount:1,
  prompts:[
    { version:'v1.3', scene:'推荐解释', status:'published', publishedAt:'2026-09-01', updatedAt:'2026-09-30', content:'你是一位生涯规划助理……' },
    { version:'v1.2', scene:'计划生成', status:'published', publishedAt:'2026-09-01', updatedAt:'2026-09-20', content:'依据学期目标与任务模板……' },
    { version:'v1.1', scene:'复盘总结', status:'published', publishedAt:'2026-09-01', updatedAt:'2026-09-15', content:'基于学生任务记录生成结构化总结……' },
    { version:'v1.0', scene:'生涯咨询', status:'published', publishedAt:'2026-09-01', updatedAt:'2026-09-01', content:'系统提示：仅回答专业认知与学习规划……' },
  ],
};

// 演示学生完整状态（种子数据：已完成大部分闭环）
function seedStudentState() {
  const s = {
    user: { id:'S1001', name:'李明', studentNo:'2026011301', grade:'2026级', majorCategory:'计算机类', className:'计科2601', role:'student' },
    consent: { version:'v1.0', agreedAt:'2026-08-25T09:00:00+08:00' },
    profile: {
      complete: 92,
      basic: { gender:'男', hometown:'重庆', birthday:'2008-05-14', phone:'138****6721' },
      academic: { math:4, english:3, programming:2, note:'高中数学较好，英语一般，编程刚起步' },
      interestPrefs: ['编程','数学建模','电子制作'],
      abilitySelf: { programming:2, math:4, english:3, communication:4, organization:3 },
      values: ['成长','技术挑战','稳定'],
      experiences: [
        { type:'竞赛', title:'数学建模校赛 · 二等奖', date:'2026-05', desc:'三人组队，负责建模与论文撰写，完成"校园快递点选址"问题。' },
        { type:'项目', title:'暑期自学 · 小计算器程序', date:'2026-07', desc:'用 Python 完成命令行计算器，第一次把代码从"看懂"变成"写出来"。' },
      ],
      developmentIntention:'employment',
      constraints: ['愿意在课余投入学习','优先考虑川渝地区就业'],
    },
    assessment: {
      completed: true,
      finishedAt:'2026-09-01T09:12:00+08:00',
      moduleState:{ holland:'done', values:'done', ability:'done', tendency:'done' },
      scores: { interest:78, values:70, ability:62, academic:58, tendency:80, practice:45 },
    },
    portrait: {
      version:2,
      generatedAt:'2026-09-01T09:13:00+08:00',
      sourceVersion:'Q v2 + 自主填报 v3',
      summary:'你的兴趣集中在技术问题求解与动手实践，职业价值观偏向成长与技术挑战；当前编程基础处于起步阶段，但数学与沟通协作基础较好。整体呈现出"动手型、技术型、成长型"的新生画像。',
      strengths:['偏好结构化问题求解，适合技术类方向','数学基础较好，是算法与数据方向的加分项','沟通协作较强，利于团队型岗位与项目管理'],
      explore:['编程实践有待积累，建议从完成小项目开始','英语是留学与阅读外文资料的门槛，可稳步提升','实践经历较少，需要补充竞赛或项目经历'],
      completeness:92,
      feedback:null,
    },
    favorites: ['employment_backend','data_analysis'],
    recommendation: {
      runId:'190001',
      ruleVersion:'R1.0',
      profileVersion:2,
      generatedAt:'2026-09-01T09:13:30+08:00',
      results: [
        {
          directionId:'employment_backend', rank:1, score:82.4, confidence:'MEDIUM',
          reasons:['偏好结构化问题求解（兴趣维度）','重视技术成长与挑战（价值观维度）','数学基础较好，适合算法方向'],
          strengths:['数学与逻辑基础较好','沟通协作能力突出','愿意投入课余学习'],
          gaps:['缺少系统编程实践，需补足编程基础'],
          semesterActions:['完成《程序设计基础》课程','完成 1 个可运行的小项目'],
          feedback:null,
        },
        {
          directionId:'data_analysis', rank:2, score:76.8, confidence:'MEDIUM',
          reasons:['对数据分析与呈现感兴趣','数学基础较好，符合数据方向要求','重视成长空间'],
          strengths:['数学基础较好','具备一定表达呈现能力'],
          gaps:['数据分析工具链尚未入门'],
          semesterActions:['学习 SQL 与 Python 数据分析基础','完成 1 份分析小报告'],
          feedback:null,
        },
        {
          directionId:'graduate_ai', rank:3, score:70.2, confidence:'MEDIUM',
          reasons:['对智能技术与问题求解感兴趣','数学基础较好是 AI 方向的优势'],
          strengths:['数学基础较好','学习意愿强'],
          gaps:['编程实践与英语阅读需要加强'],
          semesterActions:['完成 Python 入门','了解机器学习基本概念'],
          feedback:null,
        },
        {
          directionId:'employment_frontend', rank:4, score:66.5, confidence:'LOW',
          reasons:['动手实践意愿较强','但兴趣特征与前端匹配度一般'],
          strengths:['动手意愿强','协作能力好'],
          gaps:['视觉审美方向探索不足'],
          semesterActions:['体验前端三件套，判断兴趣','做一个简单个人页面'],
          feedback:null,
        },
      ],
    },
    goal: {
      primary:   { directionId:'employment_backend', name:'后端开发工程师', chosenAt:'2026-09-02T10:00:00+08:00' },
      backup:    { directionId:'data_analysis',      name:'数据分析师',     chosenAt:'2026-09-02T10:00:00+08:00' },
      version:'G-v3',
    },
    plan: (() => {
      const t = PLAN_TEMPLATES.employment_backend;
      return {
        source:'ai', confirmed:true, confirmedAt:'2026-09-02T10:05:00+08:00', version:'P-v2',
        goalSummary: t.goalSummary,
        semesterGoals: t.semesterGoals,
        monthlyTasks: t.monthlyTasks,
        notes: t.notes,
      };
    })(),
    tasks: [
      { id:'T1', month:'2026-09', title:'完成 Java 语法与面向对象章节学习', type:'LEARNING', estHours:12, status:'done', checkedInAt:'2026-09-20', note:'已完成，掌握了类与对象、集合基础。' },
      { id:'T2', month:'2026-09', title:'LeetCode 简单题 15 道（数组与字符串）', type:'LEARNING', estHours:8, status:'doing', checkedInAt:null, note:'已做 9 道，双指针方法还不熟。' },
      { id:'T3', month:'2026-10', title:'完成《数据结构》栈与队列的学习与练习', type:'LEARNING', estHours:10, status:'pending', checkedInAt:null, note:null },
      { id:'T4', month:'2026-10', title:'搭建开发环境，完成一个通讯录小项目', type:'PRACTICE', estHours:12, status:'doing', checkedInAt:null, note:'环境已就绪，功能做到一半。' },
      { id:'T5', month:'2026-11', title:'学习 SQL 基础并完成 20 道练习题', type:'LEARNING', estHours:8, status:'pending', checkedInAt:null, note:null },
      { id:'T6', month:'2026-11', title:'参加蓝桥杯报名并完成首轮模拟', type:'PRACTICE', estHours:6, status:'later', checkedInAt:null, note:'与课程时间冲突，推迟到 11 月中旬。' },
    ],
    reviews: [
      {
        id:'R1', cycle:'2026-09', completed:true, submittedAt:'2026-10-02T09:00:00+08:00',
        content:{ done:'完成 Java 语法与通讯录项目，通过四六级报名', undone:'LeetCode 练习因时间不足未完成一半', interest:'后端开发的兴趣比预期更强，尤其喜欢调试解决问题的过程', ability:'编程能力明显提升，能独立写 300 行左右的程序', next:'10 月聚焦数据结构与 SQL，减少并行任务数量' },
        aiSummary:'9 月你的编程基础快速提升，兴趣与"后端开发"高度一致；主要瓶颈是并行任务过多导致 LeetCode 练习受阻，建议 10 月聚焦少数主线任务。',
        aiSuggest:['将任务从 6 条收敛到 3 条主线','数据结构优先于 SQL 推进','每周固定 2 次刷题时间块'],
        advisorRequested:true, advisorReply:null,
      },
    ],
    aiChat: [
      { role:'ai', content:'你好，我是生涯规划助手。可以问我关于专业认知、升学/就业/留学路径比较、学习安排和计划优化的问题。回答仅供参考，重大决定请结合辅导员建议。' },
    ],
  };
  return s;
}

// 全新学生（用于白名单注册后的首次登录，强制进入隐私授权流程）
function freshStudent(studentNo, name, className) {
  return {
    user: { id:'S'+Date.now(), name, studentNo, grade:'2026级', majorCategory:'计算机类', className: className || '待分配', role:'student' },
    consent: null,
    profile: {
      complete: 0,
      basic:{}, academic:{}, interestPrefs:[], abilitySelf:{}, values:[],
      experiences:[], developmentIntention:null, constraints:[],
    },
    assessment: { completed:false, finishedAt:null, moduleState:{}, answers:{}, scores:null },
    portrait: null,
    favorites: [],
    recommendation: null,
    goal: null,
    plan: null,
    tasks: [],
    reviews: [],
    aiChat: [ { role:'ai', content:'你好，我是生涯规划助手。可以问我关于专业认知、升学/就业/留学路径比较、学习安排和计划优化的问题。回答仅供参考，重大决定请结合辅导员建议。' } ],
  };
}

// 初始化默认全局状态（含演示学生与各端演示数据）
function defaultState() {
  return {
    version: 2,
    session: { role:null, uid:null },
    student: seedStudentState(),
    advisor: { filter:{} },
    admin: { },
  };
}
