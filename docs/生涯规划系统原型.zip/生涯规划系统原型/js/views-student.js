/* ============================================================
   生涯规划系统 · MVP 原型 —— 学生端视图（核心闭环）
   ============================================================ */

function studentState() { return App.state.student; }
function saveS() { save(); }

// —— 8 步闭环旅程状态 ——
function journeyStages() {
  const s = studentState();
  const stages = [
    { key:'reg',    label:'注册',  done: !!s.user },
    { key:'assess', label:'测评',  done: !!(s.assessment && s.assessment.completed) },
    { key:'portrait', label:'画像', done: !!s.portrait },
    { key:'rec',    label:'推荐',  done: !!(s.recommendation && s.recommendation.results && s.recommendation.results.length) },
    { key:'goal',   label:'目标',  done: !!(s.goal && s.goal.primary) },
    { key:'plan',   label:'计划',  done: !!(s.plan && s.plan.confirmed) },
    { key:'task',   label:'任务',  done: !!(s.tasks && s.tasks.length) },
    { key:'review', label:'复盘',  done: !!(s.reviews && s.reviews.length) },
  ];
  const doneCount = stages.filter(x => x.done).length;
  // 当前阶段 = 第一个未完成阶段；全部完成则指向复盘
  let currentIdx = stages.findIndex(x => !x.done);
  if (currentIdx === -1) currentIdx = stages.length - 1;
  return stages.map((x, i) => ({ ...x, state: x.done ? 'done' : (i === currentIdx ? 'current' : 'todo') }));
}
function nextStep(stages) {
  const cur = stages.find(x => x.state === 'current');
  const map = {
    reg:'完成注册', assess:'完成生涯测评', portrait:'查看我的六维画像', rec:'获取方向推荐',
    goal:'选择主目标', plan:'确认学期计划', task:'记录本月任务', review:'完成阶段复盘',
  };
  const path = {
    reg:'/student/profile', assess:'/student/assessment', portrait:'/student/portrait', rec:'/student/recommendations',
    goal:'/student/recommendations', plan:'/student/plan', task:'/student/tasks', review:'/student/reviews',
  };
  if (!cur) return { label:'全部完成', path:'/student/reviews', key:'review' };
  return { label: map[cur.key], path: path[cur.key], key: cur.key };
}

// 当前得分（优先用已存得分；无则按答案计算）
function currentScores() {
  const s = studentState();
  if (s.assessment && s.assessment.scores) return s.assessment.scores;
  if (s.assessment && s.assessment.answers) return AppCore.computeScores(s.assessment.answers);
  return null;
}

function scoresToDimValues(scores) {
  if (!scores) return DIMS.map(d => ({ name: d.name, value: 0 }));
  return DIMS.map(d => ({ name: d.name, value: scores[d.key] || 0 }));
}

/* ============================================================
   首页
   ============================================================ */
window.StudentViews = {
  home(appEl) {
    const s = studentState();
    const stages = journeyStages();
    const next = nextStep(stages);
    const doneCount = stages.filter(x => x.state === 'done').length;
    const allDone = doneCount === 8;
    const scores = currentScores();
    const completeness = s.profile.complete || 0;

    // 任务汇总
    const tasks = s.tasks || [];
    const doing = tasks.filter(t => t.status === 'doing').length;
    const done = tasks.filter(t => t.status === 'done').length;
    const pending = tasks.filter(t => t.status === 'pending').length;

    const rail = stages.map(x => `
      <div class="node ${x.state}">
        <span class="n-dot">${x.state === 'done' ? '✓' : (x.state === 'current' ? (stages.indexOf(x)+1) : '')}</span>
        <span class="n-label">${x.label}</span>
      </div>`).join('');

    const goalInfo = s.goal && s.goal.primary
      ? `<div class="row gap8" style="margin-top:14px">
          <span class="badge badge-amber" style="background:rgba(198,123,52,.18)">当前主目标 · ${esc(s.goal.primary.name)}</span>
          ${s.goal.backup ? `<span class="badge" style="background:rgba(255,255,255,.12);color:#fff">备选 · ${esc(s.goal.backup.name)}</span>` : ''}
        </div>` : '';

    const html = `
    <div class="journey-card">
      <div class="jc-in">
        <div class="jc-top">
          <div class="jc-title">${allDone ? '生涯旅程 · 已走完全程' : '生涯旅程 · 当前处于 ' + next.label}</div>
          <div class="jc-count">${doneCount}/8 步</div>
        </div>
        <div class="jc-line"><div class="rail">${rail}</div></div>
        <div class="jc-hint">
          ${ICONS.arrow}
          <span>${allDone ? '闭环已跑通，建议持续记录任务并完成阶段复盘' : '下一步：' + next.label}</span>
        </div>
        ${goalInfo}
      </div>
    </div>

    <div class="row gap12 mt16">
      <div class="card card-pad" style="flex:1">
        <div class="row between">
          <div>
            <div class="small muted">画像完整度</div>
            <div style="font-size:22px;font-weight:800;margin-top:2px">${completeness}%</div>
          </div>
          ${ringSVG(completeness, 54, '#0E5A6D', '完整度')}
        </div>
      </div>
      <div class="card card-pad" style="flex:1">
        <div class="small muted">计划任务</div>
        <div class="row gap12" style="margin-top:8px">
          <div style="text-align:center"><div style="font-size:20px;font-weight:800;color:var(--blue)">${doing}</div><div class="small faint">进行中</div></div>
          <div style="width:1px;background:var(--line);height:26px"></div>
          <div style="text-align:center"><div style="font-size:20px;font-weight:800;color:var(--green)">${done}</div><div class="small faint">已完成</div></div>
          <div style="width:1px;background:var(--line);height:26px"></div>
          <div style="text-align:center"><div style="font-size:20px;font-weight:800;color:var(--faint)">${pending}</div><div class="small faint">未开始</div></div>
        </div>
      </div>
    </div>

    ${scores ? `
    <div class="card card-pad mt16">
      <div class="row between mb12">
        <div class="card-title">我的画像速览</div>
        <a class="small" href="#/student/portrait">查看完整画像 →</a>
      </div>
      <div class="radar-wrap">
        <div>${radarSVG(scoresToDimValues(scores), 170)}</div>
        <div class="radar-legend">
          ${DIMS.map(d => {
            const v = scores[d.key] || 0;
            const color = v >= 70 ? 'var(--teal)' : v >= 50 ? 'var(--amber)' : 'var(--faint)';
            return `<div class="li"><span style="width:44px">${d.name}</span><span class="bar"><i style="width:${v}%;background:${color}"></i></span><span class="val">${v}</span></div>`;
          }).join('')}
        </div>
      </div>
    </div>` : ''}

    <div class="card card-pad mt16">
      <div class="card-title">快捷入口</div>
      <div class="row gap8 wrap mt12">
        <button class="btn btn-soft btn-sm" data-g="/student/assessment">🧩 完成测评</button>
        <button class="btn btn-soft btn-sm" data-g="/student/portrait">🖼️ 我的画像</button>
        <button class="btn btn-soft btn-sm" data-g="/student/directions">🧭 探索方向</button>
        <button class="btn btn-soft btn-sm" data-g="/student/recommendations">✨ 方向推荐</button>
        <button class="btn btn-soft btn-sm" data-g="/student/plan">📝 学期计划</button>
        <button class="btn btn-soft btn-sm" data-g="/student/tasks">✅ 任务记录</button>
        <button class="btn btn-soft btn-sm" data-g="/student/reviews">🔄 阶段复盘</button>
        <button class="btn btn-soft btn-sm" data-g="/student/ai-chat">💬 AI 咨询</button>
      </div>
    </div>

    <div class="card card-pad mt16" style="border-color:var(--amber-s);background:var(--amber-l)">
      <div class="row between">
        <div>
          <div style="font-weight:700;font-size:14px">智能生成，供探索参考</div>
          <div class="small" style="color:var(--muted);margin-top:3px">推荐结果基于确定性规则，大模型仅负责解释，不构成结论性判断。</div>
        </div>
        ${ICONS.spark}
      </div>
    </div>`;

    renderStudentShell(html, 'home');
    appEl.querySelectorAll('[data-g]').forEach(b => b.addEventListener('click', () => navigate(b.dataset.g)));
  },

  /* ============================================================
     资料采集
     ============================================================ */
  profile(appEl) {
    const s = studentState();
    const p = s.profile;
    let saveTimer = null;
    let statusEl = null;

    const ratingNames = ['programming','math','english','communication','organization'];
    const ratingLabels = ['编程','数学','英语','沟通协作','组织执行'];
    const valueChips = ['成长','技术挑战','稳定','收入','地域','影响力'];
    const interestChips = ['编程','算法','数据分析','电子制作','产品设计','游戏开发','网络安全','人工智能','动漫设计','网站开发'];

    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 02 · 资料采集</div>
      <h1>完善我的信息</h1>
      <p>信息用于生成画像与推荐，可随时修改；刷新页面不会丢失。</p>
    </div>

    <div class="card card-pad mb12" style="display:flex;align-items:center;gap:10px">
      <span id="autosave-dot" style="width:8px;height:8px;border-radius:50%;background:var(--green)"></span>
      <span id="autosave-text" class="small muted">所有修改已自动保存到本地</span>
      <button class="btn btn-copper btn-sm" id="auto-fill" style="margin-left:auto">一键模拟填写</button>
    </div>

    <div class="card card-pad">
      <div class="form-sec">
        <div class="fs-title"><span class="n">1</span>基本信息</div>
        <div class="fs-sub">用于生成基础档案，学号与班级由白名单导入，不可修改</div>
        <div class="kv-grid" style="grid-template-columns:1fr 1fr 1fr">
          <div class="field"><label>学号</label><input class="input" value="${esc(p.user.studentNo)}" disabled></div>
          <div class="field"><label>姓名</label><input class="input" value="${esc(p.user.name)}" disabled></div>
          <div class="field"><label>班级</label><input class="input" value="${esc(p.user.className)}" disabled></div>
        </div>
        <div class="kv-grid">
          <div class="field"><label>性别</label>
            <div class="radio-grid col2" style="grid-template-columns:repeat(2,auto)">
              ${['男','女'].map(g => `<div class="radio-card ${p.basic.gender===g?'selected':''}" data-radio data-val="${g}"><span class="dot"></span>${g}</div>`).join('')}
            </div>
          </div>
          <div class="field"><label>家乡</label><input class="input" id="f-hometown" value="${esc(p.basic.hometown||'')}"></div>
        </div>
        <div class="kv-grid">
          <div class="field"><label>出生日期</label><input class="input" id="f-birthday" value="${esc(p.basic.birthday||'')}"></div>
          <div class="field"><label>联系方式</label><input class="input" id="f-phone" value="${esc(p.basic.phone||'')}"></div>
        </div>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">2</span>学业基础</div>
        <div class="fs-sub">对自己当前基础的自评，影响推荐的方向匹配度</div>
        <div class="field">
          <label>数学基础</label><div class="rating-row" id="r-math">${ratingRow(p.academic.math)}</div>
        </div>
        <div class="field">
          <label>英语基础</label><div class="rating-row" id="r-english">${ratingRow(p.academic.english)}</div>
        </div>
        <div class="field">
          <label>编程基础</label><div class="rating-row" id="r-programming">${ratingRow(p.academic.programming)}</div>
        </div>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">3</span>兴趣偏好</div>
        <div class="fs-sub">可多选，帮助你更精准地匹配方向</div>
        <div class="row gap8 wrap" id="f-interests">
          ${interestChips.map(c => `<span class="chip-tag ${p.interestPrefs.includes(c)?'selected':''}" data-val="${c}">${c}</span>`).join('')}
        </div>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">4</span>能力自评</div>
        <div class="fs-sub">与四类测评中的"能力自评"对应，随测评结果一并更新</div>
        <div class="row gap8 wrap" id="f-abilities">
          ${ratingNames.map((k,i) => `<div style="flex:1;min-width:150px" class="field">
            <label>${ratingLabels[i]}</label><div class="rating-row" data-rating="${k}">${ratingRow(p.abilitySelf[k] || 2)}</div></div>`).join('')}
        </div>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">5</span>职业价值观</div>
        <div class="fs-sub">选择对你最重要的 2—3 项</div>
        <div class="row gap8 wrap" id="f-values">
          ${valueChips.map(c => `<span class="chip-tag ${p.values.includes(c)?'selected':''}" data-val="${c}">${c}</span>`).join('')}
        </div>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">6</span>实践经历</div>
        <div class="fs-sub">竞赛、项目、学生工作、志愿服务等（选填）</div>
        <div id="exp-list"></div>
        <button class="btn btn-soft btn-sm" id="add-exp">＋ 新增经历</button>
      </div>

      <div style="border-top:1px dashed var(--line);margin:6px 0 22px"></div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">7</span>发展意向</div>
        <div class="fs-sub">初步倾向即可，之后可随时调整</div>
        <div class="radio-grid col3" id="f-intention">
          ${Object.values(PATHS).map(pt => `<div class="radio-card ${p.developmentIntention===pt.id?'selected':''}" data-radio data-val="${pt.id}"><span class="dot"></span>${pt.name}</div>`).join('')}
        </div>
      </div>

      <div class="form-sec">
        <div class="fs-title"><span class="n">8</span>现实约束</div>
        <div class="fs-sub">地域、时间投入、家庭期望等（选填，仅影响推荐建议）</div>
        <div class="field"><label>约束描述</label><textarea class="textarea" id="f-constraints">${esc((p.constraints||[]).join('；'))}</textarea></div>
      </div>
    </div>

    <div class="row gap8 mt16">
      <button class="btn btn-primary btn-lg" style="flex:1" id="save-goto">保存并继续 →</button>
    </div>`;

    function ratingRow(val) {
      return ['很弱','较弱','一般','较强','很强'].map((lb,i) => `
        <div class="rating-item ${val===i+1?'selected':''}" data-v="${i+1}"><b>${i+1}</b><span>${lb}</span></div>`).join('');
    }

    renderStudentShell(html, 'home');
    const root = appEl.querySelector('.app-frame');

    // 自动保存指示
    function markSaved() {
      if (statusEl) statusEl.textContent = '已自动保存 ' + new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'});
      root.querySelector('#autosave-dot').style.background = 'var(--green)';
    }
    function scheduleSave() {
      root.querySelector('#autosave-dot').style.background = 'var(--amber)';
      if (statusEl) statusEl.textContent = '正在自动保存…';
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => { saveS(); markSaved(); }, 500);
    }

    // 单选
    root.querySelectorAll('[data-radio]').forEach(el => {
      el.addEventListener('click', () => {
        const group = el.closest('[data-radio]') ? el.parentElement : null;
        // 通用处理：同组兄弟
        const siblings = el.parentElement.querySelectorAll('[data-radio]');
        siblings.forEach(x => x.classList.remove('selected'));
        el.classList.add('selected');
        // 写入 state
        const key = el.parentElement.id;
        if (key === 'f-intention') { p.developmentIntention = el.dataset.val; }
        if (key && key.startsWith('f-')) {
          const name = key.replace('f-','');
          if (name === 'intention') p.developmentIntention = el.dataset.val;
        }
        if (el.closest('.kv-grid') && el.dataset.val) {
          // 性别
          const labels = el.closest('.kv-grid').querySelectorAll('label');
          labels.forEach(l => { if (l.textContent === '性别') p.basic.gender = el.dataset.val; });
        }
        scheduleSave();
      });
    });
    // 文本输入
    root.querySelectorAll('.input, .textarea').forEach(inp => {
      if (inp.disabled) return;
      inp.addEventListener('input', () => {
        const id = inp.id;
        if (id === 'f-hometown') p.basic.hometown = inp.value;
        if (id === 'f-birthday') p.basic.birthday = inp.value;
        if (id === 'f-phone') p.basic.phone = inp.value;
        if (id === 'f-constraints') p.constraints = inp.value.split(/[；;]/).map(x=>x.trim()).filter(Boolean);
        scheduleSave();
      });
    });
    // 评分
    root.querySelectorAll('[data-rating]').forEach(box => {
      box.querySelectorAll('.rating-item').forEach(item => {
        item.addEventListener('click', () => {
          box.querySelectorAll('.rating-item').forEach(x => x.classList.remove('selected'));
          item.classList.add('selected');
          const dim = box.dataset.rating;
          p.academic[dim] = parseInt(item.dataset.v, 10);
          if (p.abilitySelf) p.abilitySelf[dim] = parseInt(item.dataset.v, 10);
          scheduleSave();
        });
      });
    });
    // 多选 chips
    ['f-interests','f-values'].forEach(id => {
      root.querySelectorAll('#'+id + ' .chip-tag').forEach(chip => {
        chip.addEventListener('click', () => {
          chip.classList.toggle('selected');
          const arr = id === 'f-interests' ? p.interestPrefs : p.values;
          const v = chip.dataset.val;
          if (chip.classList.contains('selected')) { if (!arr.includes(v)) arr.push(v); }
          else { const i = arr.indexOf(v); if (i >= 0) arr.splice(i,1); }
          scheduleSave();
        });
      });
    });

    // 实践经历列表
    function renderExps() {
      const box = root.querySelector('#exp-list');
      box.innerHTML = (p.experiences||[]).map((e,i) => `
        <div class="card card-pad-md" style="margin-bottom:10px">
          <div class="row between">
            <div><span class="badge badge-teal">${esc(e.type)}</span><span class="small muted" style="margin-left:8px">${esc(e.date)}</span></div>
            <button class="btn btn-paper btn-sm" data-del-exp="${i}">删除</button>
          </div>
          <div style="font-weight:700;margin-top:8px">${esc(e.title)}</div>
          <div class="small" style="color:var(--muted);margin-top:3px">${esc(e.desc)}</div>
        </div>`).join('');
      box.querySelectorAll('[data-del-exp]').forEach(b => b.addEventListener('click', () => {
        p.experiences.splice(parseInt(b.dataset.delExp,10),1);
        saveS(); renderExps();
      }));
    }
    renderExps();
    root.querySelector('#add-exp').addEventListener('click', () => {
      modal({
        title:'新增经历',
        body: h(`<div class="field"><label>类别</label>
          <select class="input" id="exp-type"><option>竞赛</option><option>项目</option><option>学生工作</option><option>志愿服务</option></select></div>
          <div class="field"><label>标题</label><input class="input" id="exp-title" placeholder="如 数学建模校赛二等奖"></div>
          <div class="field"><label>时间</label><input class="input" id="exp-date" placeholder="如 2026-05"></div>
          <div class="field"><label>描述</label><textarea class="textarea" id="exp-desc" placeholder="简述你的角色与成果"></textarea></div>`),
        foot: ft => {
          const cancel = h(`<button class="btn btn-paper">取消</button>`);
          const ok = h(`<button class="btn btn-primary">保存</button>`);
          ft.append(cancel, ok);
          cancel.addEventListener('click', () => ft.closest('.modal-mask').remove());
          ok.addEventListener('click', () => {
            const m = ft.closest('.modal-mask');
            const title = m.querySelector('#exp-title').value.trim();
            if (!title) { toast('请填写标题', 'error'); return; }
            p.experiences = p.experiences || [];
            p.experiences.push({ type:m.querySelector('#exp-type').value, title, date:m.querySelector('#exp-date').value, desc:m.querySelector('#exp-desc').value });
            p.complete = Math.min(100, (p.complete||70) + 5);
            saveS(); renderExps(); m.remove(); toast('经历已保存', 'success');
          });
        },
      });
    });

    // 一键模拟填写
    root.querySelector('#auto-fill').addEventListener('click', () => {
      p.basic = { gender:'男', hometown:'重庆', birthday:'2008-05-14', phone:'138****6721' };
      p.academic = { math:4, english:3, programming:2 };
      p.abilitySelf = { programming:2, math:4, english:3, communication:4, organization:3 };
      p.interestPrefs = ['编程','算法','电子制作'];
      p.values = ['成长','技术挑战'];
      p.developmentIntention = 'employment';
      p.constraints = ['愿意在课余投入学习','优先考虑川渝地区'];
      p.complete = 92;
      saveS();
      toast('已填入示例数据', 'success');
      navigate('/student/profile'); // 重渲染
    });

    // 保存并继续
    root.querySelector('#save-goto').addEventListener('click', () => {
      const total = (p.experiences||[]).length;
      p.complete = Math.min(100, 68 + total * 8);
      saveS();
      toast('资料已保存', 'success');
      navigate('/student/assessment');
    });
  },

  /* ============================================================
     测评
     ============================================================ */
  assessment(appEl) {
    const s = studentState();
    const doneMods = s.assessment.moduleState || {};
    let modIdx = 0;
    const mods = QUESTIONNAIRES;

    function body() {
      const m = mods[modIdx];
      const answers = s.assessment.answers || {};
      const answered = (qz, qi) => {
        const q = qz.questions[qi];
        if (q.type === 'rating') {
          const r = answers[`${qz.id}-q${qi}`];
          return r ? Object.values(r).filter(Boolean).length > 0 : false;
        }
        return !!answers[`${qz.id}-q${qi}`];
      };
      const qCount = m.questions.length;
      const answeredCount = m.questions.reduce((n, _, i) => n + (answered(m,i) ? 1 : 0), 0);

      const stepper = `<div class="stepper">${mods.map((x, i) => `
        <div class="s-item ${i < modIdx ? 'done' : i === modIdx ? 'current' : ''}">
          <span class="s-dot">${i < modIdx ? '✓' : i+1}</span><span class="s-label">${x.name.split('·')[0].replace('霍兰德兴趣简版','兴趣').replace('职业价值观','价值观').replace('能力自评','能力').replace('专业认知与发展倾向','倾向')}</span>
        </div>`).join('')}</div>`;

      const qs = m.questions.map((q, qi) => {
        const key = `${m.id}-q${qi}`;
        const saved = answers[key];
        if (q.type === 'rating') {
          const dims = q.opts.map((o, i) => ({ dim: ['programming','math','english','communication','organization'][i] || 'x', label: q.opts[i] }));
          return `<div class="card card-pad mb12">
            <div style="font-weight:700;font-size:15px">${qi+1}. ${q.q}</div>
            <div class="small muted mb12" style="margin-top:2px">请按当前真实水平评估</div>
            <div class="rating-row" data-q="${key}">
              ${q.labels.map((lb,i) => {
                const cur = (saved && saved[dims[i].dim]) || null;
                return `<div class="rating-item ${cur===i+1?'selected':''}" data-v="${i+1}"><b>${i+1}</b><span>${lb}</span></div>`;
              }).join('')}
            </div>
            <div class="hint small faint" style="margin-top:8px">${dims.map(d=>d.label).join(' · ')} 分别打分</div>
          </div>`;
        }
        return `<div class="card card-pad mb12">
          <div style="font-weight:700;font-size:15px">${qi+1}. ${q.q}</div>
          <div class="radio-grid mt12">
            ${q.options.map((o, oi) => `<div class="radio-card ${saved===o.text?'selected':''}" data-q="${key}" data-val="${esc(o.text)}"><span class="dot"></span>${o.text}</div>`).join('')}
          </div>
        </div>`;
      }).join('');

      return `
      <div class="page-head">
        <div class="eyebrow">Step 03 · 生涯测评</div>
        <h1>${m.icon} ${m.name}</h1>
        <p>${esc(m.tip)} · 共 ${qCount} 题 · 预计 ${m.minutes} 分钟</p>
      </div>
      ${stepper}
      <div class="row gap8 mb12" style="align-items:center">
        ${progressBar(answeredCount / qCount * 100, 6)}
        <span class="small faint" style="flex:none">${answeredCount}/${qCount}</span>
      </div>
      ${qs}
      <div class="row gap8 mt16">
        ${modIdx > 0 ? `<button class="btn btn-paper" id="prev-mod">上一模块</button>` : ''}
        <div style="flex:1"></div>
        <button class="btn btn-soft" id="auto-mod">自动模拟作答</button>
        ${modIdx < mods.length - 1
          ? `<button class="btn btn-primary" id="next-mod">下一模块 →</button>`
          : `<button class="btn btn-copper btn-lg" id="submit-mod">提交测评并生成画像</button>`}
      </div>`;
    }

    function saveAnswer(key, val) {
      s.assessment.answers = s.assessment.answers || {};
      s.assessment.answers[key] = val;
      s.assessment.moduleState = s.assessment.moduleState || {};
      saveS();
    }
    function currentModuleAnsweredCount() {
      const m = mods[modIdx]; const answers = s.assessment.answers || {};
      let n = 0;
      m.questions.forEach((q, qi) => {
        const key = `${m.id}-q${qi}`;
        if (q.type === 'rating') { const r = answers[key]; if (r && Object.values(r).filter(Boolean).length) n++; }
        else if (answers[key]) n++;
      });
      return n;
    }

    function paint() {
      appEl.querySelector('.app-frame main').innerHTML = body();
      wire();
    }
    function wire() {
      const root = appEl.querySelector('.app-frame');
      // 选择题
      root.querySelectorAll('.radio-card[data-q]').forEach(el => {
        el.addEventListener('click', () => {
          const key = el.dataset.q;
          const group = el.parentElement;
          group.querySelectorAll('.radio-card').forEach(x => x.classList.remove('selected'));
          el.classList.add('selected');
          saveAnswer(key, el.dataset.val);
          paint();
        });
      });
      // 评分题
      root.querySelectorAll('[data-q].rating-row').forEach(box => {
        box.querySelectorAll('.rating-item').forEach(item => {
          item.addEventListener('click', () => {
            const key = box.dataset.q;
            const idx = [...box.querySelectorAll('.rating-item')].indexOf(item);
            const r = s.assessment.answers[key] || {};
            r[['programming','math','english','communication','organization'][idx]] = parseInt(item.dataset.v, 10);
            saveAnswer(key, r);
            paint();
          });
        });
      });
      // 模块导航
      const prev = root.querySelector('#prev-mod');
      if (prev) prev.addEventListener('click', () => { modIdx--; paint(); });
      const nxt = root.querySelector('#next-mod');
      if (nxt) nxt.addEventListener('click', () => {
        if (currentModuleAnsweredCount() < mods[modIdx].questions.length) {
          toast(`本模块还有 ${mods[modIdx].questions.length - currentModuleAnsweredCount()} 题未作答，可用"自动模拟作答"快速完成`, 'error');
          return;
        }
        modIdx++; paint();
      });
      const auto = root.querySelector('#auto-mod');
      if (auto) auto.addEventListener('click', () => {
        const m = mods[modIdx];
        const answers = s.assessment.answers = s.assessment.answers || {};
        m.questions.forEach((q, qi) => {
          const key = `${m.id}-q${qi}`;
          if (q.type === 'rating') {
            const r = {};
            q.opts.forEach((_, i) => { r[['programming','math','english','communication','organization'][i]] = (i%4)+1; });
            answers[key] = r;
          } else {
            answers[key] = q.options[qi % q.options.length].text;
          }
        });
        saveS(); paint(); toast('已模拟作答', 'success');
      });
      const sub = root.querySelector('#submit-mod');
      if (sub) sub.addEventListener('click', () => {
        finishAssessment();
      });
    }

    function finishAssessment() {
      const answers = s.assessment.answers || {};
      // 校验四模块均完成
      let missing = 0;
      QUESTIONNAIRES.forEach(m => m.questions.forEach((q, qi) => {
        const key = `${m.id}-q${qi}`;
        if (q.type === 'rating') { if (!answers[key] || !Object.values(answers[key]).filter(Boolean).length) missing++; }
        else if (!answers[key]) missing++;
      }));
      if (missing > 0) { toast(`还有 ${missing} 题未作答，请先完成或自动模拟作答`, 'error'); return; }

      const scores = AppCore.computeScores(answers);
      s.assessment.completed = true;
      s.assessment.finishedAt = nowFull();
      s.assessment.scores = scores;
      s.assessment.moduleState = { holland:'done', values:'done', ability:'done', tendency:'done' };
      // 同步画像与推荐
      s.portrait = AppCore.generatePortrait(scores, s.profile);
      s.recommendation = AppCore.runRecommendation(scores, s.profile);
      saveS();
      toast('测评完成，六维画像已生成', 'success');
      navigate('/student/portrait');
    }

    renderStudentShell(body(), 'home');
    wire();
  },

  /* ============================================================
     六维画像
     ============================================================ */
  portrait(appEl) {
    const s = studentState();
    if (!s.portrait) {
      renderStudentShell(emptyState('🧩','画像尚未生成','完成测评后，系统会基于测评与自主填报生成六维画像。',''), 'portrait');
      appEl.querySelector('.empty').appendChild(h(`<button class="btn btn-primary btn-sm mt16" data-g="/student/assessment">去完成测评</button>`));
      appEl.querySelector('[data-g]').addEventListener('click', () => navigate('/student/assessment'));
      return;
    }
    const sc = currentScores();
    const port = s.portrait;
    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 04 · 学生画像</div>
      <h1>我的六维画像</h1>
      <p>由测评（v2）+ 自主填报（v3）生成 · ${esc(port.generatedAt)}</p>
    </div>

    <div class="card card-pad">
      <div class="row between mb12">
        <div class="card-title">维度得分</div>
        <span class="badge badge-teal">画像 v${port.version}</span>
      </div>
      <div class="radar-wrap">
        <div>${radarSVG(scoresToDimValues(sc), 220)}</div>
        <div class="radar-legend">
          ${DIMS.map(d => {
            const v = sc[d.key] || 0;
            const color = v >= 70 ? 'var(--teal)' : v >= 50 ? 'var(--amber)' : 'var(--faint)';
            return `<div class="li"><span style="width:52px">${d.name}</span><span class="bar"><i style="width:${v}%;background:${color}"></i></span><span class="val">${v}</span></div>`;
          }).join('')}
        </div>
      </div>
      <div class="row gap8 mt12">
        ${ringSVG(port.completeness, 56, '#C67B34', '完整度')}
        <div class="small muted" style="max-width:240px">数据完整度反映画像可靠程度，完整度越高，推荐的可信程度越高。</div>
      </div>
    </div>

    <div class="card card-pad mt16">
      <div class="card-title">画像摘要</div>
      <p style="font-size:14px;line-height:1.85;margin-top:8px">${esc(port.summary)}</p>
    </div>

    <div class="card card-pad mt16">
      <div class="card-title">当前优势</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:8px">
        ${port.strengths.map(t => `<li style="display:flex;gap:8px;font-size:13.5px"><span style="color:var(--green);font-weight:700">✓</span>${esc(t)}</li>`).join('')}
      </ul>
      <div class="card-title mt16">待探索问题</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:8px">
        ${port.explore.map(t => `<li style="display:flex;gap:8px;font-size:13.5px"><span style="color:var(--amber);font-weight:700">↗</span>${esc(t)}</li>`).join('')}
      </ul>
    </div>

    <div class="card card-pad mt16">
      <div class="card-title">画像反馈</div>
      <p class="small muted" style="margin:6px 0 10px">用于改进画像描述，不影响计分结果</p>
      <div class="row gap8" id="fb-row">
        ${[['fit','符合'],['partial','部分符合'],['not','不符合']].map(([k,lb]) => `<button class="btn btn-soft btn-sm ${port.feedback===k?'':''}" data-fb="${k}" style="${port.feedback===k?'box-shadow:0 0 0 2px var(--amber)':''}">${lb}</button>`).join('')}
      </div>
      <div class="row gap8 mt16">
        <a class="btn btn-ghost btn-sm" href="#/student/recommendations">查看方向推荐 →</a>
        <button class="btn btn-paper btn-sm" id="recompute" style="margin-left:auto">重新计算画像</button>
      </div>
    </div>`;

    renderStudentShell(html, 'portrait');
    appEl.querySelector('#fb-row').querySelectorAll('[data-fb]').forEach(b => b.addEventListener('click', () => {
      s.portrait.feedback = b.dataset.fb;
      saveS(); toast('反馈已记录，感谢你的反馈', 'success');
      b.style.boxShadow = '0 0 0 2px var(--amber)';
    }));
    appEl.querySelector('#recompute').addEventListener('click', () => {
      const scores = currentScores() || AppCore.computeScores(s.assessment.answers || {});
      s.portrait = AppCore.generatePortrait(scores, s.profile);
      saveS(); toast('画像已基于最新数据重新计算', 'success'); navigate('/student/portrait');
    });
  },

  /* ============================================================
     路径探索与方向库
     ============================================================ */
  directions(appEl) {
    const s = studentState();
    const favs = s.favorites || [];
    const compare = [];
    let activePath = (s.profile && s.profile.developmentIntention) || 'employment';
    if (!PATHS[activePath]) activePath = 'employment';

    function dirsOf(path) { return DIRECTIONS.filter(d => d.path === path && d.status === 'published'); }

    function body() {
      const list = dirsOf(activePath);
      return `
      <div class="page-head">
        <div class="eyebrow">Step 05 · 路径探索</div>
        <h1>发展路径与方向</h1>
        <p>三条一级路径下共 ${DIRECTIONS.filter(d=>d.status==='published').length} 个方向，可收藏与对比。</p>
      </div>
      <div class="path-row mb16">
        ${Object.values(PATHS).map(pt => `
          <div class="path-tab ${pt.id===activePath?'active':''}" data-path="${pt.id}">
            <div class="pt-name"><span class="pt-dot"></span>${pt.name}</div>
            <div class="pt-desc">${pt.desc}</div>
          </div>`).join('')}
      </div>
      <div class="row gap8 mb12">
        <span class="small muted">${list.length} 个方向 · 点击卡片查看详情</span>
        ${compare.length ? `<button class="btn btn-copper btn-sm" id="go-compare" style="margin-left:auto">对比已选 ${compare.length} 个 →</button>` : ''}
      </div>
      <div class="row" style="display:grid;gap:12px">
        ${list.map(d => `
          <div class="dir-card">
            <div class="dc-top">
              <div class="dc-icon">${d.icon}</div>
              <div class="grow">
                <div class="dc-name">${d.name}</div>
                <div class="dc-path">${PATHS[d.path].name}路径</div>
              </div>
              <button class="btn btn-paper btn-sm" data-fav="${d.id}" aria-label="收藏">${favs.includes(d.id) ? '<span style="color:var(--amber)">★</span>' : '☆'}</button>
              <button class="btn btn-paper btn-sm" data-cmp="${d.id}" aria-label="加入对比">${compare.includes(d.id) ? '✓' : '⊕'}</button>
            </div>
            <div class="dc-intro">${esc(d.intro)}</div>
            <div class="dc-meta">
              ${badge(d.abilities.slice(0,3).join(' · '), 'teal')}
              <span class="badge badge-gray">更新于 ${d.updated}</span>
            </div>
            <div class="dc-actions">
              <button class="btn btn-soft btn-sm grow" data-open="${d.id}">查看详情</button>
              <button class="btn btn-ghost btn-sm" data-open2="${d.id}" style="border-style:dashed">${esc(PATHS[d.path].name)}</button>
            </div>
          </div>`).join('')}
      </div>
      ${compare.length >= 2 ? `
      <div class="compare-panel"><div class="compare-inner">
        <span>已选择 ${compare.length} 个方向</span>
        <span class="grow small" style="opacity:.8">${compare.map(id=>DIRECTIONS.find(d=>d.id===id).name).join(' vs ')}</span>
        <button class="btn btn-copper btn-sm" id="go-compare2">对比</button>
      </div></div>` : ''}`;
    }

    function paint() {
      appEl.querySelector('.app-frame main').innerHTML = body();
      wire();
    }
    function wire() {
      const root = appEl.querySelector('.app-frame');
      root.querySelectorAll('.path-tab').forEach(t => t.addEventListener('click', () => {
        activePath = t.dataset.path; paint();
      }));
      root.querySelectorAll('[data-open],[data-open2]').forEach(b => b.addEventListener('click', () => navigate('/student/directions/' + (b.dataset.open || b.dataset.open2))));
      root.querySelectorAll('[data-fav]').forEach(b => b.addEventListener('click', () => {
        const id = b.dataset.fav;
        const i = favs.indexOf(id);
        if (i >= 0) { favs.splice(i,1); toast('已取消收藏'); }
        else { favs.push(id); toast('已收藏，会优先参与推荐', 'success'); }
        saveS(); paint();
      }));
      root.querySelectorAll('[data-cmp]').forEach(b => b.addEventListener('click', () => {
        const id = b.dataset.cmp;
        const i = compare.indexOf(id);
        if (i >= 0) { compare.splice(i,1); }
        else { if (compare.length >= 3) { toast('最多对比 3 个方向', 'error'); return; } compare.push(id); }
        paint();
      }));
      const gc = root.querySelector('#go-compare') || root.querySelector('#go-compare2');
      if (gc) gc.addEventListener('click', () => { if (compare.length < 2) { toast('请至少选择 2 个方向', 'error'); return; } showCompare(); });
    }
    function showCompare() {
      const items = compare.map(id => DIRECTIONS.find(d => d.id === id)).filter(Boolean);
      modal({
        title: '方向对比',
        body: h(`<div style="overflow-x:auto"><table class="data" style="min-width:420px">
          <tr><th>维度</th>${items.map(d=>`<th>${d.icon} ${d.name}</th>`).join('')}</tr>
          <tr><td class="cell-main">所属路径</td>${items.map(d=>`<td>${PATHS[d.path].name}</td>`).join('')}</tr>
          <tr><td class="cell-main">核心能力</td>${items.map(d=>`<td class="small">${esc(d.abilities.join('、'))}</td>`).join('')}</tr>
          <tr><td class="cell-main">推荐课程</td>${items.map(d=>`<td class="small">${esc(d.courses.slice(0,2).join('；'))}</td>`).join('')}</tr>
          <tr><td class="cell-main">首期实践</td>${items.map(d=>`<td class="small">${esc(d.activities[0])}</td>`).join('')}</tr>
          <tr><td class="cell-main">常见误区</td>${items.map(d=>`<td class="small">${esc(d.misconceptions[0])}</td>`).join('')}</tr>
        </table></div>`),
        foot: ft => ft.append(h(`<button class="btn btn-primary btn-sm">知道了</button>`, {})),
      });
    }

    renderStudentShell(body(), 'directions');
    wire();
  },

  directionDetail(appEl, params) {
    const d = DIRECTIONS.find(x => x.id === params.id);
    if (!d) { navigate('/404'); return; }
    const s = studentState();
    const favs = s.favorites || [];
    const html = `
    <div class="page-head">
      <div class="eyebrow"><a href="#/student/directions" style="color:var(--amber-d)">← 返回方向库</a></div>
      <h1 style="display:flex;align-items:center;gap:10px">${d.icon} ${d.name}</h1>
      <p>${PATHS[d.path].name}路径 · 更新于 ${d.updated}</p>
    </div>
    <div class="row gap8 mb12">
      ${badge('已发布', 'green')}
      <span class="badge badge-gray">${d.abilities.join(' · ')}</span>
    </div>

    <div class="card card-pad">
      <div class="card-title">方向简介</div>
      <p style="font-size:14px;line-height:1.85;margin-top:8px">${esc(d.intro)}</p>
    </div>
    <div class="card card-pad mt16">
      <div class="card-title">学习内容</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:7px">
        ${d.learning.map(t=>`<li style="display:flex;gap:8px;font-size:13.5px"><span style="color:var(--teal);font-weight:700">·</span>${esc(t)}</li>`).join('')}
      </ul>
    </div>
    <div class="card card-pad mt16">
      <div class="card-title">能力要求</div>
      <div class="row gap8 mt12 wrap">${d.abilities.map(a=>badge(a,'teal')).join('')}</div>
      <div class="card-title mt16">推荐课程</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:7px">${d.courses.map(t=>`<li style="font-size:13.5px">· ${esc(t)}</li>`).join('')}</ul>
    </div>
    <div class="card card-pad mt16">
      <div class="card-title">实践活动建议</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:7px">${d.activities.map((t,i)=>`<li style="font-size:13.5px"><b style="color:var(--amber-d)">${i+1}</b> · ${esc(t)}</li>`).join('')}</ul>
    </div>
    <div class="card card-pad mt16">
      <div class="card-title">发展路径</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:9px">
        ${d.pathDesc.map((t,i)=>`<li style="display:flex;gap:10px;font-size:13.5px"><span style="flex:none;width:20px;height:20px;border-radius:7px;background:var(--teal-s);color:var(--teal-d);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700">${i+1}</span>${esc(t)}</li>`).join('')}
      </ul>
    </div>
    <div class="card card-pad mt16" style="border-color:var(--amber-s);background:var(--amber-l)">
      <div class="card-title" style="color:var(--amber-d)">常见误区</div>
      <ul class="mt12" style="list-style:none;display:grid;gap:7px">
        ${d.misconceptions.map(t=>`<li style="display:flex;gap:8px;font-size:13.5px"><span style="color:var(--amber-d)">⚠</span>${esc(t)}</li>`).join('')}
      </ul>
    </div>
    <div class="row gap8 mt16">
      <button class="btn btn-paper" id="fav-dir" style="flex:1">${favs.includes(d.id)?'★ 已收藏':'☆ 收藏方向'}</button>
      <button class="btn btn-primary btn-lg" style="flex:2" id="to-plan">以此方向生成学期计划</button>
    </div>`;

    renderStudentShell(html, 'directions');
    appEl.querySelector('#fav-dir').addEventListener('click', () => {
      const i = favs.indexOf(d.id);
      if (i >= 0) { favs.splice(i,1); } else { favs.push(d.id); toast('已收藏','success'); }
      saveS(); navigate('/student/directions/' + d.id);
    });
    appEl.querySelector('#to-plan').addEventListener('click', () => {
      const plan = AppCore.generatePlan(d.id);
      if (!plan) { toast('该方向暂无计划模板', 'error'); return; }
      // 同步目标与计划
      s.goal = { primary:{ directionId:d.id, name:d.name, chosenAt:nowFull() }, backup: s.goal ? s.goal.backup : null, version:'G-v1' };
      s.plan = plan;
      s.tasks = AppCore.buildTasksFromPlan(plan);
      saveS();
      toast(`已按「${d.name}」生成学期计划草案`, 'success');
      navigate('/student/plan');
    });
  },

  /* ============================================================
     方向推荐
     ============================================================ */
  recommendations(appEl) {
    const s = studentState();
    if (!s.recommendation || !s.recommendation.results.length) {
      renderStudentShell(emptyState('✨','暂无推荐结果','完成测评生成画像后，即可获得 3—5 个可解释的方向推荐。',''), 'directions');
      appEl.querySelector('.empty').appendChild(h(`<button class="btn btn-primary btn-sm mt16" id="go-assess">去完成测评</button>`));
      appEl.querySelector('#go-assess').addEventListener('click', () => navigate('/student/assessment'));
      return;
    }
    const rec = s.recommendation;
    const confMap = { HIGH:{label:'可信程度较高', type:'green'}, MEDIUM:{label:'可信程度一般', type:'amber'}, LOW:{label:'可信程度较低 · 建议继续探索', type:'gray'} };

    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 06 · 方向推荐</div>
      <h1>为你推荐的方向</h1>
      <p>基于规则过滤与六维评分，规则版本 ${rec.ruleVersion} · 画像 v${rec.profileVersion} · 生成于 ${rec.generatedAt.slice(5,16)}</p>
    </div>
    <div class="row gap8 mb12">
      ${badge(confMap[rec.confidence].label, confMap[rec.confidence].type)}
      <span class="small muted">可信程度不是概率，用于提示数据与结果的一致性</span>
    </div>
    ${rec.results.map((r, i) => {
      const dir = DIRECTIONS.find(d => d.id === r.directionId);
      const isPrimary = s.goal && s.goal.primary && s.goal.primary.directionId === r.directionId;
      const isBackup = s.goal && s.goal.backup && s.goal.backup.directionId === r.directionId;
      return `
      <div class="rec-card mb16">
        <div class="rc-head">
          <div class="row between">
            <div class="row gap12">
              <div class="rank">${i+1}</div>
              <div>
                <div style="font-size:17px;font-weight:800">${dir ? dir.icon + ' ' : ''}${r.name}</div>
                <div class="small muted">${dir ? PATHS[dir.path].name : ''}路径 · ${badge(confMap[r.confidence]?.label || '', 'gray')}</div>
              </div>
            </div>
            <div style="text-align:right">
              <div class="rc-score">${r.targetScore}<span class="small" style="font-weight:400;color:var(--muted)"> 分</span></div>
              <div class="small faint">综合匹配分</div>
            </div>
          </div>
        </div>
        <div class="rc-body">
          <div class="rc-section"><div class="rs-title">为什么推荐给我</div>
            <ul class="rc-reasons">${r.reasons.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>
          <div class="rc-section"><div class="rs-title">匹配优势</div>
            <ul class="rc-strengths">${r.strengths.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>
          <div class="rc-section"><div class="rs-title">主要差距</div>
            <ul class="rc-gaps">${r.gaps.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>
          <div class="rc-section"><div class="rs-title">本学期探索建议</div>
            <ul class="rc-actions">${r.semesterActions.map(t=>`<li>${esc(t)}</li>`).join('')}</ul></div>
        </div>
        <div class="rc-foot">
          <div class="row gap8">
            <button class="btn ${isPrimary ? 'btn-copper' : 'btn-ghost'} btn-sm" data-primary="${r.directionId}">${isPrimary ? '✓ 当前主目标' : '设为主目标'}</button>
            <button class="btn ${isBackup ? 'btn-soft' : 'btn-paper'} btn-sm" data-backup="${r.directionId}">${isBackup ? '✓ 备选' : '设为备选'}</button>
          </div>
          <div class="row gap6">
            ${['有帮助','一般','不感兴趣'].map((f,fi) => `<button class="btn btn-paper btn-sm" data-fb="${fi+1}">${f}</button>`).join('')}
          </div>
        </div>
      </div>`;
    }).join('')}

    <div class="card card-pad mt16" style="border-color:var(--amber-s);background:var(--amber-l)">
      <div class="row gap8" style="align-items:flex-start">
        <span style="color:var(--amber-d);font-size:16px">ℹ️</span>
        <div class="small" style="color:var(--muted)">
          推荐用于探索参考：大模型仅负责转写解释，<b>不决定排序</b>。若数据缺失较多，推荐可信程度会降低，建议先完善资料再重新生成。
        </div>
      </div>
      <button class="btn btn-soft btn-sm mt12" id="regenerate">重新生成（基于最新画像与规则）</button>
    </div>`;

    renderStudentShell(html, 'directions');
    const root = appEl.querySelector('.app-frame');
    root.querySelectorAll('[data-primary]').forEach(b => b.addEventListener('click', () => {
      const dir = DIRECTIONS.find(d => d.id === b.dataset.primary);
      s.goal = { primary:{ directionId:dir.id, name:dir.name, chosenAt:nowFull() }, backup: s.goal ? s.goal.backup : null, version:'G-v2' };
      saveS();
      toast(`已设「${dir.name}」为主目标`, 'success');
      navigate('/student/recommendations');
    }));
    root.querySelectorAll('[data-backup]').forEach(b => b.addEventListener('click', () => {
      const dir = DIRECTIONS.find(d => d.id === b.dataset.backup);
      if (s.goal && s.goal.primary && s.goal.primary.directionId === dir.id) { toast('主目标与备选目标不能相同', 'error'); return; }
      s.goal = { primary: s.goal ? s.goal.primary : null, backup:{ directionId:dir.id, name:dir.name, chosenAt:nowFull() }, version:'G-v2' };
      saveS();
      toast(`已设「${dir.name}」为备选目标`, 'success');
      navigate('/student/recommendations');
    }));
    root.querySelectorAll('[data-fb]').forEach(b => b.addEventListener('click', () => {
      toast('反馈已记录（不会立即改变推荐结果）', 'success');
      b.disabled = true;
    }));
    root.querySelector('#regenerate').addEventListener('click', () => {
      const scores = currentScores();
      s.recommendation = AppCore.runRecommendation(scores, s.profile);
      saveS();
      toast('已按最新规则重新生成推荐', 'success');
      navigate('/student/recommendations');
    });
  },

  /* ============================================================
     目标
     ============================================================ */
  goals(appEl) {
    const s = studentState();
    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 06 · 目标选择</div>
      <h1>我的生涯目标</h1>
      <p>可自主选择 1 个主目标 + 1 个备选目标，辅导员可建议但不审批。</p>
    </div>
    <div class="card card-pad">
      <div class="card-title">主目标</div>
      ${s.goal && s.goal.primary ? `
        <div class="dir-card mt12" style="border-color:var(--teal)">
          <div class="row between">
            <div class="row gap12">
              <div class="dc-icon">${(DIRECTIONS.find(d=>d.id===s.goal.primary.directionId)||{}).icon||'🎯'}</div>
              <div><div style="font-weight:800;font-size:16px">${esc(s.goal.primary.name)}</div>
              <div class="small muted">${esc(s.goal.primary.chosenAt)}</div></div>
            </div>
            <button class="btn btn-paper btn-sm" id="clear-primary">更换</button>
          </div>
        </div>` : emptyState('🎯','尚未设置主目标','在推荐结果中选择，或前往方向库浏览后设定。','')}
    </div>
    <div class="card card-pad mt16">
      <div class="card-title">备选目标</div>
      ${s.goal && s.goal.backup ? `
        <div class="dir-card mt12" style="border-color:var(--amber)">
          <div class="row between">
            <div class="row gap12">
              <div class="dc-icon" style="background:var(--amber-s)">${(DIRECTIONS.find(d=>d.id===s.goal.backup.directionId)||{}).icon||'🎯'}</div>
              <div><div style="font-weight:800;font-size:16px">${esc(s.goal.backup.name)}</div>
              <div class="small muted">${esc(s.goal.backup.chosenAt)}</div></div>
            </div>
            <button class="btn btn-paper btn-sm" id="clear-backup">更换</button>
          </div>
        </div>` : emptyState('🔁','尚未设置备选目标','备选目标让你在多条路径之间保持灵活性。','')}
    </div>
    <div class="row gap8 mt16">
      <button class="btn btn-paper" id="g-directions" style="flex:1">去方向库浏览</button>
      <button class="btn btn-primary btn-lg" id="g-recs" style="flex:2">从推荐中选择 →</button>
    </div>`;

    renderStudentShell(html, 'directions');
    const c1 = appEl.querySelector('#clear-primary');
    if (c1) c1.addEventListener('click', () => { s.goal.primary = null; s.goal.version = 'G-v3'; saveS(); navigate('/student/goals'); });
    const c2 = appEl.querySelector('#clear-backup');
    if (c2) c2.addEventListener('click', () => { s.goal.backup = null; s.goal.version = 'G-v3'; saveS(); navigate('/student/goals'); });
    appEl.querySelector('#g-directions').addEventListener('click', () => navigate('/student/directions'));
    appEl.querySelector('#g-recs').addEventListener('click', () => navigate('/student/recommendations'));
  },

  /* ============================================================
     学期计划
     ============================================================ */
  plan(appEl) {
    const s = studentState();
    if (!s.plan) {
      renderStudentShell(emptyState('📝','还没有学期计划','选择主目标后，系统将依据目标与任务模板生成学期计划草案。',''), 'plan');
      appEl.querySelector('.empty').appendChild(h(`<button class="btn btn-primary btn-sm mt16" id="go-recs">去选择目标</button>`));
      appEl.querySelector('#go-recs').addEventListener('click', () => navigate('/student/recommendations'));
      return;
    }
    const plan = s.plan;
    const months = [...new Set(plan.monthlyTasks.map(t => t.month))];

    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 07 · 学期计划</div>
      <h1>${s.goal && s.goal.primary ? '围绕「' + s.goal.primary.name + '」的学期计划' : '学期计划'}</h1>
      <p>由目标 + 培养方案 + 任务模板生成草案，可编辑后确认。</p>
    </div>
    <div class="row gap8 mb12">
      ${plan.confirmed ? badge('已确认 · ' + plan.version, 'green') : badge('待确认 · AI 草案', 'amber')}
      <span class="small muted">${plan.source === 'ai' ? 'AI 生成' : '人工编辑'}</span>
    </div>

    <div class="card card-pad">
      <div class="card-title">学期目标摘要</div>
      <p class="small muted" style="margin:4px 0 8px">描述本学期想达成的整体状态</p>
      <textarea class="textarea" id="p-summary">${esc(plan.goalSummary)}</textarea>
    </div>

    <div class="card card-pad mt16">
      <div class="card-title">学期目标</div>
      <div id="p-goals" style="display:grid;gap:8px;margin-top:10px">
        ${plan.semesterGoals.map((g, i) => `
          <div class="row gap8">
            <span class="badge badge-teal" style="flex:none">${esc(g.abilityTag.replace('_',' '))}</span>
            <input class="input grow" data-goal="${i}" value="${esc(g.title)}">
            <button class="btn btn-paper btn-sm" data-del-goal="${i}">删</button>
          </div>`).join('')}
      </div>
      <button class="btn btn-soft btn-sm mt12" id="add-goal">＋ 添加学期目标</button>
    </div>

    ${months.map(m => {
      const monthTasks = plan.monthlyTasks.filter(t => t.month === m);
      return `
      <div class="card card-pad mt16">
        <div class="row between mb12">
          <div class="card-title">${m.slice(0,4)} 年 ${parseInt(m.slice(5),10)} 月任务</div>
          <span class="small faint">共 ${monthTasks.length} 项 · 约 ${monthTasks.reduce((n,t)=>n+t.estimatedHours,0)} 小时</span>
        </div>
        <div style="display:grid;gap:8px">
          ${monthTasks.map((t, ti) => `
            <div class="row gap8">
              <span class="badge ${({LEARNING:'teal',PRACTICE:'amber',CAREER:'blue',REVIEW:'gray'})[t.taskType]}">${({LEARNING:'学习',PRACTICE:'实践',CAREER:'规划',REVIEW:'复盘'})[t.taskType]}</span>
              <input class="input grow" data-task="${m}|${ti}" value="${esc(t.title)}">
              <span class="small faint" style="flex:none">${t.estimatedHours}h</span>
              <button class="btn btn-paper btn-sm" data-del-task="${m}|${ti}">删</button>
            </div>`).join('')}
        </div>
      </div>`;
    }).join('')}

    <div class="card card-pad mt16">
      <div class="card-title">注意事项</div>
      <p class="small muted" style="margin-top:6px">${esc(plan.notes.join(' '))}</p>
    </div>

    <div class="row gap8 mt16">
      <button class="btn btn-soft" id="regen-plan">按主目标重新生成草案</button>
      <div style="flex:1"></div>
      <button class="btn btn-primary btn-lg" id="confirm-plan">${plan.confirmed ? '已确认 · 仍可修改' : '确认并生成任务 →'}</button>
    </div>`;

    renderStudentShell(html, 'plan');
    const root = appEl.querySelector('.app-frame');
    root.querySelector('#p-summary').addEventListener('input', e => { plan.goalSummary = e.target.value; saveS(); });
    root.querySelector('#p-goals').querySelectorAll('[data-goal]').forEach(inp => inp.addEventListener('input', () => {
      plan.semesterGoals[inp.dataset.goal].title = inp.value; saveS();
    }));
    root.querySelector('#add-goal').addEventListener('click', () => {
      plan.semesterGoals.push({ title:'新目标', abilityTag:'project_basic' }); saveS(); navigate('/student/plan');
    });
    root.querySelectorAll('[data-del-goal]').forEach(b => b.addEventListener('click', () => {
      plan.semesterGoals.splice(parseInt(b.dataset.delGoal,10),1); saveS(); navigate('/student/plan');
    }));
    root.querySelectorAll('[data-task]').forEach(inp => inp.addEventListener('input', () => {
      const [m, ti] = inp.dataset.task.split('|');
      const t = plan.monthlyTasks.find(t => t.month === m);
      const items = plan.monthlyTasks.filter(x => x.month === m);
      items[parseInt(ti,10)].title = inp.value; saveS();
    }));
    root.querySelectorAll('[data-del-task]').forEach(b => b.addEventListener('click', () => {
      const [m, ti] = b.dataset.delTask.split('|');
      const items = plan.monthlyTasks.filter(x => x.month === m);
      plan.monthlyTasks.splice(plan.monthlyTasks.indexOf(items[parseInt(ti,10)]),1);
      saveS(); navigate('/student/plan');
    }));
    root.querySelector('#regen-plan').addEventListener('click', () => {
      const d = s.goal && s.goal.primary ? s.goal.primary.directionId : 'employment_backend';
      const np = AppCore.generatePlan(d);
      s.plan = np; s.tasks = AppCore.buildTasksFromPlan(np); saveS();
      toast('已按主目标重新生成草案', 'success'); navigate('/student/plan');
    });
    root.querySelector('#confirm-plan').addEventListener('click', () => {
      plan.confirmed = true; plan.confirmedAt = nowFull(); plan.version = 'P-v2';
      if (!s.tasks || !s.tasks.length) s.tasks = AppCore.buildTasksFromPlan(plan);
      saveS(); toast('计划已确认，任务已生成', 'success'); navigate('/student/tasks');
    });
  },

  /* ============================================================
     任务看板
     ============================================================ */
  tasks(appEl) {
    const s = studentState();
    if (!s.tasks || !s.tasks.length) {
      renderStudentShell(emptyState('✅','还没有任务','确认学期计划后，将自动生成按月拆解的任务清单。',''), 'plan');
      appEl.querySelector('.empty').appendChild(h(`<button class="btn btn-primary btn-sm mt16" id="go-plan">去确认计划</button>`));
      appEl.querySelector('#go-plan').addEventListener('click', () => navigate('/student/plan'));
      return;
    }
    let filter = 'all';

    function body() {
      const months = [...new Set(s.tasks.map(t => t.month))].sort();
      let list = s.tasks.slice();
      if (filter !== 'all') list = list.filter(t => t.status === filter);
      const counts = {};
      s.tasks.forEach(t => counts[t.status] = (counts[t.status] || 0) + 1);
      return `
      <div class="page-head">
        <div class="eyebrow">Step 08 · 任务记录</div>
        <h1>任务看板</h1>
        <p>按月记录任务状态与行动说明，支持五类状态流转。</p>
      </div>
      <div class="card card-pad mb12">
        <div class="row gap8" style="flex-wrap:wrap">
          ${Object.entries(TASK_STATUS).map(([k,v]) => `<button class="btn btn-sm ${filter===k?'btn-copper':'btn-paper'}" data-f="${k}">${v.label} ${counts[k]||0}</button>`).join('')}
          <button class="btn btn-sm ${filter==='all'?'btn-copper':'btn-paper'}" data-f="all">全部 ${s.tasks.length}</button>
        </div>
      </div>
      ${months.map(m => {
        const mTasks = list.filter(t => t.month === m);
        if (!mTasks.length) return '';
        const doneN = mTasks.filter(t => t.status === 'done').length;
        return `
        <div class="section-title">${m.slice(0,4)} 年 ${parseInt(m.slice(5),10)} 月
          <span class="small muted" style="font-weight:400">${doneN}/${mTasks.length} 已完成</span>
        </div>
        <div class="kanban mb12">
          ${mTasks.map(t => `
            <div class="card task-item ${t.status==='done'?'done':''}">
              <div class="t-check">
                <button class="task-check ${t.status==='done'?'done':(t.status==='doing'?'some':'')}" data-check="${t.id}" aria-label="标记完成">${t.status==='done'?'✓':''}</button>
              </div>
              <div class="t-body">
                <div class="t-title">${esc(t.title)}</div>
                <div class="t-meta">
                  ${badge(({LEARNING:'学习',PRACTICE:'实践',CAREER:'规划',REVIEW:'复盘'})[t.type] || '任务', 'gray')}
                  ${taskBadge(t.status)}
                  <span class="small faint">约 ${t.estHours} 小时</span>
                  ${t.checkedInAt ? `<span class="small faint">打卡于 ${esc(t.checkedInAt)}</span>` : ''}
                </div>
                ${t.note ? `<div class="t-note">${esc(t.note)}</div>` : ''}
                <div class="row gap6 mt12" style="flex-wrap:wrap">
                  ${[['doing','进行中'],['done','已完成'],['later','延期'],['abandon','放弃'],['pending','未开始']].map(([st,lb]) =>
                    `<button class="btn btn-sm ${t.status===st?'btn-soft':'btn-paper'}" data-status="${st}" data-tid="${t.id}">${lb}</button>`).join('')}
                </div>
              </div>
            </div>`).join('')}
        </div>`;
      }).join('')}`;
    }

    function paint() { appEl.querySelector('.app-frame main').innerHTML = body(); wire(); }
    function wire() {
      const root = appEl.querySelector('.app-frame');
      root.querySelectorAll('[data-f]').forEach(b => b.addEventListener('click', () => { filter = b.dataset.f; paint(); }));
      root.querySelectorAll('[data-status]').forEach(b => b.addEventListener('click', () => {
        const t = s.tasks.find(x => x.id === b.dataset.tid);
        const st = b.dataset.status;
        if (st === 'later' || st === 'abandon') {
          promptReason(t, st);
          return;
        }
        t.status = st;
        if (st === 'done') { t.checkedInAt = nowFull(); openCheckin(t); }
        else if (st === 'doing') t.note = t.note || '';
        saveS(); paint();
      }));
      root.querySelectorAll('[data-check]').forEach(b => b.addEventListener('click', () => {
        const t = s.tasks.find(x => x.id === b.dataset.check);
        if (t.status === 'done') { t.status = 'doing'; t.checkedInAt = null; }
        else { t.status = 'done'; t.checkedInAt = nowFull(); openCheckin(t); }
        saveS(); paint();
      }));
    }
    function promptReason(t, st) {
      modal({
        title: st === 'later' ? '延期' : '放弃',
        body: h(`<p class="small muted" style="margin-bottom:8px">「${esc(t.title)}」</p>
          <div class="field"><label>${st === 'later' ? '延期原因（选填）' : '放弃原因（选填）'}</label>
          <textarea class="textarea" id="reason" placeholder="${st === 'later' ? '如：与课程时间冲突' : '如：方向调整，改为更有价值的事项'}"></textarea></div>`),
        foot: ft => {
          const c = h(`<button class="btn btn-paper">取消</button>`);
          const o = h(`<button class="btn ${st==='abandon'?'btn-danger-soft':'btn-primary'}">确定</button>`);
          ft.append(c, o);
          c.addEventListener('click', () => ft.closest('.modal-mask').remove());
          o.addEventListener('click', () => {
            t.status = st; t.note = ft.closest('.modal-mask').querySelector('#reason').value.trim() || t.note;
            saveS(); paint(); ft.closest('.modal-mask').remove(); toast(st === 'later' ? '已标记延期' : '已标记放弃');
          });
        },
      });
    }
    function openCheckin(t) {
      modal({
        title: '任务打卡 · ' + (t.title.length > 14 ? t.title.slice(0,14) + '…' : t.title),
        body: h(`<div class="field"><label>完成说明</label><textarea class="textarea" id="ck-note">${esc(t.note||'')}</textarea></div>
          <div class="field"><label>收获</label><textarea class="textarea" id="ck-gain" placeholder="学到了什么、有什么体会"></textarea></div>
          <div class="field"><label>困难</label><textarea class="textarea" id="ck-hard" placeholder="遇到什么障碍、如何克服"></textarea></div>
          <div class="field"><label>证明材料（选填）</label><input class="input" id="ck-proof" placeholder="链接 / 文件路径"></div>`),
        foot: ft => {
          const c = h(`<button class="btn btn-paper">稍后填写</button>`);
          const o = h(`<button class="btn btn-primary">保存打卡</button>`);
          ft.append(c, o);
          c.addEventListener('click', () => ft.closest('.modal-mask').remove());
          o.addEventListener('click', () => {
            const m = ft.closest('.modal-mask');
            t.note = m.querySelector('#ck-note').value.trim();
            t.gain = m.querySelector('#ck-gain').value.trim();
            t.hard = m.querySelector('#ck-hard').value.trim();
            saveS(); m.remove(); toast('打卡已保存', 'success');
          });
        },
      });
    }
    renderStudentShell(body(), 'plan');
    wire();
  },

  /* ============================================================
     阶段复盘
     ============================================================ */
  reviews(appEl) {
    const s = studentState();
    const reviews = s.reviews || [];
    const nextCycle = () => {
      const used = reviews.map(r => r.cycle);
      const cur = new Date();
      const ym = `${cur.getFullYear()}-${String(cur.getMonth()+1).padStart(2,'0')}`;
      return used.includes(ym) ? '自定义周期' : ym;
    };

    const html = `
    <div class="page-head">
      <div class="eyebrow">Step 09 · 阶段复盘</div>
      <h1>阶段复盘</h1>
      <p>对任务完成情况、兴趣变化与下一步调整做结构化总结。</p>
    </div>
    <button class="btn btn-primary btn-lg btn-block" id="new-review">＋ 开始${nextCycle()}复盘</button>

    ${reviews.map(r => `
      <div class="card card-pad mt16">
        <div class="row between">
          <div class="row gap8">
            <span class="badge badge-teal">${r.cycle} 复盘</span>
            ${r.completed ? badge('已提交','green') : badge('草稿','gray')}
          </div>
          <button class="btn btn-paper btn-sm" data-open-review="${r.id}">查看</button>
        </div>
        ${r.content ? `
          <div class="small mt12" style="color:var(--muted)">${esc((r.content.done||'').slice(0,60))}${(r.content.done||'').length>60?'…':''}</div>
        ` : ''}
        ${r.aiSummary ? `<div class="small mt12" style="background:var(--amber-l);border-radius:8px;padding:8px 10px;color:var(--ink-2)">🤖 阶段总结：${esc(r.aiSummary.slice(0,50))}…</div>` : ''}
        ${r.advisorRequested && !r.advisorReply ? `<div class="small mt12" style="color:var(--amber-d)">📨 已申请辅导员指导，待回复</div>` : ''}
      </div>`).join('')}`;

    renderStudentShell(html, 'plan');
    appEl.querySelector('#new-review').addEventListener('click', () => openReviewWizard(nextCycle()));
    appEl.querySelectorAll('[data-open-review]').forEach(b => b.addEventListener('click', () => {
      const r = reviews.find(x => x.id === b.dataset.openReview);
      modal({
        title: r.cycle + ' 阶段复盘',
        body: h(`<div class="prose" style="font-size:13.5px">
          ${r.content ? `
            <p><b>完成情况：</b>${esc(r.content.done||'')}</p>
            <p><b>未完成原因：</b>${esc(r.content.undone||'—')}</p>
            <p><b>兴趣变化：</b>${esc(r.content.interest||'—')}</p>
            <p><b>能力提升：</b>${esc(r.content.ability||'—')}</p>
            <p><b>下一步调整：</b>${esc(r.content.next||'—')}</p>` : '<p>草稿，无内容</p>'}
          ${r.aiSummary ? `<div style="background:var(--amber-l);border:1px solid var(--amber-s);border-radius:10px;padding:10px 12px;margin-top:10px"><b>🤖 AI 阶段总结</b><p style="margin-top:4px">${esc(r.aiSummary)}</p><p class="small" style="color:var(--muted)">智能生成，供探索参考</p></div>` : ''}
          ${r.aiSuggest ? `<div style="margin-top:10px"><b>调整建议</b><ul style="margin:6px 0 0 18px">${r.aiSuggest.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>` : ''}
          ${r.advisorRequested ? `<p class="small" style="color:var(--amber-d);margin-top:10px">📨 已申请辅导员指导${r.advisorReply?`，回复：${esc(r.advisorReply)}`:''}</p>` : ''}
        </div>`),
        foot: ft => ft.append(h(`<button class="btn btn-primary btn-sm">知道了</button>`, {})),
      });
    }));

    function openReviewWizard(cycle) {
      let step = 0;
      const form = {};
      const steps = [
        { t:'完成情况', field:'done', p:'这个周期你完成了哪些计划内或额外的事？', ph:'例如：完成了 Java 语法学习、通过了四级报名…' },
        { t:'未完成原因', field:'undone', p:'有哪些计划内事项未完成？原因是什么？', ph:'例如：LeetCode 练习因时间不足完成一半…' },
        { t:'兴趣变化', field:'interest', p:'这个周期的探索中，你的兴趣或方向看法有什么变化？', ph:'例如：对后端开发的兴趣比预期更强…' },
        { t:'能力提升', field:'ability', p:'你感觉哪些能力有提升？有什么证据？', ph:'例如：能独立写出 300 行左右的程序…' },
        { t:'下一步调整', field:'next', p:'下一阶段你打算如何调整？', ph:'例如：减少并行任务，聚焦数据结构与 SQL…' },
      ];
      let wizardEl;
      function paint() {
        const st = steps[step];
        const progress = step / steps.length * 100;
        const bodyEl = wizardEl.querySelector('.modal-body');
        bodyEl.innerHTML = `
          <div class="stepper" style="margin-bottom:14px">${steps.map((x,i)=>`<div class="s-item ${i<step?'done':i===step?'current':''}"><span class="s-dot">${i<step?'✓':i+1}</span><span class="s-label">${x.t}</span></div>`).join('')}</div>
          ${progressBar(progress)}
          <div class="field mt16"><label>${st.p}</label>
          <textarea class="textarea" id="wz-in" placeholder="${st.ph}" style="min-height:110px">${esc(form[st.field]||'')}</textarea></div>
          <label class="row gap8 small muted" style="cursor:pointer;margin-top:4px">
            <input type="checkbox" id="wz-advisor" ${step===steps.length-1 ? '' : 'disabled'} style="accent-color:var(--teal)"> 申请辅导员对本次复盘给出指导建议
          </label>`;
      }
      wizardEl = modal({
        title: cycle + ' · 阶段复盘',
        body: h(`<div></div>`),
        foot: ft => {
          const back = h(`<button class="btn btn-paper">上一步</button>`);
          const next = h(`<button class="btn btn-primary">${step===steps.length-1?'生成 AI 阶段总结 →':'下一步 →'}</button>`);
          ft.append(back, next);
          back.addEventListener('click', () => { if (step>0){ step--; paint(); } });
          next.addEventListener('click', () => {
            const val = wizardEl.querySelector('#wz-in').value.trim();
            if (!val) { toast('请填写内容或点击"下一步"跳过', 'error'); return; }
            form[steps[step].field] = val;
            if (step < steps.length-1) { step++; paint(); }
            else {
              const wantAdvisor = wizardEl.querySelector('#wz-advisor').checked;
              // 生成 AI 总结
              const summary = genAiSummary(form);
              const suggest = genAiSuggest(form);
              const r = { id:'R'+Date.now(), cycle, completed:true, submittedAt:nowFull(), content:{...form}, aiSummary:summary, aiSuggest:suggest, advisorRequested:wantAdvisor, advisorReply:null };
              s.reviews = s.reviews || [];
              s.reviews.unshift(r);
              saveS();
              wizardEl.close();
              toast('复盘已提交，AI 阶段总结已生成', 'success');
              navigate('/student/reviews');
            }
          });
        },
      });
      paint();
    }
    function genAiSummary(f) {
      const done = s.tasks ? s.tasks.filter(t=>t.status==='done').length : 0;
      const total = s.tasks ? s.tasks.length : 0;
      const dir = s.goal && s.goal.primary ? s.goal.primary.name : '当前方向';
      return `本周期你${done && total ? `完成了 ${done}/${total} 项任务` : '推进了任务清单'}，围绕「${dir}」的探索有明显进展：${esc((f.done||'').slice(0,40))}。${f.undone ? `未完成部分主要集中在「${esc(f.undone.slice(0,30))}」，` : ''}${f.interest ? `兴趣上${esc(f.interest.slice(0,30))}。` : ''}整体来看，方向感比上一阶段更清晰，建议下一阶段收敛重点、提升执行密度。`;
    }
    function genAiSuggest(f) {
      return ['将任务收敛到 3 条主线，减少并行','每周固定时间块推进重点任务','依据本轮复盘更新学期计划'];
    }
  },

  /* ============================================================
     AI 生涯咨询
     ============================================================ */
  aiChat(appEl) {
    const s = studentState();
    s.aiChat = s.aiChat || [];
    let typing = false;

    function body() {
      return `
      <div class="page-head">
        <div class="eyebrow">AI 智能服务</div>
        <h1>生涯咨询助手</h1>
        <p>回答专业认知、路径比较、学习安排与计划优化问题。</p>
      </div>
      <div class="chat-ai-note">${ICONS.spark}<span><b>智能生成，供探索参考。</b>涉及重大决策、心理健康、法律、医疗等内容将提示转人工或专业机构，AI 不进行诊断与结论性判断。</span></div>
      <div class="quick-q">
        ${['后端开发怎么入门？','考研和就业能同时准备吗？','AI 方向需要学什么？','我有点迷茫，怎么选方向？','数据分析 vs 产品经理怎么选？'].map((q,i)=>`<button data-q="${i}">${q}</button>`).join('')}
      </div>
      <div class="chat-wrap" id="chat-log"></div>`;
    }

    function renderMsgs() {
      const log = appEl.querySelector('#chat-log');
      log.innerHTML = s.aiChat.map((m,i) => `
        <div class="chat-msg ${m.role}">
          <div class="c-ava">${m.role==='ai' ? '🤖' : '👤'}</div>
          <div class="c-body">
            <div class="c-bubble">${esc(m.content)}</div>
            ${m.role==='ai' ? '<div class="c-meta">生涯助手 · 智能生成，供探索参考</div>' : ''}
          </div>
        </div>`).join('');
      log.scrollTop = log.scrollHeight;
    }

    function send(text) {
      if (typing) return;
      if (!text.trim()) return;
      s.aiChat.push({ role:'me', content:text });
      saveS(); renderMsgs();
      typing = true;
      // 模拟"正在输入"
      const log = appEl.querySelector('#chat-log');
      const tip = h(`<div class="chat-msg ai"><div class="c-ava">🤖</div><div class="c-body"><div class="c-bubble" style="color:var(--faint)">正在思考…</div></div></div>`);
      log.appendChild(tip);
      setTimeout(() => {
        tip.remove();
        const r = AppCore.aiReply(text);
        const reply = r.esc ? `⚠️ ${r.text}` : r.text;
        s.aiChat.push({ role:'ai', content: reply, esc: r.esc });
        typing = false;
        saveS(); renderMsgs();
      }, 550 + Math.random() * 500);
    }

    const html = body();
    renderStudentShell(html, 'ai');
    renderMsgs();
    const root = appEl.querySelector('.app-frame');
    root.querySelectorAll('[data-q]').forEach(b => b.addEventListener('click', () => send(b.textContent.replace(/\？$/,'?'))));
    // 输入条固定到底部
    const inputBar = h(`<div class="mt16"><div class="chat-input-bar">
      <textarea id="ai-in" placeholder="输入你的问题…（如：考研和就业能同时准备吗）" rows="1"></textarea>
      <button class="btn btn-primary" id="ai-send">发送</button>
    </div></div>`);
    root.querySelector('main').appendChild(inputBar);
    const ta = inputBar.querySelector('#ai-in');
    ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(ta.value); ta.value=''; } });
    inputBar.querySelector('#ai-send').addEventListener('click', () => { send(ta.value); ta.value=''; });
  },
};
