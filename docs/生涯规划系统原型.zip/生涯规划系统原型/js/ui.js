/* ============================================================
   生涯规划系统 · MVP 原型 —— UI 工具库
   ============================================================ */

// 从 HTML 字符串创建元素（可注入事件）
function h(html, handlers) {
  const tpl = document.createElement('template');
  tpl.innerHTML = html.trim();
  const node = tpl.content.firstElementChild;
  if (handlers) {
    for (const [sel, fn] of Object.entries(handlers)) {
      const els = node.querySelectorAll(sel);
      els.forEach(el => el.addEventListener('click', fn));
    }
  }
  return node;
}

function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function toast(msg, type='info', ms=2400) {
  const w = document.getElementById('toast-wrap');
  const el = h(`<div class="toast ${type}">${type==='success'?'✓':type==='error'?'✕':''}<span>${esc(msg)}</span></div>`);
  w.appendChild(el);
  setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity .3s'; }, ms);
  setTimeout(() => el.remove(), ms + 320);
}

// 模态框
function modal({ title, body, foot, onClose }) {
  const root = document.getElementById('modal-root');
  const mask = h(`<div class="modal-mask"><div class="modal">
    <div class="modal-head"><h3>${title}</h3><button class="modal-close" aria-label="关闭">×</button></div>
    <div class="modal-body"></div>
    <div class="modal-foot"></div>
  </div></div>`);
  mask.querySelector('.modal-body').append(body);
  const footEl = mask.querySelector('.modal-foot');
  if (foot) foot(footEl);
  const close = () => { mask.remove(); if (onClose) onClose(); };
  mask.querySelector('.modal-close').addEventListener('click', close);
  mask.addEventListener('click', e => { if (e.target === mask) close(); });
  root.appendChild(mask);
  return { close, el: mask };
}

function confirmModal({ title, text, okText='确认', danger=false, onOk }) {
  return modal({
    title,
    body: h(`<p class="muted" style="font-size:14px">${text}</p>`),
    foot: ft => {
      ft.append(h(`<button class="btn btn-paper">取消</button>`, {}));
      const ok = h(`<button class="btn ${danger?'btn-danger-soft':'btn-primary'}">${okText}</button>`);
      ft.append(ok);
      ok.addEventListener('click', () => { onOk && onOk(); closeModal(); });
      const closeModal = () => ft.closest('.modal-mask').remove();
    },
  });
}

// —— SVG 雷达图（六维画像） ——
// dims: [{name, value:0..100}]
function radarSVG(dims, size=240) {
  const c = size / 2;
  const R = size / 2 - 34;
  const n = dims.length;
  const ang = (i) => (-Math.PI / 2) + (2 * Math.PI * i / n);
  const pt = (i, r) => [c + r * Math.cos(ang(i)), c + r * Math.sin(ang(i))];
  const round = (v) => Math.round(v * 10) / 10;

  let grid = '';
  const levels = 4;
  for (let L = 1; L <= levels; L++) {
    let pts = '';
    for (let i = 0; i < n; i++) { const [x, y] = pt(i, R * L / levels); pts += `${round(x)},${round(y)} `; }
    grid += `<polygon points="${pts}" fill="none" stroke="#E5E0D4" stroke-width="1"/>`;
  }
  let spokes = '';
  for (let i = 0; i < n; i++) { const [x, y] = pt(i, R); spokes += `<line x1="${c}" y1="${c}" x2="${round(x)}" y2="${round(y)}" stroke="#E5E0D4" stroke-width="1"/>`; }
  let dataPts = '';
  for (let i = 0; i < n; i++) {
    const v = Math.max(4, Math.min(100, dims[i].value));
    const [x, y] = pt(i, R * v / 100); dataPts += `${round(x)},${round(y)} `;
  }
  let labels = '';
  for (let i = 0; i < n; i++) {
    const [x, y] = pt(i, R + 22);
    labels += `<text x="${round(x)}" y="${round(y + 4)}" text-anchor="middle" font-size="12" font-weight="700" fill="#45535E" font-family="'Noto Sans SC',sans-serif">${dims[i].name}</text>`;
  }
  let dots = '';
  for (let i = 0; i < n; i++) {
    const v = Math.max(4, Math.min(100, dims[i].value));
    const [x, y] = pt(i, R * v / 100);
    dots += `<circle cx="${round(x)}" cy="${round(y)}" r="3.5" fill="#C67B34"/>`;
  }
  return `
  <svg class="radar-svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" role="img" aria-label="六维画像雷达图">
    ${grid}${spokes}
    <polygon points="${dataPts}" fill="rgba(14,90,109,.18)" stroke="#0E5A6D" stroke-width="2" stroke-linejoin="round"/>
    ${dots}
    ${labels}
  </svg>`;
}

// 环形进度
function ringSVG(value, size=64, color='#0E5A6D', label='') {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(100, value));
  return `
  <span class="ring" style="--p:${p};width:${size}px;height:${size}px">
    <svg width="${size}" height="${size}">
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="#EFEBE2" stroke-width="6"/>
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="${color}" stroke-width="6" stroke-linecap="round"
        stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - p/100)}"/>
    </svg>
    <span class="ring-label"><b>${Math.round(p)}</b><span>${label}</span></span>
  </span>`;
}

// 空状态
function emptyState(icon, title, sub, action) {
  const el = h(`<div class="empty"><div class="e-icon">${icon}</div><div class="e-title">${title}</div><div class="e-sub">${sub || ''}</div></div>`);
  if (action) { action(el.querySelector('.empty')); }
  return el;
}

// 徽章
function badge(text, type='teal') {
  return `<span class="badge badge-${type}"><span class="dot"></span>${esc(text)}</span>`;
}

// 任务状态 → 徽章映射
const TASK_STATUS = {
  pending: { label:'未开始', type:'gray' },
  doing:   { label:'进行中', type:'blue' },
  done:    { label:'已完成', type:'green' },
  later:   { label:'延期',   type:'amber' },
  abandon: { label:'放弃',   type:'red' },
};

function taskBadge(status) {
  const s = TASK_STATUS[status] || TASK_STATUS.pending;
  return badge(s.label, s.type);
}

// 进度条
function progressBar(value, height=6) {
  return `<div class="progress" style="height:${height}px"><i style="width:${Math.max(0, Math.min(100, value))}%"></i></div>`;
}

// 日期工具
function todayISO() {
  const d = new Date();
  const p = n => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;
}

function nowFull() {
  const d = new Date();
  const p = n => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function timeGreeting() {
  const hh = new Date().getHours();
  if (hh < 6) return '夜深了';
  if (hh < 12) return '上午好';
  if (hh < 14) return '中午好';
  if (hh < 18) return '下午好';
  return '晚上好';
}
